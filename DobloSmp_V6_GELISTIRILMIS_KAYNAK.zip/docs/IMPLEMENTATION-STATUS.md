# DobloSmp V6 - Bu düzenlemenin kapsamı

## Kaynakta yapılan değişiklikler

- SkyBlock ada seviye/değer modeli kaldırıldı; `/is level`, ada seviyesi görevleri ve profil/scoreboard seviyesi gösterimleri kaldırıldı.
- Yeni ada başlangıç sandığı yalnızca 1 lava kovası, 1 su kovası ve 2 meşe fidanı verecek şekilde düzeltildi.
- `/ada` yeni V6 SkyBlock komutuna bağlandı; `/island` alias'ı `/is` üzerinden korunuyor.
- `/spawn` komutu Lobby'ye dönüş için eklendi.
- BedWars modları yalnızca Solo olarak sınırlandı; 8 oyuncu ve 8 ayrı takım zorunlu hâle getirildi. Takım adları Mavi, Kırmızı, Sarı, Mor, Yeşil, Koyu Yeşil, Siyah ve Gri.
- BedWars mağaza kataloğu genişletildi; araç yükseltmeleri, kalıcı makas, iksirler ve özel eşyalar eklendi.
- BedWars scoreboard/TAB görünümü için HUD bağlantısı eklendi.
- Murder Mystery en az 5 oyuncuya sınırlandı; Şerif/Katil şansları ve bağımsız masum geçmiş sayaçları YAML dosyasına kaydediliyor.
- Murder Mystery rol açıklama süresi, ok cooldown'u ve XP şişesi toplama noktaları eklendi.
- Murder Mystery'de sidebar scoreboard kapalı tutuluyor.
- Duels lig adları Bakır, Demir, Altın, Elmas, Zümrüt ve Netherite olarak değiştirildi; Crystal/Mace/Diamond kitleri config'e eklendi.
- Duels Elo için YAML yedek kalıcılığı ve `/duel top` komutu eklendi.
- TAB başlık/altbilgi ve Lobby/SkyBlock/BedWars/Duels scoreboard güncelleme servisi eklendi. Scoreboard'larda oyun modu satırı yok. Rank görünümü `doblo.rank.kurucu`, `doblo.rank.developer`, `doblo.rank.moderator`, `doblo.rank.rehber`, `doblo.rank.drehber`, `doblo.rank.medya`, `doblo.rank.vipplus`, `doblo.rank.vip` izin düğümlerini tanır.
- Maven test çalıştırıcılarında `System.exit` kaldırıldı; test hataları build'i AssertionError ile durduruyor.
- GitHub Actions Java 21/Maven build workflow'u eklendi.

## Yerel doğrulama

- Bukkit/Paper bağımlılığı gerektirmeyen Java kaynakları Java 21 ile derlendi.
- CoreTests: 120 başarılı, 0 başarısız.
- NewTests'in veritabanı dışındaki bölümü: 89 başarılı, 0 başarısız.
- YAML config.yml ve plugin.yml sözdizimi doğrulandı.

## Henüz doğrulanmayan / gereken işler

- Bu çalışma ortamında Maven ve Paper API indirilemediği için tam Paper plugin JAR derlemesi yapılamadı. GitHub Actions workflow'u bu derlemeyi yapacak şekilde eklendi; başarılı artifact oluşmadan JAR hazır sayılmaz.
- Tam NewTests DB/H2 bölümü bu ortamda çalıştırılmadı.
- ZIP içinde Lobby dünyası var; BedWars, Duels ve Murder Mystery arena haritaları yok. Bu haritalar ve arena spawn/bed/generator/XP konumları sağlanmalı.
- Duels'in mevcut maç motoru hâlâ 1v1 çalışıyor; 2v2 takım maç motoru henüz uygulanmadı.
- Paper sunucusunda canlı oyun testi yapılmadı. Arena, NPC, shop, respawn, TAB ve scoreboard davranışları gerçek sunucuda doğrulanmalı.

## Kurulum için not

- `worlds/lobby-world` klasörünü sunucunun ana dizinine `lobby` adıyla kopyalayın. `config.yml` içindeki `lobby.world` varsayılan olarak `lobby` değerini kullanır.
- GitHub deposunun köküne bu ZIP'in içeriğini çıkarın; ZIP'i tek başına depoya koymak build workflow'unu çalıştırmaz.
- GitHub Actions'ta **DobloSmp V6 Build** iş akışını çalıştırın. Başarılı olursa `DobloSmp-V6-JAR` artifact'i oluşur.
- Arena haritaları olmadığı için BedWars, Duels ve Murder Mystery arenaları yönetici komutlarıyla konumlandırılıp kurulmalıdır; harita ZIP'leri ayrıca gereklidir.
