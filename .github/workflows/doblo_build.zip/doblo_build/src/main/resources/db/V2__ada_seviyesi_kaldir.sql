-- DobloSmp V6: ada seviyesi / puanı / geliştirme seviyeleri kaldırıldı.
ALTER TABLE islands DROP COLUMN lvl;
ALTER TABLE islands DROP COLUMN worth;
ALTER TABLE islands DROP COLUMN size_lvl;
ALTER TABLE islands DROP COLUMN member_lvl;
ALTER TABLE islands DROP COLUMN gen_lvl;
