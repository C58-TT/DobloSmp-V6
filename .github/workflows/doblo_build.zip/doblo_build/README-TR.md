# DobloSuite 6.0.0 — DobloSmp V6 çalışma paketi
Java 21 / Paper 1.21.11 Maven projesi. **V6 gerçek Paper sunucusunda test edilmedi** — önce `docs/STATUS.md` ve `docs/V6-DEVAM-EDEN-ISLER.md` oku.
- Derleme/test: `mvn clean package`. V5 test sayısı V6 için geçerli değildir; testleri yeniden çalıştır. Kurulum: `docs/INSTALL.md`. Android: `docs/ANDROID-YONETIM.md`.
- Komutlar: `/is`, `/bw`, `/duel`, `/mm`, `/menu`, `/bakiye`, `/pay`, `/takas`, `/market`, `/klan`, `/arkadas`, `/parti`, `/gorevler`, `/rapor`, `/discord`; yönetici: `/dac`, `/perf`, `/yedek`, `/dnpc`, arena komutları. Eski `/ada` korunur.
- Gizli bilgiler DB parolası ve Discord webhook dahil ortam değişkenleriyle verilir; config.yml içine yazma.


## V6 değişiklikleri
- Web paneli kaldırıldı; yönetim SSH/systemd üzerinden yapılır.
- Lobi haritası `worlds/lobby-world/` içinde; `scripts/install-lobby.sh /opt/minecraft` ile sunucu dizinine `lobby/` olarak kopyalayın (mevcut dünyayı ezmez).
- `/lobby` komutu oyuncuyu lobi spawn noktasına götürür.
- `lobby.npcs.enabled: true` iken lobi yüklendikten sonra eksik varsayılan oyun NPC'leri otomatik oluşturulur; var olan NPC'ler çoğaltılmaz.
- NPC'lere sağ tıklamak ilgili oyun/menüyü açar. Yönetici `/dnpc create <eylem> [isim]` ile özel NPC oluşturabilir.
- Paper gerçek ortam doğrulaması tamamlanmamıştır. `docs/V6-DEVAM-EDEN-ISLER.md`

- Harici eklentiler / LuckPerms / GrimAC / Geyser / Vault: `configs/V6-PLUGIN-KURULUM.md`
- Gizli ayarların oluşturulması: `scripts/setup-secrets.sh`
