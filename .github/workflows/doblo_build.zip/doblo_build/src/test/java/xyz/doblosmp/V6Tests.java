package xyz.doblosmp;

import xyz.doblosmp.bedwars.*;
import xyz.doblosmp.duels.*;
import xyz.doblosmp.economy.*;
import xyz.doblosmp.murder.*;
import java.util.*;

/** V6 testleri (saf mantık). Çalıştır: java -cp target/classes:target/test-classes xyz.doblosmp.V6Tests */
public class V6Tests {
    static int pass, fail;
    static void check(String n, boolean c) { if (c) pass++; else { fail++; System.out.println("BASARISIZ: " + n); } }
    static UUID u() { return UUID.randomUUID(); }

    public static void main(String[] a) {
        elo(); bedwars(); murder(); skyShop(); pairHist();
        System.out.println("V6 testleri - Geçen: " + pass + "  Kalan: " + fail);
        System.exit(fail == 0 ? 0 : 1);
    }

    static void elo() {
        check("6 lig", Elo.leagues().size() == 6);
        check("lig sırası", Elo.league(0).equals("Bakır") && Elo.league(950).equals("Demir") && Elo.league(1100).equals("Altın")
                && Elo.league(1300).equals("Elmas") && Elo.league(1500).equals("Zümrüt") && Elo.league(1750).equals("Netherite") && Elo.league(9999).equals("Netherite"));
        Elo.Result eq = Elo.compute(1000, 1000, 32, 0, 1);
        int base = Elo.expectedDelta(1000, 1000, true, 32);   // klasik Elo = 16
        check("eşit rakip: kazanç lig çarpanıyla azalır (Demir: 15), kayıp artar (17)", eq.winnerDelta() == 15 && eq.loserDelta() == 17 && base == 16);
        Elo.Result up = Elo.compute(1000, 1400, 32, 0, 1), down = Elo.compute(1400, 1000, 32, 0, 1);
        check("güçlü rakibi yenmek daha çok Elo", up.winnerDelta() > down.winnerDelta());
        check("zayıfa yenilmek daha çok Elo kaybettirir", down.loserDelta() >= 1 && Elo.compute(1400, 1000, 32, 0, 1).loserDelta() < Elo.compute(1000, 1400, 32, 0, 1).loserDelta() + 100);
        Elo.Result lossToWeak = Elo.compute(1000, 1400, 32, 0, 1);   // kaybeden 1400 zayıf 1000'e yenildi
        Elo.Result lossToStrong = Elo.compute(1400, 1000, 32, 0, 1);  // kaybeden 1000, güçlüye yenildi
        check("zayıfa yenilen güçlü daha çok kaybeder", lossToWeak.loserDelta() > lossToStrong.loserDelta());
        check("üst ligde kazanç azalır", Elo.gainMultiplier(5) < Elo.gainMultiplier(0) && Elo.lossMultiplier(5) > Elo.lossMultiplier(0));
        int full = Elo.compute(1000, 1000, 32, 0, 1).winnerDelta();
        check("kasılma: 1. maç serbest", Elo.compute(1000, 1000, 32, 1, 1).winnerDelta() == full);
        int f2 = Elo.compute(1000, 1000, 32, 2, 1).winnerDelta(), f5 = Elo.compute(1000, 1000, 32, 5, 1).winnerDelta();
        check("kasılma: aynı çift tekrar edince kazanç düşer, sonunda 0", f2 < full && f5 == 0);
        check("Elo 0'ın altına düşmez", Elo.compute(1000, 3, 32, 0, 1).loserNew() >= 0);
        check("geçersiz lig tablosu reddedilir", !Elo.setLeagues(List.of(new Elo.League("A", "§f", 5), new Elo.League("B", "§f", 10))));
        check("geçerli özel lig tablosu", Elo.setLeagues(List.of(new Elo.League("X", "§f", 0), new Elo.League("Y", "§f", 100))) && Elo.league(150).equals("Y"));
        Elo.resetLeagues();
    }

    static void bedwars() {
        BedwarsMatch m = new BedwarsMatch(BedwarsMode.SOLO);
        check("solo: 8 takım, takım başı 1", m.teams().size() == 8 && BedwarsMode.SOLO.perTeam == 1 && BedwarsMode.SOLO.capacity() == 8);
        check("takım isimleri", Arrays.equals(BedwarsMatch.TEAM_NAMES, new String[]{"Mavi", "Kırmızı", "Sarı", "Mor", "Yeşil", "Koyu Yeşil", "Siyah", "Gri"}));
        List<UUID> ps = new ArrayList<>(); for (int i = 0; i < 8; i++) ps.add(u());
        for (int i = 0; i < 7; i++) m.join(ps.get(i), null);
        check("7 oyuncuyla başlamaz", !m.canStart(2) && !m.startCountdown(2));
        check("9. oyuncu alınmaz", m.join(ps.get(7), null) && !m.join(u(), null));
        check("8 oyuncuyla başlar", m.startCountdown(2) && m.state() == BedwarsMatch.State.COUNTDOWN);
        check("begin", m.begin(new Random(7)) && m.state() == BedwarsMatch.State.RUNNING);
        Set<BedwarsMatch.Team> used = new HashSet<>(); boolean one = true; for (UUID p : ps) { used.add(m.teamOf(p)); one &= m.teamOf(p).members.size() == 1; }
        check("8 farklı takım, her takımda 1 oyuncu", used.size() == 8 && one);
        check("takım durumu ✓", m.teamStatus(m.teams().get(0)).contains("✓") && m.teamsLeft() == 8 && m.playersLeft() == 8);
        // yatak + eleme
        UUID a = ps.get(0), b = ps.get(1); int bt = m.teamOf(b).index;
        check("yatak kırılır", m.breakBed(a, bt) && !m.teams().get(bt).bed);
        check("yatak yoksa ölünce elenir", m.onDeath(b, a) == BedwarsMatch.DeathResult.ELIMINATED && m.isSpectator(b));
        check("takım elendi ✗", m.teamStatus(m.teams().get(bt)).contains("✗") && m.teamsLeft() == 7);
        check("yatak varken yeniden doğar", m.onDeath(ps.get(2), a) == BedwarsMatch.DeathResult.RESPAWN);
        // son kalan kazanır
        for (int i = 2; i < 8; i++) { m.breakBed(a, m.teamOf(ps.get(i)).index); m.onDeath(ps.get(i), a); }
        check("son hayatta kalan kazanır", m.state() == BedwarsMatch.State.ENDING && m.winner() == m.teamOf(a));
        // eski modlar
        check("eski mod adı SOLO'ya döner", BedwarsMode.of("DOUBLES") == BedwarsMode.SOLO);
    }

    static void murder() {
        RoleChance.Cfg cfg = RoleChance.Cfg.defaults(); RoleChance rc = new RoleChance(cfg); UUID p = u();
        check("başlangıç şansları", rc.of(p).sheriff() == 1500 && rc.of(p).murderer() == 500);
        rc.record(p, MurderGame.Role.INNOCENT);
        check("masum kalınca ikisi de artar", rc.of(p).sheriff() == 2000 && rc.of(p).murderer() == 800);
        for (int i = 0; i < 50; i++) rc.record(p, MurderGame.Role.INNOCENT);
        check("şans tavana takılır", rc.of(p).sheriff() == cfg.maxSheriff() && rc.of(p).murderer() == cfg.maxMurderer());
        rc.record(p, MurderGame.Role.DETECTIVE);
        check("şerif olunca yalnız şerif şansı sıfırlanır", rc.of(p).sheriff() == 1500 && rc.of(p).murderer() == cfg.maxMurderer());
        rc.record(p, MurderGame.Role.INNOCENT); rc.record(p, MurderGame.Role.MURDERER);
        check("katil olunca yalnız katil şansı sıfırlanır", rc.of(p).murderer() == 500 && rc.of(p).sheriff() > 1500);
        check("iki şansın toplamı %100 olmak zorunda değil", rc.of(p).sheriff() + rc.of(p).murderer() != 10000);
        // ağırlıklı seçim: yüksek şanslı oyuncu daha sık seçilir
        RoleChance w = new RoleChance(cfg); List<UUID> ps = new ArrayList<>(); for (int i = 0; i < 6; i++) ps.add(u());
        w.load(ps.get(0), 6000, 3000); Random rng = new Random(42); int sheriff0 = 0, murd0 = 0, sheriffLow = 0, murdLow = 0, N = 6000;
        for (int i = 0; i < N; i++) { var as = w.pick(ps, rng); if (ps.get(0).equals(as.sheriff())) sheriff0++; if (ps.get(0).equals(as.murderer())) murd0++;
            if (ps.get(2).equals(as.sheriff())) sheriffLow++; if (ps.get(2).equals(as.murderer())) murdLow++;
            check("katil != şerif", !as.murderer().equals(as.sheriff())); }
        check("yüksek şanslı daha sık şerif", sheriff0 > sheriffLow * 1.2);
        check("yüksek şanslı daha sık katil", murd0 > murdLow * 3);
        check("düşük şanslı oyuncu da seçilebilir (adil, sıfırlanmaz)", sheriffLow > 0 && murdLow > 0);
        // yüklenen şans tavan/taban dışına çıkamaz
        w.load(ps.get(1), 999999, -5); check("load sınırlar", w.of(ps.get(1)).sheriff() == cfg.maxSheriff() && w.of(ps.get(1)).murderer() == cfg.baseMurderer());
        check("format", RoleChance.format(new RoleChance.Chances(1500, 500)).equals("Şerif Olma Şansı: %15,0  |  Katil Olma Şansı: %5,0") || RoleChance.format(new RoleChance.Chances(1500, 500)).contains("%15.0"));
        // oyun mantığı
        UUID m = ps.get(0), s = ps.get(1); MurderGame g = new MurderGame(ps, m, s, 60000);
        check("tek katil", ps.stream().filter(x -> g.role(x) == MurderGame.Role.MURDERER).count() == 1);
        long t0 = 1_000_000;
        check("şerif ok atar", g.tryShoot(s, t0)); check("5 sn cooldown", !g.tryShoot(s, t0 + 4000) && g.tryShoot(s, t0 + 5000));
        g.kill(m, s);
        check("şerif ölünce ok düşer", g.arrowDropped() && g.bowHolder() == null);
        UUID inn = ps.get(2); check("masum oku alır ve atabilir", g.pickupBow(inn) && g.tryShoot(inn, t0 + 20000));
        check("katil oku alamaz", !g.pickupBow(m));
        check("katil ölünce masumlar kazanır", g.kill(inn, m) == MurderGame.Winner.INNOCENTS);
        MurderGame g2 = new MurderGame(ps.subList(0, 3), ps.get(0), ps.get(1), 60000); g2.kill(ps.get(0), ps.get(1)); 
        check("hepsi ölünce katil kazanır", g2.kill(ps.get(0), ps.get(2)) == MurderGame.Winner.MURDERER);
    }

    /** Basit sahte envanter: kapasite 36 yuva, yığın 64. */
    static class FakeInv implements SkyShop.InventoryPort {
        final Map<String, Integer> items = new HashMap<>(); int freeSlots = 36; boolean failAdd;
        public int count(SkyShop.Product p) { return items.getOrDefault(p.id(), 0); }
        public boolean canFit(SkyShop.Product p, int n) { return freeSlots >= (n + 63) / 64; }
        public boolean add(SkyShop.Product p, int n) { if (failAdd || !canFit(p, n)) return false; items.merge(p.id(), n, Integer::sum); freeSlots -= (n + 63) / 64; return true; }
        public boolean remove(SkyShop.Product p, int n) { int h = count(p); if (h < n) return false; items.put(p.id(), h - n); freeSlots += (n + 63) / 64; return true; }
    }

    static void skyShop() {
        SkyShop shop = new SkyShop(); Ledger l = new Ledger(1000); UUID p = u(); FakeInv inv = new FakeInv(); String M = "sb";
        check("6 kategori", SkyShop.Category.values().length == 6);
        check("tarım 8 ürün, maden 7, yapı 7, mob 6, özel 3, spawner 6", shop.in(SkyShop.Category.TARIM).size() == 8 && shop.in(SkyShop.Category.MADEN).size() == 7
                && shop.in(SkyShop.Category.YAPI).size() == 7 && shop.in(SkyShop.Category.MOB).size() == 6 && shop.in(SkyShop.Category.OZEL).size() == 3 && shop.in(SkyShop.Category.SPAWNER).size() == 6);
        check("kaktüs satış kategorisinde (tarım)", shop.get("CACTUS").cat() == SkyShop.Category.TARIM && shop.get("CACTUS").buy() == 350 && shop.get("CACTUS").sell() == 140);
        check("fiyat: Buğday 64 / 320 / 120", shop.get("WHEAT").amount() == 64 && shop.get("WHEAT").buy() == 320 && shop.get("WHEAT").sell() == 120);
        check("Çürük Et satın alınamaz, satılır 90", !shop.get("ROTTEN_FLESH").canBuy() && shop.get("ROTTEN_FLESH").sell() == 90);
        check("Demir Golem Spawner 600.000", shop.get("IRON_GOLEM_SPAWNER").buy() == 600_000 && shop.get("IRON_GOLEM_SPAWNER").entity().equals("IRON_GOLEM"));
        check("yetersiz bakiye", shop.buy(l, M, p, "WHEAT", inv) == SkyShop.Result.NO_FUNDS && inv.count(shop.get("WHEAT")) == 0 && l.balance(M, p) == 0);
        l.deposit(M, p, 1000, "test");
        check("satın alma", shop.buy(l, M, p, "WHEAT", inv) == SkyShop.Result.OK && inv.count(shop.get("WHEAT")) == 64 && l.balance(M, p) == 680);
        check("satış", shop.sell(l, M, p, "WHEAT", inv) == SkyShop.Result.OK && inv.count(shop.get("WHEAT")) == 0 && l.balance(M, p) == 800);
        check("eşyasız satış reddi", shop.sell(l, M, p, "WHEAT", inv) == SkyShop.Result.NOT_ENOUGH_ITEMS && l.balance(M, p) == 800);
        check("satın alınamaz ürün", shop.buy(l, M, p, "ROTTEN_FLESH", inv) == SkyShop.Result.NOT_BUYABLE);
        check("satılamaz ürün (kova)", shop.sell(l, M, p, "WATER_BUCKET", inv) == SkyShop.Result.NOT_SELLABLE);
        check("bilinmeyen ürün", shop.buy(l, M, p, "HACK", inv) == SkyShop.Result.UNKNOWN);
        inv.freeSlots = 0; long before = l.balance(M, p);
        check("envanter dolu -> iptal, para düşmez", shop.buy(l, M, p, "WHEAT", inv) == SkyShop.Result.INVENTORY_FULL && l.balance(M, p) == before);
        inv.freeSlots = 36; inv.failAdd = true;
        check("eşya verilemezse para iade", shop.buy(l, M, p, "WHEAT", inv) == SkyShop.Result.FAILED && l.balance(M, p) == before);
        inv.failAdd = false;
        check("ledger tutarlı (audit)", l.audit(M));
        // para negatife düşmez, tam bakiyeyle alım
        UUID q = u(); l.deposit(M, q, 320, "t"); FakeInv i2 = new FakeInv();
        check("tam bakiye ile alım -> 0", shop.buy(l, M, q, "WHEAT", i2) == SkyShop.Result.OK && l.balance(M, q) == 0 && shop.buy(l, M, q, "WHEAT", i2) == SkyShop.Result.NO_FUNDS);
        // çift işlem kilidi: iç içe alım BUSY
        UUID r = u(); l.deposit(M, r, 10_000, "t"); boolean[] nested = {false};
        FakeInv reenter = new FakeInv() { public boolean add(SkyShop.Product pr, int n) { nested[0] = shop.buy(l, M, r, "WHEAT", this) == SkyShop.Result.BUSY; return super.add(pr, n); } };
        check("eşzamanlı çift alım engellenir", shop.buy(l, M, r, "WHEAT", reenter) == SkyShop.Result.OK && nested[0] && l.balance(M, r) == 9680);
        // config fiyat geçersiz kılma
        SkyShop s2 = new SkyShop(); int n = s2.applyOverrides(Map.of("DIAMOND", new long[]{999, 111}, "YOK", new long[]{1, 1}, "ZOMBIE_SPAWNER", new long[]{5, 5}));
        check("config fiyatı", n == 2 && s2.get("DIAMOND").buy() == 999 && s2.get("DIAMOND").sell() == 111 && s2.get("ZOMBIE_SPAWNER").buy() == 5 && !s2.get("ZOMBIE_SPAWNER").canSell());
    }

    static void pairHist() {
        PairHistory h = new PairHistory(); UUID a = u(), b = u(), c = u(); long t = 1_000_000, W = 3_600_000;
        check("başlangıçta 0", h.recent(a, b, t, W) == 0);
        h.record(a, b, t); h.record(b, a, t + 1000);
        check("sıra fark etmez, 2 maç", h.recent(b, a, t + 2000, W) == 2 && h.recent(a, c, t + 2000, W) == 0);
        check("pencere dışı silinir", h.recent(a, b, t + W + 5000, W) == 0 && h.size() == 0);
        h.record(a, c, t); h.purge(t + W * 2, W); check("purge bellek temizler", h.size() == 0);
        // sürekli aynı rakiple maç: Elo kazancı sıfıra iner (kasılma engeli)
        int total = 0, ea = 1000, eb = 1000; long now = t; PairHistory ph = new PairHistory();
        for (int i = 0; i < 10; i++) { var r = Elo.compute(ea, eb, 32, ph.recent(a, b, now, W), 1); ph.record(a, b, now); ea = r.winnerNew(); eb = r.loserNew(); total += r.winnerDelta(); now += 60_000; }
        int base = 0, xa = 1000, xb = 1000; for (int i = 0; i < 10; i++) { var r = Elo.compute(xa, xb, 32, 0, 1); xa = r.winnerNew(); xb = r.loserNew(); base += r.winnerDelta(); }
        check("kasılma engeli: 10 maçta kazanç engelsiz duruma göre yarıdan az (" + total + " < " + base + "/2)", total > 0 && total < base / 2);
        check("kasılma sonunda kazanç sıfır", Elo.compute(ea, eb, 32, 10, 1).winnerDelta() == 0);
    }
}
