package xyz.doblosmp.game;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

/** Arena sıfırlama: değiştirilen her bloğun İLK hâlini kaydeder ve oyun bitince tick başına sınırlı sayıda geri yazar. */
public final class BlockLog {
    private record Snap(String world, int x, int y, int z, BlockData data) {}
    private final Map<Long, Snap> originals = new LinkedHashMap<>(); private final Set<Long> placed = new HashSet<>();

    static long key(int x, int y, int z) { return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF); }
    public void record(Block b) { originals.putIfAbsent(key(b.getX(), b.getY(), b.getZ()), new Snap(b.getWorld().getName(), b.getX(), b.getY(), b.getZ(), b.getBlockData().clone())); }
    public void recordData(String world, int x, int y, int z, BlockData d) { originals.putIfAbsent(key(x, y, z), new Snap(world, x, y, z, d.clone())); }
    public void recordPlaced(Block b) { placed.add(key(b.getX(), b.getY(), b.getZ())); }
    public boolean isPlaced(Block b) { return placed.contains(key(b.getX(), b.getY(), b.getZ())); }
    public void unplace(Block b) { placed.remove(key(b.getX(), b.getY(), b.getZ())); }
    public int size() { return originals.size(); }

    /** Geri yükleme bitince done çalışır. */
    public void restore(JavaPlugin plugin, int perTick, Runnable done) {
        Iterator<Snap> it = new ArrayList<>(originals.values()).iterator(); originals.clear(); placed.clear();
        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            int n = 0;
            while (it.hasNext() && n++ < perTick) { Snap s = it.next(); World w = Bukkit.getWorld(s.world()); if (w != null) w.getBlockAt(s.x(), s.y(), s.z()).setBlockData(s.data(), false); }
            if (!it.hasNext()) { task.cancel(); if (done != null) done.run(); }
        }, 1L, 1L);
    }
}
