package xyz.doblosmp.glue;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.game.Activities;

import java.util.UUID;

/** Görev ilerlemesi GERÇEK olaylardan gelir: blok kırma/koyma, öldürme, oyunda geçen süre. Oyun modları kendi galibiyet olaylarını Ctx.quest ile bildirir. */
public final class QuestListener implements Listener {
    public QuestListener(JavaPlugin plugin) {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> { for (Player p : Bukkit.getOnlinePlayers()) { Ctx.quest(p.getUniqueId(), "playtime_min", 1);
            if (Ctx.persist != null && Ctx.persist.sql()) { UUID id = p.getUniqueId(); String n = p.getName(); boolean bed = BedrockSupport.isBedrock(p); Ctx.persist.run(() -> { Ctx.persist.store().touchPlayer(id, n, bed, 1); return null; }); } } }, 20L * 60, 20L * 60);
    }
    /** Oyun/ada olayları kendi sayaçlarını tutar; burada yalnızca oyun dışı normal dünya olayları sayılır. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true) public void onBreak(BlockBreakEvent e) { if (!Activities.busy(e.getPlayer().getUniqueId())) Ctx.quest(e.getPlayer().getUniqueId(), "blocks_mined", 1); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true) public void onPlace(BlockPlaceEvent e) { if (!Activities.busy(e.getPlayer().getUniqueId())) Ctx.quest(e.getPlayer().getUniqueId(), "blocks_placed", 1); }
    @EventHandler public void onDeath(PlayerDeathEvent e) { Player k = e.getEntity().getKiller(); if (k != null && !k.equals(e.getEntity()) && !Activities.busy(k.getUniqueId())) Ctx.quest(k.getUniqueId(), "player_kills", 1); }
    @EventHandler public void onJoin(PlayerJoinEvent e) {
        UUID id = e.getPlayer().getUniqueId(); Integer day = Ctx.quests.dailyLogin(id, Ctx.today());
        if (day != null) { long coins = 50L * day; Ctx.ledger.deposit(Ctx.mode("skyblock"), id, coins, "daily-login"); Ctx.quests.of(id).passXp += 20L * day; e.getPlayer().sendMessage("§6Günlük giriş ödülü! Seri: " + day + ". gün → +" + coins + " para, +" + 20 * day + " pass XP"); }
        if (Ctx.quests.grantAchievement(id, "ilk_giris")) e.getPlayer().sendMessage("§a★ Başarım: İlk giriş!");
    }
}
