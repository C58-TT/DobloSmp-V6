package xyz.doblosmp.glue.sky;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.Container;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.*;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.sb.*;

import java.util.*;

/** SkyBlock: /is komutları, void dünya, şablonlar, koruma olayları, sınır, seviye taraması, silme/sıfırlama. Paper'da test EDİLMEDİ. */
public final class Skyblock implements CommandExecutor, Listener {
    public static final class VoidGen extends ChunkGenerator {}                   // hiçbir şey üretmez = void
    private final JavaPlugin plugin; private final IslandRegistry reg; private final int spacing;
    private final Map<Long, Integer> cellSlot = new HashMap<>(); private int built;
    private final Set<UUID> confirm = new HashSet<>(); private final Map<UUID, Long> confirmAt = new HashMap<>();
    private final Random rnd = new Random();

    public Skyblock(JavaPlugin plugin) {
        this.plugin = plugin; this.reg = Ctx.islands; this.spacing = Math.max(420, plugin.getConfig().getInt("skyblock.island-spacing", 512));
    }
    private String worldName() { return plugin.getConfig().getString("skyblock.v2-world", "skyblock_is"); }
    public World world() {
        World w = Bukkit.getWorld(worldName());
        if (w == null) { w = new WorldCreator(worldName()).generator(new VoidGen()).environment(World.Environment.NORMAL).createWorld(); if (w != null) w.setSpawnLocation(0, 100, 0); }
        return w;
    }
    private String mode() { return Ctx.mode("skyblock"); }

    // ---------- geometri ----------
    private static long ck(int x, int z) { return ((long) x << 32) ^ (z & 0xffffffffL); }
    private Island islandAtCell(int gx, int gz) {
        int lim = reg.slotLimit(); for (; built < lim; built++) { int[] c = IslandGrid.cell(built); cellSlot.put(ck(c[0], c[1]), built); }
        Integer slot = cellSlot.get(ck(gx, gz)); return slot == null ? null : reg.bySlot(slot);
    }
    public Island islandAt(Location l) { int[] c = IslandGrid.cellAt(l.getBlockX(), l.getBlockZ(), spacing); return islandAtCell(c[0], c[1]); }
    int[] center(Island i) { return IslandGrid.center(i.slot, spacing); }
    private boolean inSky(Location l) { return l.getWorld() != null && l.getWorld().getName().equals(worldName()); }
    private boolean insideRadius(Island i, Location l) { int[] c = center(i); int r = IslandUpgrades.radius(i); return Math.abs(l.getX() - c[0]) <= r && Math.abs(l.getZ() - c[1]) <= r; }
    public Location home(Island i) { int[] c = center(i); return new Location(world(), c[0] + 0.5 + i.homeX, i.homeY, c[1] + 0.5 + i.homeZ); }

    /** Koruma kararı: ada dışı alanlar (sahipsiz hücre / yarıçap dışı) herkese kapalı, yalnızca bypass yetkisi geçer. */
    private boolean allowed(Player p, Location l, Protection.Action a) {
        if (!inSky(l)) return true; boolean bypass = p.hasPermission("doblo.sky.bypass") || p.hasPermission("doblo.admin");
        if (bypass) return true; Island i = islandAt(l); if (i == null || !insideRadius(i, l)) return false;
        return Protection.allowed(i, p.getUniqueId(), a, false);
    }
    private void deny(Player p) { p.sendMessage("§cBu ada alanında bunu yapamazsın."); }

    // ---------- şablon, temizlik ----------
    private void build(Island i) {
        World w = world(); int[] c = center(i); int cx = c[0], cz = c[1];
        boolean desert = i.template.equals("desert");
        Material top = desert ? Material.SAND : Material.GRASS_BLOCK, mid = desert ? Material.SAND : Material.DIRT;
        for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) { w.getBlockAt(cx + dx, 63, cz + dz).setType(top); w.getBlockAt(cx + dx, 62, cz + dz).setType(mid); if (Math.abs(dx) <= 2 && Math.abs(dz) <= 2) w.getBlockAt(cx + dx, 61, cz + dz).setType(mid); }
        w.getBlockAt(cx, 60, cz).setType(Material.BEDROCK);
        { for (int y = 64; y <= 67; y++) w.getBlockAt(cx + 2, y, cz + 2).setType(Material.OAK_LOG);
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int y = 66; y <= 68; y++) if (!(dx == 0 && dz == 0 && y < 68) && (Math.abs(dx) + Math.abs(dz) < 4)) { Block b = w.getBlockAt(cx + 2 + dx, y, cz + 2 + dz); if (b.getType() == Material.AIR) b.setType(Material.OAK_LEAVES); } }
        Block chest = w.getBlockAt(cx, 64, cz + 2); chest.setType(Material.CHEST);
        w.getBlockAt(cx + 1, 64, cz + 2).setType(Material.CRAFTING_TABLE);
        // Başlangıç sandığı YALNIZCA: 1 Lava Bucket, 1 Water Bucket, 2 Sapling
        BlockState st = chest.getState(); if (st instanceof Chest ch) { ch.getBlockInventory().clear(); ch.getBlockInventory().addItem(new ItemStack(Material.LAVA_BUCKET), new ItemStack(Material.WATER_BUCKET), new ItemStack(Material.OAK_SAPLING, 2)); }
    }
    private void spawnAway(Island i) {
        World w = world(); int[] c = center(i); int r = Math.max(50, IslandUpgrades.radius(i));
        for (Player p : w.getPlayers()) if (Math.abs(p.getX() - c[0]) <= r && Math.abs(p.getZ() - c[1]) <= r) p.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
    }
    /** Alanı chunk chunk (tick başına 2) temizler; bitince done. Oyuncu olmayan varlıklar da silinir. */
    private void clear(int cx, int cz, int radius, Runnable done) {
        World w = world(); int x0 = (cx - radius) >> 4, x1 = (cx + radius) >> 4, z0 = (cz - radius) >> 4, z1 = (cz + radius) >> 4;
        List<int[]> chunks = new ArrayList<>(); for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) chunks.add(new int[]{x, z});
        Iterator<int[]> it = chunks.iterator(); int min = w.getMinHeight(), max = w.getMaxHeight();
        Bukkit.getScheduler().runTaskTimer(plugin, t -> {
            for (int n = 0; n < 2 && it.hasNext(); n++) {
                int[] ch = it.next(); Chunk c = w.getChunkAt(ch[0], ch[1]);
                for (Entity e : c.getEntities()) if (!(e instanceof Player)) e.remove();
                var snap = c.getChunkSnapshot(false, false, false);
                for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) { int wx = (ch[0] << 4) + x, wz = (ch[1] << 4) + z; if (Math.abs(wx - cx) > radius || Math.abs(wz - cz) > radius) continue;
                    for (int y = min; y < max; y++) if (!snap.getBlockType(x, y, z).isAir()) w.getBlockAt(wx, y, wz).setType(Material.AIR, false); }
            }
            if (!it.hasNext()) { t.cancel(); if (done != null) done.run(); }
        }, 1L, 1L);
    }

    private List<UUID> members(Island i) { List<UUID> l = new ArrayList<>(i.members.keySet()); l.add(i.owner); return l; }
    private static String name(UUID id) { var p = Bukkit.getOfflinePlayer(id); return p.getName() == null ? id.toString().substring(0, 8) : p.getName(); }
    private UUID find(String n) { Player p = Bukkit.getPlayerExact(n); if (p != null) return p.getUniqueId(); var op = Bukkit.getOfflinePlayerIfCached(n); return op == null ? null : op.getUniqueId(); }

    private boolean confirmed(Player p, String what) {
        long now = System.currentTimeMillis();
        if (confirm.contains(p.getUniqueId()) && now - confirmAt.getOrDefault(p.getUniqueId(), 0L) < 30_000) { confirm.remove(p.getUniqueId()); return true; }
        confirm.add(p.getUniqueId()); confirmAt.put(p.getUniqueId(), now); p.sendMessage("§cEmin misin? 30 saniye içinde aynı komutu tekrar yaz: §f/is " + what); return false;
    }
    private boolean fail(Player p, IslandRegistry.Result r) {
        String m = switch (r) { case OK -> null; case HAS_ISLAND -> "Zaten bir adan var."; case NO_ISLAND -> "Bir adan yok."; case NOT_OWNER -> "Bunu yalnızca ada sahibi yapabilir."; case NO_PERMISSION -> "Yetkin yok.";
            case TARGET_HAS_ISLAND -> "Hedef oyuncunun zaten bir adası var."; case ALREADY_MEMBER -> "Zaten üye."; case NOT_MEMBER -> "Bu oyuncu üye/uygun değil."; case FULL -> "Ada üye sınırına ulaştı (/is upgrade members).";
            case NO_INVITE -> "Geçerli bir davetin yok."; case BANNED -> "Bu adadan yasaklısın/hedef yasaklı."; case SELF -> "Kendin üzerinde yapamazsın."; case COOLDOWN -> "Bekleme süresi dolmadı / bakiye yetersiz.";
            case UNKNOWN_TEMPLATE -> "Bilinmeyen şablon."; case INVALID -> "Geçersiz işlem."; };
        if (m != null) p.sendMessage("§c" + m); return m != null;
    }

    // ---------- komut ----------
    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Oyuncu komutu."); return true; }
        UUID id = p.getUniqueId(); Island mine = reg.islandOf(id); String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT); sub = switch (sub) { case "olustur", "oluştur" -> "create"; case "ev" -> "home"; case "davet" -> "invite"; case "kabul" -> "accept"; case "ziyaret" -> "visit"; case "ayarlar" -> "settings"; case "market" -> "shop"; case "bilgi" -> "info"; case "at" -> "kick"; case "sil" -> "delete"; default -> sub; }; long now = System.currentTimeMillis();
        if (world() == null) { p.sendMessage("§cSkyBlock dünyası oluşturulamadı."); return true; }
        switch (sub) {
            case "" -> adaMenu(p, mine);
            case "shop" -> xyz.doblosmp.gui.SkyShopMenu.open(p);
            case "help" -> p.sendMessage("§e/is create [classic|desert] shop home sethome invite accept kick leave delete reset visit ban unban settings members role transfer rate info");
            case "create" -> { String t = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "classic"; IslandRegistry.Result[] o = new IslandRegistry.Result[1]; Island i = reg.create(id, t, o);
                if (fail(p, o[0])) return true; build(i); p.teleport(home(i)); p.sendMessage("§aAdan oluşturuldu!"); Ctx.quest(id, "island_created", 1); Ctx.quests.grantAchievement(id, "ilk_ada"); Ctx.persist.saveAsync(); }
            case "home" -> { if (mine == null) { p.sendMessage("§cÖnce /is create"); return true; } p.teleport(home(mine)); }
            case "sethome" -> { if (mine == null) { p.sendMessage("§cAdan yok."); return true; } int[] c0 = center(mine); Location lo = p.getLocation();
                if (!inSky(lo) || fail(p, reg.setHome(id, lo.getX() - c0[0] - 0.5, lo.getY(), lo.getZ() - c0[1] - 0.5, IslandUpgrades.radius(mine)))) { if (!inSky(lo)) p.sendMessage("§cAda dünyasında olmalısın."); return true; } p.sendMessage("§aAda evi ayarlandı."); }
            case "invite" -> { UUID t = a.length > 1 ? find(a[1]) : null; Player tp = t == null ? null : Bukkit.getPlayer(t); if (tp == null) { p.sendMessage("§c/is invite <çevrimiçi oyuncu>"); return true; }
                if (fail(p, reg.invite(id, t, now))) return true; tp.sendMessage("§e" + p.getName() + " seni adasına davet etti: /is accept"); p.sendMessage("§aDavet gönderildi."); }
            case "accept" -> { if (fail(p, reg.accept(id, now))) return true; p.sendMessage("§aAdaya katıldın."); Island i = reg.islandOf(id); p.teleport(home(i)); Player ow = Bukkit.getPlayer(i.owner); if (ow != null) ow.sendMessage("§a" + p.getName() + " adana katıldı."); }
            case "kick" -> { UUID t = a.length > 1 ? find(a[1]) : null; if (t == null) { p.sendMessage("§c/is kick <oyuncu>"); return true; } if (fail(p, reg.kick(id, t))) return true; p.sendMessage("§aÜye çıkarıldı."); Player tp = Bukkit.getPlayer(t); if (tp != null) { tp.sendMessage("§cAdadan çıkarıldın."); if (inSky(tp.getLocation())) tp.teleport(Bukkit.getWorlds().get(0).getSpawnLocation()); } }
            case "leave" -> { if (fail(p, reg.leave(id))) return true; p.sendMessage("§eAdadan ayrıldın."); if (inSky(p.getLocation())) p.teleport(Bukkit.getWorlds().get(0).getSpawnLocation()); }
            case "delete" -> { if (mine == null) { p.sendMessage("§cAdan yok."); return true; } if (!mine.owner.equals(id)) { p.sendMessage("§cYalnızca sahip."); return true; } if (!confirmed(p, "delete")) return true;
                int[] c0 = center(mine); int r = Math.max(50, IslandUpgrades.radius(mine)); spawnAway(mine); if (fail(p, reg.delete(id))) return true; clear(c0[0], c0[1], r, null); p.sendMessage("§eAda silindi, alan temizleniyor."); Ctx.persist.saveAsync(); }
            case "reset" -> { if (mine == null) { p.sendMessage("§cAdan yok."); return true; } if (!mine.owner.equals(id)) { p.sendMessage("§cYalnızca sahip."); return true; } if (!confirmed(p, "reset")) return true;
                int[] c0 = center(mine); int r = Math.max(50, IslandUpgrades.radius(mine)); Island i = mine; spawnAway(i);
                if (fail(p, reg.reset(id, now))) return true; p.sendMessage("§eAda sıfırlanıyor...");
                clear(c0[0], c0[1], r, () -> { build(i); for (UUID u : members(i)) { Player m = Bukkit.getPlayer(u); if (m != null) m.teleport(home(i)); } p.sendMessage("§aAda yeniden kuruldu."); Ctx.persist.saveAsync(); }); }
            case "visit" -> { UUID t = a.length > 1 ? find(a[1]) : null; Island ti = t == null ? null : reg.islandOf(t); if (ti == null) { p.sendMessage("§cBu oyuncunun adası yok."); return true; }
                if (fail(p, reg.canVisit(id, ti))) return true; p.teleport(home(ti)); p.sendMessage("§aZiyaret ediyorsun: " + name(ti.owner)); Ctx.quest(id, "island_visit", 1);
                Player ow = Bukkit.getPlayer(ti.owner); if (ow != null && !ti.members.containsKey(id) && Ctx.plugin.getConfig().getBoolean("skyblock.notify-visits", true)) ow.sendMessage("§7" + p.getName() + " adanı ziyaret ediyor."); }
            case "ban", "unban" -> { UUID t = a.length > 1 ? find(a[1]) : null; if (t == null) { p.sendMessage("§c/is " + sub + " <oyuncu>"); return true; }
                if (fail(p, sub.equals("ban") ? reg.ban(id, t) : reg.unban(id, t))) return true; p.sendMessage("§aTamam."); Player tp = Bukkit.getPlayer(t);
                if (sub.equals("ban") && tp != null && mine != null && inSky(tp.getLocation()) && islandAt(tp.getLocation()) == mine) { tp.teleport(Bukkit.getWorlds().get(0).getSpawnLocation()); tp.sendMessage("§cBu adadan yasaklandın."); } }
            case "settings" -> settings(p, mine, a);
            case "members" -> { if (mine == null) { p.sendMessage("§cAdan yok."); return true; } p.sendMessage("§6Sahip: §f" + name(mine.owner)); mine.members.forEach((u, r) -> p.sendMessage("§7" + r + " §f" + name(u))); }
            case "role" -> { UUID t = a.length > 2 ? find(a[1]) : null; Role r; try { r = Role.valueOf(a.length > 2 ? a[2].toUpperCase(Locale.ROOT) : ""); } catch (IllegalArgumentException e) { p.sendMessage("§c/is role <oyuncu> <MEMBER|MODERATOR>"); return true; }
                if (t == null || fail(p, reg.setRole(id, t, r))) return true; p.sendMessage("§aRol verildi."); }
            case "transfer" -> { UUID t = a.length > 1 ? find(a[1]) : null; if (t == null) { p.sendMessage("§c/is transfer <üye>"); return true; } if (!confirmed(p, "transfer " + a[1])) return true; if (fail(p, reg.transfer(id, t))) return true; p.sendMessage("§aLiderlik devredildi."); Ctx.persist.saveAsync(); }
            case "rate" -> { UUID t = a.length > 2 ? find(a[1]) : null; Island ti = t == null ? null : reg.islandOf(t); int sc; try { sc = Integer.parseInt(a.length > 2 ? a[2] : "x"); } catch (NumberFormatException e) { p.sendMessage("§c/is rate <oyuncu> <1-5>"); return true; }
                if (ti == null || fail(p, reg.rate(id, ti, sc))) return true; p.sendMessage("§aPuanın kaydedildi."); }
            case "info" -> { Island i = mine; if (i == null) { p.sendMessage("§cAdan yok."); return true; } p.sendMessage("§bAda #" + i.id + " §7| Sahip: " + name(i.owner) + " | Yarıçap " + IslandUpgrades.radius(i) + " | Üye " + i.memberCount() + "/" + IslandUpgrades.memberLimit(i) + " | ★" + String.format("%.1f", i.avgRating())); }
            default -> p.sendMessage("§c/is help");
        }
        return true;
    }

    /** /ada ve /island: ada ana menüsü. Her düğme gerçek bir işleve bağlıdır (market yalnızca /ada shop ile açılır). */
    private void adaMenu(Player p, Island mine) {
        xyz.doblosmp.gui.Menu m = new xyz.doblosmp.gui.Menu("§a§lAda Menüsü", 3);
        if (mine == null) {
            m.set(11, xyz.doblosmp.gui.Menu.item(Material.GRASS_BLOCK, "§aAda Oluştur", "§7Kendi adanı kur"), pl -> { pl.closeInventory(); pl.performCommand("ada create"); });
        } else {
            m.set(10, xyz.doblosmp.gui.Menu.item(Material.GRASS_BLOCK, "§aAdama Git", "§7Ada evine ışınlan"), pl -> { pl.closeInventory(); pl.performCommand("ada home"); });
            m.set(12, xyz.doblosmp.gui.Menu.item(Material.PLAYER_HEAD, "§bÜyeler", "§7Ada üye sayısı: §f" + mine.memberCount()), pl -> { pl.closeInventory(); pl.performCommand("is members"); });
            m.set(14, xyz.doblosmp.gui.Menu.item(Material.COMPARATOR, "§eAyarlar", "§7Ada izinleri ve ziyaretçi ayarları"), pl -> { pl.closeInventory(); pl.performCommand("ada settings"); });
            m.set(16, xyz.doblosmp.gui.Menu.item(Material.OAK_DOOR, "§7Evi Ayarla", "§7Bulunduğun konumu ada evi yap"), pl -> { pl.closeInventory(); pl.performCommand("is sethome"); });
        }
        m.fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }
    private void settings(Player p, Island mine, String[] a) {
        if (mine == null) { p.sendMessage("§cAdan yok."); return; }
        if (a.length == 1) { mine.flags.forEach((k, v) -> p.sendMessage("§7" + k + ": " + (v ? "§aaçık" : "§ckapalı"))); for (Perm pm : Perm.values()) p.sendMessage("§7izin " + pm + " ≥ §f" + mine.need(pm)); p.sendMessage("§e/is settings <ayar> <on|off>  veya  /is settings perm <İZİN> <ROL>"); return; }
        if (a[1].equalsIgnoreCase("perm") && a.length >= 4) { try { if (!fail(p, reg.setRequired(p.getUniqueId(), Perm.valueOf(a[2].toUpperCase(Locale.ROOT)), Role.valueOf(a[3].toUpperCase(Locale.ROOT))))) p.sendMessage("§aİzin güncellendi."); } catch (IllegalArgumentException e) { p.sendMessage("§cGeçersiz izin/rol."); } return; }
        if (a.length >= 3 && !fail(p, reg.setFlag(p.getUniqueId(), a[1].toLowerCase(Locale.ROOT), a[2].equalsIgnoreCase("on")))) p.sendMessage("§aAyar güncellendi.");
    }

    // ---------- olaylar ----------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onBreak(BlockBreakEvent e) { if (!allowed(e.getPlayer(), e.getBlock().getLocation(), e.getBlock().getBlockData() instanceof org.bukkit.block.data.Ageable ? Protection.Action.FARM : Protection.Action.BREAK)) { e.setCancelled(true); deny(e.getPlayer()); } }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onPlace(BlockPlaceEvent e) {
        if (!allowed(e.getPlayer(), e.getBlock().getLocation(), Protection.Action.PLACE)) { e.setCancelled(true); deny(e.getPlayer()); return; }
        if (inSky(e.getBlock().getLocation())) Ctx.quest(e.getPlayer().getUniqueId(), "island_blocks_placed", 1);
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onBucket(PlayerBucketEmptyEvent e) { if (!allowed(e.getPlayer(), e.getBlock().getLocation(), Protection.Action.PLACE)) { e.setCancelled(true); deny(e.getPlayer()); } }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onBucketFill(PlayerBucketFillEvent e) { if (!allowed(e.getPlayer(), e.getBlock().getLocation(), Protection.Action.BREAK)) { e.setCancelled(true); deny(e.getPlayer()); } }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onInteract(PlayerInteractEvent e) {
        Block b = e.getClickedBlock(); if (b == null || !inSky(b.getLocation())) return; Player p = e.getPlayer(); Protection.Action act = null;
        if (e.getAction() == Action.PHYSICAL) { if (b.getType() == Material.FARMLAND) act = Protection.Action.FARM; }
        else if (e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Material m = b.getType();
            if (Tag.DOORS.isTagged(m) || Tag.TRAPDOORS.isTagged(m) || Tag.FENCE_GATES.isTagged(m) || Tag.BUTTONS.isTagged(m) || m == Material.LEVER) act = Protection.Action.DOOR;
            else if (b.getState() instanceof Container) act = Protection.Action.CONTAINER;
            else if (m == Material.CRAFTING_TABLE || m == Material.ENCHANTING_TABLE || m == Material.ANVIL) act = null;
            else act = Protection.Action.PLACE;                                 // diğer etkileşimler (kova, tohum, boya...) yerleştirme izni ister
        }
        if (act != null && !allowed(p, b.getLocation(), act)) { e.setCancelled(true); if (act != Protection.Action.FARM) deny(p); }
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onEntityInteract(PlayerInteractEntityEvent e) {
        Entity t = e.getRightClicked(); if (t instanceof Player || t instanceof Villager v && !v.hasAI()) return;     // NPC'ler (AI kapalı) korumadan muaf
        if (!allowed(e.getPlayer(), t.getLocation(), t instanceof Monster ? Protection.Action.PVP : Protection.Action.ANIMAL)) { e.setCancelled(true); deny(e.getPlayer()); }
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onDamage(EntityDamageByEntityEvent e) {
        if (!inSky(e.getEntity().getLocation())) return; Player p = e.getDamager() instanceof Player pl ? pl : (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player sh ? sh : null);
        if (p == null || p.hasPermission("doblo.admin")) return; Entity v = e.getEntity();
        if (v instanceof Player vp) { Island i = islandAt(vp.getLocation()); if (i == null || !Protection.allowed(i, p.getUniqueId(), Protection.Action.PVP, false)) { e.setCancelled(true); p.sendMessage("§cBu adada PvP kapalı."); } }
        else if (!(v instanceof Monster) && !allowed(p, v.getLocation(), Protection.Action.ANIMAL)) { e.setCancelled(true); deny(p); }
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onExplode(EntityExplodeEvent e) { if (inSky(e.getLocation())) e.blockList().clear(); }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onBlockExplode(BlockExplodeEvent e) { if (inSky(e.getBlock().getLocation())) e.blockList().clear(); }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onHopper(InventoryMoveItemEvent e) {
        Location a = e.getSource().getLocation(), b = e.getDestination().getLocation(); if (a == null || b == null || !inSky(a)) return; if (islandAt(a) != islandAt(b)) e.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onFlow(BlockFromToEvent e) { if (inSky(e.getBlock().getLocation()) && islandAt(e.getBlock().getLocation()) != islandAt(e.getToBlock().getLocation())) e.setCancelled(true); }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onSpawn(CreatureSpawnEvent e) {
        if (!inSky(e.getLocation()) || e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.CUSTOM || e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG) return;
        Island i = islandAt(e.getLocation()); if (i == null || !i.flags.getOrDefault("mob_spawning", true) && e.getEntity() instanceof Monster) e.setCancelled(true);
    }
    @EventHandler(ignoreCancelled = true) public void onMove(PlayerMoveEvent e) {
        if (e.getTo() == null || !inSky(e.getTo()) || e.getFrom().getBlockX() == e.getTo().getBlockX() && e.getFrom().getBlockZ() == e.getTo().getBlockZ() && e.getFrom().getBlockY() == e.getTo().getBlockY()) return;
        Player p = e.getPlayer(); if (e.getTo().getY() < world().getMinHeight() + 4) { Island m = reg.islandOf(p.getUniqueId()); p.setFallDistance(0); p.teleport(m != null ? home(m) : Bukkit.getWorlds().get(0).getSpawnLocation()); return; }
        if (p.hasPermission("doblo.admin")) return; Island i = islandAt(e.getTo());
        if (i != null && insideRadius(i, e.getTo())) { if (i.bans.contains(p.getUniqueId())) { e.setTo(e.getFrom()); p.sendMessage("§cBu adadan yasaklısın."); } }
        else if (i != null) { e.setTo(e.getFrom()); p.sendMessage("§cAda sınırına ulaştın."); }
    }
    @EventHandler(ignoreCancelled = true) public void onTeleport(PlayerTeleportEvent e) {
        Location t = e.getTo(); if (t == null || !inSky(t) || e.getPlayer().hasPermission("doblo.admin")) return; Island i = islandAt(t);
        if (i != null && i.bans.contains(e.getPlayer().getUniqueId())) { e.setCancelled(true); e.getPlayer().sendMessage("§cBu adadan yasaklısın."); }
    }
}
