package xyz.doblosmp.glue;

import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.discord.DiscordNotifier;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** Mute, geçici ban, ceza geçmişi, oyuncu raporları. YAML birincil; MariaDB açıksa SQL'e de yazılır. Discord bildirimi içerir. */
public final class Punishments implements Listener {
    private final JavaPlugin plugin; private final File file;
    private final Map<String, Long> mutes = new ConcurrentHashMap<>(), tempBans = new ConcurrentHashMap<>();     // küçük harf ad -> bitiş ms (0 = kalıcı mute)
    private final List<Map<String, Object>> history = new CopyOnWriteArrayList<>(), reports = new CopyOnWriteArrayList<>();

    public Punishments(JavaPlugin plugin) {
        this.plugin = plugin; this.file = new File(plugin.getDataFolder(), "punishments.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        var ms = y.getConfigurationSection("mutes"); if (ms != null) for (String k : ms.getKeys(false)) mutes.put(k, ms.getLong(k));
        var tb = y.getConfigurationSection("tempbans"); if (tb != null) for (String k : tb.getKeys(false)) tempBans.put(k, tb.getLong(k));
        for (var m : y.getMapList("history")) history.add(new LinkedHashMap<>(castMap(m)));
        for (var m : y.getMapList("reports")) reports.add(new LinkedHashMap<>(castMap(m)));
    }
    @SuppressWarnings("unchecked") private static Map<String, Object> castMap(Map<?, ?> m) { return (Map<String, Object>) m; }

    public synchronized void save() {
        YamlConfiguration y = new YamlConfiguration();
        mutes.forEach((k, v) -> y.set("mutes." + k, v)); tempBans.forEach((k, v) -> y.set("tempbans." + k, v));
        y.set("history", new ArrayList<>(history)); y.set("reports", new ArrayList<>(reports));
        try { plugin.getDataFolder().mkdirs(); File tmp = new File(plugin.getDataFolder(), "punishments.yml.tmp"); y.save(tmp);
            java.nio.file.Files.move(tmp.toPath(), file.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
        catch (IOException e) { plugin.getLogger().severe("Ceza kaydı yazılamadı: " + e.getMessage()); }
    }
    public static String clean(String s) { return s.replaceAll("[\\r\\n§]", " ").trim(); }

    public void record(String type, String player, String reason, long seconds, String staff) {
        Map<String, Object> e = new LinkedHashMap<>(); long now = System.currentTimeMillis(); String r = clean(reason);
        e.put("time", now); e.put("type", type); e.put("player", player); e.put("reason", r); e.put("seconds", seconds); e.put("staff", staff);
        history.add(e); save();
        if (Ctx.persist != null && Ctx.persist.sql()) Ctx.persist.run(() -> { Ctx.persist.store().addPunishment(now, type, player, r, seconds, staff); return null; });
        Ctx.discord(DiscordNotifier.Kind.MOD, "Ceza: " + type.toUpperCase(Locale.ROOT), "**Oyuncu:** " + player + "\n**Yetkili:** " + staff + "\n**Süre:** " + (seconds <= 0 ? "kalıcı" : seconds + " sn") + "\n**Sebep:** " + r);
    }
    public void mute(String player, long seconds) { long until = seconds <= 0 ? 0L : System.currentTimeMillis() + seconds * 1000L; mutes.put(player.toLowerCase(Locale.ROOT), until); save();
        if (Ctx.persist != null && Ctx.persist.sql()) Ctx.persist.run(() -> { Ctx.persist.store().setMute(player, until); return null; }); }
    public void unmute(String player) { mutes.remove(player.toLowerCase(Locale.ROOT)); save(); if (Ctx.persist != null && Ctx.persist.sql()) Ctx.persist.run(() -> { Ctx.persist.store().setMute(player, -1); return null; }); }
    public boolean isMuted(String player) {
        Long until = mutes.get(player.toLowerCase(Locale.ROOT)); if (until == null) return false;
        if (until != 0 && until < System.currentTimeMillis()) { mutes.remove(player.toLowerCase(Locale.ROOT)); return false; } return true;
    }
    public void tempBan(String player, long seconds) { tempBans.put(player.toLowerCase(Locale.ROOT), System.currentTimeMillis() + seconds * 1000L); save(); }
    public void unTempBan(String player) { tempBans.remove(player.toLowerCase(Locale.ROOT)); save(); }
    public long bannedUntil(String player) { Long u = tempBans.get(player.toLowerCase(Locale.ROOT)); if (u == null) return 0; if (u < System.currentTimeMillis()) { tempBans.remove(player.toLowerCase(Locale.ROOT)); return 0; } return u; }

    public List<Map<String, Object>> history(String player) {
        if (player == null || player.isBlank()) return history.subList(Math.max(0, history.size() - 100), history.size());
        return history.stream().filter(m -> player.equalsIgnoreCase(String.valueOf(m.get("player")))).toList();
    }
    public void report(String reporter, String target, String reason) {
        Map<String, Object> e = new LinkedHashMap<>(); e.put("time", System.currentTimeMillis()); e.put("reporter", reporter); e.put("target", target); e.put("reason", clean(reason));
        reports.add(e); save(); Ctx.discord(DiscordNotifier.Kind.WARN, "Yeni rapor", "**Raporlayan:** " + reporter + "\n**Hedef:** " + target + "\n**Sebep:** " + clean(reason));
    }
    public List<Map<String, Object>> reports() { return new ArrayList<>(reports); }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true) @SuppressWarnings("deprecation")
    public void onChat(AsyncPlayerChatEvent e) { if (isMuted(e.getPlayer().getName())) { e.setCancelled(true); e.getPlayer().sendMessage("§cSusturulmuşsun."); } }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        long until = bannedUntil(e.getName()); if (until == 0) return;
        e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, Component.text("Geçici olarak yasaklısın. Kalan: " + Math.max(1, (until - System.currentTimeMillis()) / 60000) + " dakika."));
    }
}
