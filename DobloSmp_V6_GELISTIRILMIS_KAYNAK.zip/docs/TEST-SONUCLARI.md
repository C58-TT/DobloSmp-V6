# V6 test sonuçları

Bu çalışma oturumunda Java 21 ile bağımsız çekirdek testleri derlenip çalıştırıldı:
- `CoreTests`: 111 geçti / 0 kaldı.
- `NewTestsWithoutDb`: 91 geçti / 0 kaldı. Bu koşucu, H2 JDBC sürücüsü ortamda bulunmadığı için yalnızca DB entegrasyon testini atlar; kaynak test dosyasının kendisi değiştirilmemiştir.
- `scripts/install-lobby.sh`: `bash -n` sözdizimi kontrolü geçti.
- `config.yml` ve `plugin.yml`: YAML ayrıştırma kontrolü geçti.

**Henüz doğrulanmayanlar:**
- Maven derlemesi yapılamadı: bu ortamda Maven kurulu değil ve PaperMC Maven deposuna DNS/ağ erişimi yok.
- Bu nedenle tüm Bukkit/Paper sınıfları, NPC değişiklikleri ve JAR çıktısı Paper 1.21.11 üzerinde derlenmiş/çalıştırılmış sayılmaz.
- MariaDB/H2 veritabanı entegrasyonu, gerçek oyuncular, oyun modlarının uçtan uca akışı, Bedrock, Geyser ve performans/yük testi yapılmadı.

Önceki V5 test raporları V6'nın tam Paper uyumluluğunu kanıtlamaz.
