# Paper optimizasyon önerileri (uygulanmadı, elle yapılır — config/paper-world-defaults.yml)
- `chunks.delay-chunk-unloads-by: 10s`
- `entities.spawning.per-player-mob-spawns: true`, `entities.spawning.spawn-limits`: monster 50, animals 8, water-animals 3, ambient 1
- `entities.behavior.disable-chest-cat-detection: true`
- `environment.optimize-explosions: true`, `hopper.disable-move-event: false` (SkyBlock hopper koruması MoveItemEvent kullanır)
- `server.properties`: `view-distance=8`, `simulation-distance=6`, `network-compression-threshold=256`
- BedWars/Duels/Murder arenalarını tek dünyada, birbirinden en az 300 blok uzakta kur.
