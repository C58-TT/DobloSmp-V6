package xyz.doblosmp.bedwars;

import java.util.*;

/**
 * BedWars saf maç motoru: takım atama, yatak, yeniden doğma, eleme, kazanan, kaynak üreticileri,
 * mağaza ve takım yükseltmeleri. Dünya/envanter işlemleri Paper tarafında (BedwarsListener) uygulanır.
 */
public final class BedwarsMatch {
    public enum State { WAITING, COUNTDOWN, RUNNING, ENDING }
    public static final String[] TEAM_NAMES = {"Mavi", "Kırmızı", "Sarı", "Mor", "Yeşil", "Koyu Yeşil", "Siyah", "Gri"};

    public enum Res { IRON, GOLD, DIAMOND, EMERALD }

    public record Item(String id, Res cost, int price) {}
    /** Mağaza kataloğu (sunucu tarafında sabit; istemciden fiyat alınmaz). */
    public static final Map<String, Item> SHOP = new LinkedHashMap<>();
    static {
        for (Item i : List.of(
                new Item("WOOL16", Res.IRON, 4), new Item("CLAY16", Res.IRON, 12), new Item("GLASS4", Res.IRON, 12),
                new Item("END_STONE12", Res.IRON, 24), new Item("LADDER8", Res.IRON, 4), new Item("WOOD_PLANKS16", Res.GOLD, 4), new Item("OBSIDIAN4", Res.EMERALD, 4),
                new Item("STONE_SWORD", Res.IRON, 10), new Item("IRON_SWORD", Res.GOLD, 7), new Item("DIAMOND_SWORD", Res.EMERALD, 4),
                new Item("CHAIN_ARMOR", Res.IRON, 24), new Item("IRON_ARMOR", Res.GOLD, 12), new Item("DIAMOND_ARMOR", Res.EMERALD, 6),
                new Item("SHEARS", Res.IRON, 20),
                new Item("PICKAXE_WOOD", Res.IRON, 10), new Item("PICKAXE_IRON", Res.IRON, 10), new Item("PICKAXE_GOLD", Res.GOLD, 3), new Item("PICKAXE_DIAMOND", Res.GOLD, 6),
                new Item("AXE_WOOD", Res.IRON, 10), new Item("AXE_STONE", Res.IRON, 10), new Item("AXE_IRON", Res.GOLD, 3), new Item("AXE_DIAMOND", Res.GOLD, 6),
                new Item("ARROW8", Res.GOLD, 2), new Item("BOW", Res.GOLD, 12), new Item("BOW_POWER", Res.GOLD, 24), new Item("BOW_POWER_PUNCH", Res.EMERALD, 6),
                new Item("POTION_SPEED", Res.EMERALD, 1), new Item("POTION_JUMP", Res.EMERALD, 1), new Item("POTION_INVIS", Res.EMERALD, 2),
                new Item("GOLDEN_APPLE", Res.GOLD, 3), new Item("BEDBUG", Res.IRON, 30), new Item("DREAM_DEFENDER", Res.IRON, 120),
                new Item("FIREBALL", Res.IRON, 40), new Item("TNT", Res.GOLD, 4), new Item("ENDER_PEARL", Res.EMERALD, 4),
                new Item("WATER_BUCKET", Res.GOLD, 3), new Item("BRIDGE_EGG", Res.EMERALD, 2), new Item("MAGIC_MILK", Res.GOLD, 4),
                new Item("SPONGE4", Res.GOLD, 3), new Item("POPUP_TOWER", Res.IRON, 24))) SHOP.put(i.id(), i);
    }

    public static final class Team {
        public final int index; public final String name;
        public final Set<UUID> members = new LinkedHashSet<>(), alive = new HashSet<>();
        public boolean bed = true;
        public int sharpness, protection, haste, forge;
        Team(int i) { index = i; name = TEAM_NAMES[i % TEAM_NAMES.length]; }
        public boolean eliminated() { return !bed && alive.isEmpty(); }
    }

    public final BedwarsMode mode;
    private final List<Team> teams = new ArrayList<>();
    private final Map<UUID, Team> byPlayer = new HashMap<>();
    private final Map<UUID, EnumMap<Res, Integer>> wallets = new HashMap<>();
    private final Map<UUID, int[]> stats = new HashMap<>(); // kills, finalKills, beds, deaths
    private State state = State.WAITING;
    private Team winner;
    private final Set<UUID> spectators = new HashSet<>();

    public BedwarsMatch(BedwarsMode mode) {
        this.mode = mode;
        for (int i = 0; i < mode.teams; i++) teams.add(new Team(i));
    }

    public State state() { return state; }
    public List<Team> teams() { return teams; }
    public Team winner() { return winner; }
    public Team teamOf(UUID p) { return byPlayer.get(p); }
    public boolean isSpectator(UUID p) { return spectators.contains(p); }
    public int playerCount() { return byPlayer.size(); }
    public int[] stats(UUID p) { return stats.getOrDefault(p, new int[4]); }

    /** Oyuncu ekle: tercih edilen takım doluysa en boş takıma atanır. */
    public boolean join(UUID p, Integer preferred) {
        if (state != State.WAITING && state != State.COUNTDOWN || byPlayer.containsKey(p) || playerCount() >= mode.capacity()) return false;
        Team t = null;
        if (preferred != null && preferred >= 0 && preferred < teams.size() && teams.get(preferred).members.size() < mode.perTeam)
            t = teams.get(preferred);
        if (t == null) t = teams.stream().filter(x -> x.members.size() < mode.perTeam)
                .min(Comparator.comparingInt(x -> x.members.size())).orElse(null);
        if (t == null) return false;
        t.members.add(p); byPlayer.put(p, t); stats.put(p, new int[4]);
        wallets.put(p, new EnumMap<>(Res.class));
        return true;
    }

    /** Bekleme/geri sayım sırasında takım değiştirme (dolu takıma geçilemez). */
    public boolean switchTeam(UUID p, int teamIndex) {
        Team old = byPlayer.get(p);
        if (old == null || (state != State.WAITING && state != State.COUNTDOWN) || teamIndex < 0 || teamIndex >= teams.size()) return false;
        Team t = teams.get(teamIndex);
        if (t == old || t.members.size() >= mode.perTeam) return false;
        old.members.remove(p); t.members.add(p); byPlayer.put(p, t); return true;
    }

    public void leave(UUID p) {
        Team t = byPlayer.get(p);
        if (t == null) { spectators.remove(p); return; }
        if (state == State.WAITING || state == State.COUNTDOWN) { t.members.remove(p); byPlayer.remove(p); return; }
        t.alive.remove(p); evaluate();
    }

    public boolean canStart(int minPlayers) {
        long used = teams.stream().filter(t -> !t.members.isEmpty()).count();
        return playerCount() == mode.capacity() && used == mode.teams && mode == BedwarsMode.SOLO;
    }

    public boolean startCountdown(int minPlayers) {
        if (state != State.WAITING || !canStart(minPlayers)) return false;
        state = State.COUNTDOWN; return true;
    }
    /** Geri sayım iptal (oyuncu sayısı düştü). */
    public void abortCountdown(int minPlayers) { if (state == State.COUNTDOWN && !canStart(minPlayers)) state = State.WAITING; }

    public boolean begin() {
        if (state != State.COUNTDOWN) return false;
        for (Team t : teams) { t.alive.addAll(t.members); t.bed = !t.members.isEmpty(); }
        state = State.RUNNING; return true;
    }

    /** Yatak kırma. Kendi yatağını kıramaz; kırılan takımın oyuncuları artık yeniden doğamaz. */
    public boolean breakBed(UUID breaker, int victimTeam) {
        if (state != State.RUNNING || victimTeam < 0 || victimTeam >= teams.size()) return false;
        Team bt = byPlayer.get(breaker), vt = teams.get(victimTeam);
        if (bt == null || bt == vt || !vt.bed || !bt.alive.contains(breaker)) return false;
        vt.bed = false; stats.get(breaker)[2]++;
        evaluate();
        return true;
    }

    public enum DeathResult { IGNORED, RESPAWN, ELIMINATED }

    public DeathResult onDeath(UUID victim, UUID killer) {
        Team t = byPlayer.get(victim);
        if (state != State.RUNNING || t == null || !t.alive.contains(victim)) return DeathResult.IGNORED;
        stats.get(victim)[3]++;
        Team kt = killer == null ? null : byPlayer.get(killer);
        if (t.bed) {
            if (kt != null && kt != t) stats.get(killer)[0]++;
            return DeathResult.RESPAWN;
        }
        t.alive.remove(victim); spectators.add(victim);
        if (kt != null && kt != t) stats.get(killer)[1]++;
        evaluate();
        return DeathResult.ELIMINATED;
    }

    private void evaluate() {
        List<Team> left = teams.stream().filter(t -> !t.members.isEmpty() && !t.eliminated()).toList();
        if (left.size() <= 1 && state == State.RUNNING) {
            winner = left.isEmpty() ? null : left.get(0);
            state = State.ENDING;
        }
    }

    // ---- ekonomi ----
    public void addResource(UUID p, Res r, int n) { if (n > 0 && wallets.containsKey(p)) wallets.get(p).merge(r, n, Integer::sum); }
    public int resource(UUID p, Res r) { return wallets.getOrDefault(p, new EnumMap<>(Res.class)).getOrDefault(r, 0); }

    /** Sunucu tarafı satın alma: fiyat katalogdan okunur. Başarılıysa item id döner. */
    public boolean buy(UUID p, String itemId) {
        Item it = SHOP.get(itemId);
        if (it == null || state != State.RUNNING || teamOf(p) == null) return false;
        EnumMap<Res, Integer> w = wallets.get(p);
        if (w.getOrDefault(it.cost(), 0) < it.price()) return false;
        w.merge(it.cost(), -it.price(), Integer::sum);
        return true;
    }

    // ---- takım yükseltmeleri ----
    private static final int[] PROT_COST = {2, 4, 8, 16};
    private static final int[] HASTE_COST = {2, 4};
    public enum Upgrade { SHARPNESS, PROTECTION, HASTE, FORGE }

    /** Yükseltme maliyeti elmas; takım içinde herhangi bir üye ödeyebilir. -1 = azami seviye. */
    public int upgradeCost(Team t, Upgrade u) {
        return switch (u) {
            case SHARPNESS -> t.sharpness >= 1 ? -1 : 4;
            case PROTECTION -> t.protection >= PROT_COST.length ? -1 : PROT_COST[t.protection];
            case HASTE -> t.haste >= HASTE_COST.length ? -1 : HASTE_COST[t.haste];
            case FORGE -> t.forge >= 3 ? -1 : new int[]{2, 4, 6}[t.forge];
        };
    }
    public boolean buyUpgrade(UUID p, Upgrade u) {
        Team t = byPlayer.get(p);
        if (t == null || state != State.RUNNING) return false;
        int cost = upgradeCost(t, u);
        if (cost < 0 || resource(p, Res.DIAMOND) < cost) return false;
        wallets.get(p).merge(Res.DIAMOND, -cost, Integer::sum);
        switch (u) { case SHARPNESS -> t.sharpness++; case PROTECTION -> t.protection++; case HASTE -> t.haste++; case FORGE -> t.forge++; }
        return true;
    }

    /** Envanter tabanlı ödeme: payer elmas maliyetini envanterden düşebilirse yükseltme uygulanır. */
    public boolean upgradeTeam(UUID p, Upgrade u, java.util.function.IntPredicate payer) {
        Team t = byPlayer.get(p);
        if (t == null || state != State.RUNNING) return false;
        int cost = upgradeCost(t, u);
        if (cost < 0 || !payer.test(cost)) return false;
        switch (u) { case SHARPNESS -> t.sharpness++; case PROTECTION -> t.protection++; case HASTE -> t.haste++; case FORGE -> t.forge++; }
        return true;
    }

    // ---- üreticiler ----
    /** Takım adasındaki demir/altın üretici aralığı (tick). Forge seviyesi hızı artırır. */
    public static int ironIntervalTicks(int forge) { return switch (forge) { case 0 -> 20; case 1 -> 14; case 2 -> 10; default -> 7; }; }
    public static int goldIntervalTicks(int forge) { return switch (forge) { case 0 -> 80; case 1 -> 56; case 2 -> 40; default -> 28; }; }
    /** Ortadaki elmas/zümrüt üreticileri; tier 1..3 (süre geçtikçe hızlanır). */
    public static int diamondIntervalTicks(int tier) { return switch (tier) { case 1 -> 600; case 2 -> 460; default -> 240; }; }
    public static int emeraldIntervalTicks(int tier) { return switch (tier) { case 1 -> 1300; case 2 -> 1000; default -> 600; }; }

    public void endNow() { state = State.ENDING; }
}
