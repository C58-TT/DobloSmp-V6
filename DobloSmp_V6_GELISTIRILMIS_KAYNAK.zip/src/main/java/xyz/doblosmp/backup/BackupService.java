package xyz.doblosmp.backup;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/** Zip yedek + dosya bazlı SHA-256 manifest + zip için yan dosya özeti. Geri yükleme zip-slip korumalıdır. */
public final class BackupService {
    private final Path backupDir; private final int keep;
    public BackupService(Path backupDir, int keep) { this.backupDir = backupDir; this.keep = Math.max(1, keep); }

    static String sha256(InputStream in) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256"); byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            return HexFormat.of().formatHex(md.digest());
        } catch (java.security.NoSuchAlgorithmException e) { throw new IOException(e); }
    }

    /** sources: zip içindeki üst klasör adı -> diskteki kaynak yol. Oluşan zip yolunu döndürür. */
    public Path create(String label, Map<String, Path> sources) throws IOException {
        Files.createDirectories(backupDir);
        String name = label.replaceAll("[^a-zA-Z0-9_-]", "_") + "-" + System.currentTimeMillis() + ".zip";
        Path zip = backupDir.resolve(name);
        StringBuilder manifest = new StringBuilder();
        try (ZipOutputStream z = new ZipOutputStream(Files.newOutputStream(zip))) {
            for (var src : sources.entrySet()) {
                Path root = src.getValue(); if (!Files.exists(root)) continue;
                try (var walk = Files.walk(root)) {
                    for (Path p : (Iterable<Path>) walk.filter(Files::isRegularFile)::iterator) {
                        String entry = src.getKey() + "/" + root.relativize(p).toString().replace('\\', '/');
                        if (entry.contains("session.lock")) continue;       // kilitli dosya
                        String h;
                        try (InputStream in = Files.newInputStream(p)) { h = sha256(in); }
                        z.putNextEntry(new ZipEntry(entry));
                        Files.copy(p, z); z.closeEntry();
                        manifest.append(h).append("  ").append(entry).append('\n');
                    }
                }
            }
            z.putNextEntry(new ZipEntry("MANIFEST.sha256"));
            z.write(manifest.toString().getBytes(StandardCharsets.UTF_8)); z.closeEntry();
        }
        try (InputStream in = Files.newInputStream(zip)) {
            Files.writeString(Path.of(zip + ".sha256"), sha256(in) + "  " + name + "\n");
        }
        prune();
        return zip;
    }

    /** Hem zip özetini hem de içindeki her dosyanın özetini doğrular. */
    public boolean verify(Path zip) {
        try {
            Path side = Path.of(zip + ".sha256");
            if (Files.exists(side)) {
                String want = Files.readString(side).trim().split("\\s+")[0];
                try (InputStream in = Files.newInputStream(zip)) { if (!want.equals(sha256(in))) return false; }
            }
            Map<String, String> expected = new HashMap<>();
            try (ZipFile zf = new ZipFile(zip.toFile())) {
                ZipEntry m = zf.getEntry("MANIFEST.sha256"); if (m == null) return false;
                for (String line : new String(zf.getInputStream(m).readAllBytes(), StandardCharsets.UTF_8).split("\n")) {
                    if (line.isBlank()) continue; String[] parts = line.split("  ", 2);
                    if (parts.length != 2) return false; expected.put(parts[1], parts[0]);
                }
                int seen = 0;
                for (Enumeration<? extends ZipEntry> e = zf.entries(); e.hasMoreElements(); ) {
                    ZipEntry ze = e.nextElement(); if (ze.isDirectory() || ze.getName().equals("MANIFEST.sha256")) continue;
                    String want = expected.get(ze.getName()); if (want == null) return false;
                    try (InputStream in = zf.getInputStream(ze)) { if (!want.equals(sha256(in))) return false; }
                    seen++;
                }
                return seen == expected.size();
            }
        } catch (IOException | RuntimeException e) { return false; }
    }

    /** Doğrulanmış yedeği hedefe açar. Doğrulama başarısızsa veya yol hedef dışına çıkıyorsa reddeder. */
    public void restore(Path zip, Path target) throws IOException {
        if (!verify(zip)) throw new IOException("Yedek bütünlük kontrolünden geçemedi: " + zip.getFileName());
        Path root = target.toAbsolutePath().normalize();
        try (ZipFile zf = new ZipFile(zip.toFile())) {
            for (Enumeration<? extends ZipEntry> e = zf.entries(); e.hasMoreElements(); ) {
                ZipEntry ze = e.nextElement(); if (ze.isDirectory() || ze.getName().equals("MANIFEST.sha256")) continue;
                Path out = root.resolve(ze.getName()).normalize();
                if (!out.startsWith(root)) throw new IOException("Geçersiz yol (zip-slip): " + ze.getName());
                Files.createDirectories(out.getParent());
                try (InputStream in = zf.getInputStream(ze)) { Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING); }
            }
        }
    }

    /** Geri yükleme hazırlığı: yedeği doğrular, staging'e açar, PENDING işaretini yazar. Canlı dosyalara DOKUNMAZ. */
    public void stageRestore(Path zip, Path staging) throws IOException {
        if (Files.exists(staging)) try (var w = Files.walk(staging)) { for (Path p : (Iterable<Path>) w.sorted(Comparator.reverseOrder())::iterator) Files.delete(p); }
        Files.createDirectories(staging);
        restore(zip, staging.resolve("files"));                      // doğrular + zip-slip korumalı açar
        Files.writeString(staging.resolve("PENDING"), zip.getFileName() + "\n");
    }

    /**
     * Sunucu KAPALIYKEN çalıştırılır. Önce üzerine yazılacak mevcut dosyaların doğrulanmış yedeği alınır (başarısızsa hiçbir şey değişmez),
     * sonra "server/" girdileri sunucu köküne, "plugin-data/" girdileri eklenti klasörüne kopyalanır. Dönüş: kopyalanan dosya sayısı.
     */
    public int applyStaged(Path staging, Path serverRoot, Path pluginDir) throws IOException {
        if (!Files.exists(staging.resolve("PENDING"))) return 0;
        Path files = staging.resolve("files"); Path root = serverRoot.toAbsolutePath().normalize(), plug = pluginDir.toAbsolutePath().normalize();
        Map<Path, Path> plan = new LinkedHashMap<>();                  // kaynak -> hedef
        try (var w = Files.walk(files)) {
            for (Path src : (Iterable<Path>) w.filter(Files::isRegularFile)::iterator) {
                String rel = files.relativize(src).toString().replace('\\', '/'); Path dst;
                if (rel.startsWith("server/")) dst = root.resolve(rel.substring(7)).normalize();
                else if (rel.startsWith("plugin-data/")) dst = plug.resolve(rel.substring(12)).normalize();
                else continue;
                if (!(dst.startsWith(root))) throw new IOException("Geçersiz hedef: " + rel);
                plan.put(src, dst);
            }
        }
        Path tmp = Files.createTempDirectory(backupDir.getParent() == null ? Path.of(".") : backupDir.getParent(), "prerestore");
        try {
            for (Path dst : plan.values()) if (Files.exists(dst)) { Path c = tmp.resolve(root.relativize(dst).toString()); Files.createDirectories(c.getParent()); Files.copy(dst, c, StandardCopyOption.REPLACE_EXISTING); }
            Path pre = create("pre-restore", Map.of("existing", tmp));
            if (!verify(pre)) throw new IOException("Geri yükleme öncesi yedek doğrulanamadı; işlem iptal edildi.");
        } finally { try (var w = Files.walk(tmp)) { for (Path p : (Iterable<Path>) w.sorted(Comparator.reverseOrder())::iterator) Files.deleteIfExists(p); } }
        int n = 0;
        for (var e : plan.entrySet()) { Files.createDirectories(e.getValue().getParent()); Files.copy(e.getKey(), e.getValue(), StandardCopyOption.REPLACE_EXISTING); n++; }
        Files.delete(staging.resolve("PENDING"));
        return n;
    }

    public List<Path> list() throws IOException {
        if (!Files.isDirectory(backupDir)) return List.of();
        try (var s = Files.list(backupDir)) {
            return s.filter(p -> p.toString().endsWith(".zip")).sorted(Comparator.comparing(Path::getFileName).reversed()).toList();
        }
    }
    private void prune() throws IOException {
        List<Path> all = list();
        for (int i = keep; i < all.size(); i++) { Files.deleteIfExists(all.get(i)); Files.deleteIfExists(Path.of(all.get(i) + ".sha256")); }
    }
}
