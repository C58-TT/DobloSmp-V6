# Üçüncü taraf
- Paper API (provided, MIT/GPL ayrı lisanslıdır) — yalnızca derleme bağımlılığı.
- mariadb-java-client (LGPL 2.1): pom'da bağımlılık; JAR'a gömülürse lisans metni ve kaynak erişimi korunmalıdır. Pakettaki "DOGRULANMAMIS" JAR sürücüyü (2.7.6, Ubuntu paketi) içerir.
- H2 (test kapsamı, MPL 2.0/EPL 1.0).
- Geyser/Floodgate (MIT) ve Citizens: pakete DAHİL DEĞİL; kullanıcı resmî kaynaktan kurar.
