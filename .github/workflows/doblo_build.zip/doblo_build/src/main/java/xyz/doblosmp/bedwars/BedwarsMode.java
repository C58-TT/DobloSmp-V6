package xyz.doblosmp.bedwars;

/** Yalnızca Solo BedWars: tam 8 oyuncu, 8 takım, takım başına 1 oyuncu. */
public enum BedwarsMode {
    SOLO(8, 1);
    public final int teams, perTeam;
    BedwarsMode(int teams, int perTeam) { this.teams = teams; this.perTeam = perTeam; }
    public int capacity() { return teams * perTeam; }
    /** Eski kayıtlı arena modları (DOUBLES vb.) güvenle SOLO'ya dönüşür. */
    public static BedwarsMode of(String s) { return SOLO; }
}
