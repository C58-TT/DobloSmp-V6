#!/usr/bin/env bash
# Geyser + Floodgate kurulumu (RESMİ indirme API'si). Bu betik bu çalışmada ÇALIŞTIRILMADI/TEST EDİLMEDİ.
set -euo pipefail
PLUGINS="${1:-/opt/minecraft/plugins}"
for P in geyser floodgate; do
  URL="https://download.geysermc.org/v2/projects/$P/versions/latest/builds/latest/downloads/spigot"
  echo "İndiriliyor: $P"; curl -fsSL -o "$PLUGINS/$P-spigot.jar" "$URL"
done
echo "Sunucuyu bir kez başlatıp kapat, sonra:"
echo " - plugins/Geyser-Spigot/config.yml: bedrock.port: 19132, auth-type: floodgate"
echo " - plugins/floodgate/config.yml: username-prefix: \".\""
echo " - Güvenlik duvarı: sudo ufw allow 19132/udp  (sağlayıcı panelinde de UDP 19132 açık olmalı)"
echo " - Geyser'ın 'remote' bölümünde adres 127.0.0.1, port 25565"
echo "ÖNEMLİ: plugins/floodgate/key.pem dosyasını kimseyle paylaşma."
