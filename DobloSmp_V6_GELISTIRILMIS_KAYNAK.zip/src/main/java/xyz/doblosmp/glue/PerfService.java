package xyz.doblosmp.glue;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.discord.DiscordNotifier;

import java.util.*;

/** Performans: chunk başına canlı sınırı (doğal doğma), periyodik TPS/MSPT/RAM raporu ve uyarılar, /perf komutu. Ana thread'de ağır iş yapmaz. */
public final class PerfService implements CommandExecutor, Listener {
    private final JavaPlugin plugin; private long lastWarn;
    public PerfService(JavaPlugin plugin) {
        this.plugin = plugin; long every = 20L * 60 * Math.max(1, plugin.getConfig().getInt("performance.report-minutes", 5));
        Bukkit.getScheduler().runTaskTimer(plugin, this::report, every, every);
    }
    private String line() {
        Runtime rt = Runtime.getRuntime(); long used = (rt.totalMemory() - rt.freeMemory()) >> 20, max = rt.maxMemory() >> 20; int ent = 0, chunks = 0;
        for (var w : Bukkit.getWorlds()) { chunks += w.getLoadedChunks().length; ent += w.getEntityCount(); }
        return String.format("TPS %.2f | MSPT %.1f | RAM %d/%d MB | oyuncu %d | chunk %d | varlık %d", Math.min(20, Bukkit.getTPS()[0]), Bukkit.getAverageTickTime(), used, max, Bukkit.getOnlinePlayers().size(), chunks, ent);
    }
    private void report() {
        String l = line(); plugin.getLogger().info("[Perf] " + l); double tps = Bukkit.getTPS()[0]; Runtime rt = Runtime.getRuntime(); double ram = (double) (rt.totalMemory() - rt.freeMemory()) / rt.maxMemory();
        long now = System.currentTimeMillis();
        if ((tps < plugin.getConfig().getDouble("performance.warn-tps", 17.0) || ram > plugin.getConfig().getDouble("performance.warn-ram", 0.9)) && now - lastWarn > 600_000L) { lastWarn = now; Ctx.discord(DiscordNotifier.Kind.WARN, "Performans uyarısı", l);
            for (Player p : Bukkit.getOnlinePlayers()) if (p.hasPermission("doblo.admin")) p.sendMessage("§c[Perf] " + l); }
        else if (plugin.getConfig().getBoolean("performance.discord-status", false)) Ctx.discord(DiscordNotifier.Kind.INFO, "Sunucu durumu", l);
    }
    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("doblo.admin")) { s.sendMessage("§cYetkin yok."); return true; } s.sendMessage("§e" + line());
        for (var w : Bukkit.getWorlds()) s.sendMessage("§7" + w.getName() + ": chunk " + w.getLoadedChunks().length + ", varlık " + w.getEntityCount()); return true;
    }
    /** Chunk başına aynı türden azami canlı (doğal doğma ve spawner). Özel/yumurta doğmaları etkilenmez. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onSpawn(CreatureSpawnEvent e) {
        int cap = plugin.getConfig().getInt("performance.max-mobs-per-chunk", 24); if (cap <= 0) return; var r = e.getSpawnReason();
        if (r != CreatureSpawnEvent.SpawnReason.NATURAL && r != CreatureSpawnEvent.SpawnReason.SPAWNER && r != CreatureSpawnEvent.SpawnReason.BREEDING && r != CreatureSpawnEvent.SpawnReason.CHUNK_GEN) return;
        Chunk ch = e.getLocation().getChunk(); int same = 0; for (Entity en : ch.getEntities()) if (en.getType() == e.getEntityType()) same++;
        if (same >= cap) e.setCancelled(true);
    }
}
