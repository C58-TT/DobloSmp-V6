package xyz.doblosmp.duels;

import java.util.*;

/** Mod+kit bazlı kuyruk. Bekleme süresi arttıkça kabul edilen ELO aralığı genişler. */
public final class DuelQueue {
    public record Ticket(UUID player, String kit, int teamSize, int elo, long since) {}
    public record Match(Ticket a, Ticket b) {}

    private final List<Ticket> waiting = new ArrayList<>();
    private final int baseRange, widenPerSec;

    public DuelQueue(int baseRange, int widenPerSec) { this.baseRange = baseRange; this.widenPerSec = widenPerSec; }

    public synchronized boolean join(UUID p, String kit, int teamSize, int elo) {
        for (Ticket t : waiting) if (t.player().equals(p)) return false;
        waiting.add(new Ticket(p, kit, teamSize, elo, System.currentTimeMillis()));
        return true;
    }
    public synchronized boolean leave(UUID p) { return waiting.removeIf(t -> t.player().equals(p)); }
    public synchronized int size() { return waiting.size(); }

    /** Eşleşmeleri üretir ve kuyruktan çıkarır. now parametresi test edilebilirlik içindir. */
    public synchronized List<Match> poll(long now) {
        List<Match> out = new ArrayList<>();
        waiting.sort(Comparator.comparingLong(Ticket::since));
        Set<UUID> used = new HashSet<>();
        for (int i = 0; i < waiting.size(); i++) {
            Ticket a = waiting.get(i);
            if (used.contains(a.player())) continue;
            Ticket best = null; int bestDiff = Integer.MAX_VALUE;
            for (int j = i + 1; j < waiting.size(); j++) {
                Ticket b = waiting.get(j);
                if (used.contains(b.player()) || !a.kit().equals(b.kit()) || a.teamSize() != b.teamSize()) continue;
                int diff = Math.abs(a.elo() - b.elo());
                long wa = (now - a.since()) / 1000, wb = (now - b.since()) / 1000;
                long range = baseRange + (long) widenPerSec * Math.max(wa, wb);
                if (diff <= range && diff < bestDiff) { best = b; bestDiff = diff; }
            }
            if (best != null) { used.add(a.player()); used.add(best.player()); out.add(new Match(a, best)); }
        }
        waiting.removeIf(t -> used.contains(t.player()));
        return out;
    }
}
