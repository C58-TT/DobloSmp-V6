# Durum (V5 tabanı, V6 çalışma kopyası)

V5 için daha önce bildirilen test sonuçları V6 değişikliklerini kapsamaz. Bu V6 kopyasında web paneli kaldırıldı. Paper API gerçek sunucu testi, uçtan uca oyun testleri, Bedrock ve yük testleri henüz yapılmadı. Ayrıntı için `V6-DEVAM-EDEN-ISLER.md`.
