package xyz.doblosmp.glue;

import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.gui.Menus;

import java.util.*;

/** /arkadas ve /parti (FriendService ve PartyService üstünde) + giriş/çıkış bildirimleri. */
public final class SocialCommands implements CommandExecutor, Listener {
    private static String name(UUID id) { var p = Bukkit.getOfflinePlayer(id); return p.getName() == null ? id.toString().substring(0, 8) : p.getName(); }
    private Player online(String n) { return n == null ? null : Bukkit.getPlayerExact(n); }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Oyuncu komutu."); return true; }
        if (c.getName().equalsIgnoreCase("arkadas")) friends(p, a); else party(p, a); return true;
    }
    private void friends(Player p, String[] a) {
        UUID id = p.getUniqueId(); long now = System.currentTimeMillis(); String sub = a.length == 0 ? "liste" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "ekle" -> { Player t = online(a.length > 1 ? a[1] : null); if (t == null) { p.sendMessage("§c/arkadas ekle <çevrimiçi oyuncu>"); return; }
                if (Ctx.friends.areFriends(id, t.getUniqueId())) { p.sendMessage("§eZaten arkadaşsınız."); return; }
                if (!Ctx.friends.request(id, t.getUniqueId(), now)) { p.sendMessage("§cİstek gönderilemedi (liste dolu/geçersiz)."); return; }
                if (Ctx.friends.areFriends(id, t.getUniqueId())) { p.sendMessage("§aArtık arkadaşsınız!"); t.sendMessage("§a" + p.getName() + " ile arkadaş oldunuz!"); } else { p.sendMessage("§aİstek gönderildi."); t.sendMessage("§e" + p.getName() + " sana arkadaşlık isteği gönderdi: §a/arkadas kabul " + p.getName()); } }
            case "kabul" -> { Player t = online(a.length > 1 ? a[1] : null); UUID from = t != null ? t.getUniqueId() : (Ctx.friends.pending(id, now).size() == 1 ? Ctx.friends.pending(id, now).get(0) : null);
                if (from == null || !Ctx.friends.accept(id, from, now)) { p.sendMessage("§cGeçerli istek yok."); return; } p.sendMessage("§aArkadaş eklendi: " + name(from)); Player f = Bukkit.getPlayer(from); if (f != null) f.sendMessage("§a" + p.getName() + " isteğini kabul etti!"); }
            case "reddet" -> { Player t = online(a.length > 1 ? a[1] : null); p.sendMessage(t != null && Ctx.friends.deny(id, t.getUniqueId()) ? "§eReddedildi." : "§cGeçerli istek yok."); }
            case "sil" -> { UUID t = a.length > 1 ? find(a[1]) : null; p.sendMessage(t != null && Ctx.friends.remove(id, t) ? "§eArkadaşlıktan çıkarıldı." : "§cBulunamadı."); }
            case "davet" -> { Player t = online(a.length > 1 ? a[1] : null); if (t == null || !Ctx.friends.areFriends(id, t.getUniqueId())) { p.sendMessage("§cYalnızca çevrimiçi arkadaşlarını davet edebilirsin."); return; } p.performCommand("parti davet " + t.getName()); }
            case "menu" -> Menus.friends(p);
            default -> { var f = new ArrayList<>(Ctx.friends.of(id)); f.sort(Comparator.comparing((UUID u) -> Bukkit.getPlayer(u) == null).thenComparing(SocialCommands::name)); p.sendMessage("§dArkadaşlar (" + f.size() + "):");
                for (UUID u : f) p.sendMessage((Bukkit.getPlayer(u) != null ? "§a● " : "§7○ ") + name(u)); var pend = Ctx.friends.pending(id, now); if (!pend.isEmpty()) p.sendMessage("§eBekleyen istekler: " + String.join(", ", pend.stream().map(SocialCommands::name).toList())); }
        }
    }
    private UUID find(String n) { Player p = Bukkit.getPlayerExact(n); if (p != null) return p.getUniqueId(); var op = Bukkit.getOfflinePlayerIfCached(n); return op == null ? null : op.getUniqueId(); }

    private void party(Player p, String[] a) {
        UUID id = p.getUniqueId(); long now = System.currentTimeMillis(); String sub = a.length == 0 ? "liste" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "davet" -> { Player t = online(a.length > 1 ? a[1] : null); if (t == null) { p.sendMessage("§c/parti davet <çevrimiçi oyuncu>"); return; } if (!Menus.prefs.get(t.getUniqueId(), "party_requests")) { p.sendMessage("§cBu oyuncu parti isteklerini kapattı."); return; }
                if (!Ctx.parties.invite(id, t.getUniqueId(), now)) { p.sendMessage("§cDavet gönderilemedi (lider olmalısın, hedef partisiz ve parti dolu olmamalı)."); return; } p.sendMessage("§aDavet gönderildi."); t.sendMessage("§6" + p.getName() + " seni partiye davet etti: §a/parti kabul"); }
            case "kabul" -> { if (!Ctx.parties.accept(id, now)) { p.sendMessage("§cGeçerli davet yok."); return; } var party = Ctx.parties.of(id); for (UUID u : party.members) { Player m = Bukkit.getPlayer(u); if (m != null) m.sendMessage("§6" + p.getName() + " partiye katıldı."); } }
            case "ayril" -> { var party = Ctx.parties.of(id); List<UUID> before = party == null ? List.of() : new ArrayList<>(party.members); if (!Ctx.parties.leave(id)) { p.sendMessage("§cPartide değilsin."); return; } p.sendMessage("§ePartiden ayrıldın."); for (UUID u : before) { Player m = Bukkit.getPlayer(u); if (m != null && !m.equals(p)) m.sendMessage("§6" + p.getName() + " partiden ayrıldı."); } }
            case "at" -> { UUID t = a.length > 1 ? find(a[1]) : null; if (t == null || !Ctx.parties.kick(id, t)) { p.sendMessage("§cAtılamadı."); return; } p.sendMessage("§eÜye atıldı."); Player m = Bukkit.getPlayer(t); if (m != null) m.sendMessage("§cPartiden atıldın."); }
            case "devret" -> { UUID t = a.length > 1 ? find(a[1]) : null; p.sendMessage(t != null && Ctx.parties.transfer(id, t) ? "§aLiderlik devredildi." : "§cDevredilemedi."); }
            case "dagit" -> { var party = Ctx.parties.of(id); List<UUID> before = party == null ? List.of() : new ArrayList<>(party.members); if (!Ctx.parties.disband(id)) { p.sendMessage("§cYetkin yok."); return; } for (UUID u : before) { Player m = Bukkit.getPlayer(u); if (m != null) m.sendMessage("§6Parti dağıtıldı."); } }
            case "menu" -> Menus.party(p);
            default -> { var party = Ctx.parties.of(id); if (party == null) { p.sendMessage("§7Partin yok. /parti davet <oyuncu>"); return; } p.sendMessage("§6Parti (" + party.members.size() + "): " + String.join(", ", party.members.stream().map(u -> (u.equals(party.leader) ? "★" : "") + name(u)).toList())); }
        }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { notify(e.getPlayer(), "§a+ §f" + e.getPlayer().getName() + " §7çevrimiçi oldu"); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { notify(e.getPlayer(), "§c- §f" + e.getPlayer().getName() + " §7çevrimdışı oldu"); Ctx.parties.leave(e.getPlayer().getUniqueId()); }
    private void notify(Player who, String msg) { for (UUID f : Ctx.friends.of(who.getUniqueId())) { Player fp = Bukkit.getPlayer(f); if (fp != null && Menus.prefs.get(f, "friend_notify")) fp.sendMessage(msg); } }
}
