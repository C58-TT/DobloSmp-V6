package xyz.doblosmp.economy;

import java.util.*;

/** İki taraflı onaylı güvenli ticaret. Teklif değişirse iki onay da sıfırlanır; zaman aşımı vardır. */
public final class TradeSession {
    public enum State { OPEN, COMPLETED, CANCELLED, EXPIRED, FAILED }

    /** Eşya işlemleri için sunucu tarafı köprü (Bukkit envanteri bunu uygular). */
    public interface ItemGateway {
        boolean has(UUID p, String item, int amount);
        boolean take(UUID p, String item, int amount);
        void give(UUID p, String item, int amount);
    }

    public final UUID a, b;
    private final String mode;
    private final long expiresAt;
    private final Map<UUID, Long> coins = new HashMap<>();
    private final Map<UUID, Map<String, Integer>> items = new HashMap<>();
    private final Set<UUID> confirmed = new HashSet<>();
    private State state = State.OPEN;

    public TradeSession(UUID a, UUID b, String mode, long timeoutMillis) {
        if (a.equals(b)) throw new IllegalArgumentException("Kendinle ticaret yapılamaz");
        this.a = a; this.b = b; this.mode = mode;
        this.expiresAt = System.currentTimeMillis() + timeoutMillis;
        items.put(a, new HashMap<>()); items.put(b, new HashMap<>());
    }

    public synchronized State state() { return state; }
    private boolean party(UUID p) { return p.equals(a) || p.equals(b); }
    private boolean live() {
        if (state == State.OPEN && System.currentTimeMillis() > expiresAt) state = State.EXPIRED;
        return state == State.OPEN;
    }

    public synchronized boolean setCoins(UUID p, long amount) {
        if (!live() || !party(p) || amount < 0) return false;
        coins.put(p, amount); confirmed.clear(); return true;
    }

    public synchronized boolean setItem(UUID p, String item, int amount) {
        if (!live() || !party(p) || amount < 0) return false;
        if (amount == 0) items.get(p).remove(item); else items.get(p).put(item, amount);
        confirmed.clear(); return true;
    }

    public synchronized boolean confirm(UUID p) {
        if (!live() || !party(p)) return false;
        confirmed.add(p); return true;
    }

    public synchronized void cancel() { if (state == State.OPEN) state = State.CANCELLED; }

    public synchronized boolean bothConfirmed() { return live() && confirmed.contains(a) && confirmed.contains(b); }

    /** İki taraf da onayladıysa her şeyi atomik uygular; herhangi bir adım başarısızsa geri alır. */
    public synchronized boolean execute(Ledger ledger, ItemGateway gw) {
        if (!bothConfirmed()) return false;
        long ca = coins.getOrDefault(a, 0L), cb = coins.getOrDefault(b, 0L);
        // 1) ön doğrulama
        if (ledger.balance(mode, a) < ca || ledger.balance(mode, b) < cb) return fail();
        for (UUID p : List.of(a, b))
            for (var e : items.get(p).entrySet()) if (!gw.has(p, e.getKey(), e.getValue())) return fail();
        // 2) eşyaları al (yapılanları kaydet)
        List<Object[]> taken = new ArrayList<>();
        for (UUID p : List.of(a, b))
            for (var e : items.get(p).entrySet()) {
                if (!gw.take(p, e.getKey(), e.getValue())) { rollbackItems(taken, gw); return fail(); }
                taken.add(new Object[]{p, e.getKey(), e.getValue()});
            }
        // 3) para takası
        boolean ok = true;
        boolean movedA = false;
        if (ca > 0) { ok = ledger.transfer(mode, a, b, ca, "trade"); movedA = ok; }
        if (ok && cb > 0) ok = ledger.transfer(mode, b, a, cb, "trade");
        if (!ok) {
            if (movedA) ledger.transfer(mode, b, a, ca, "trade-rollback");
            rollbackItems(taken, gw); return fail();
        }
        // 4) eşyaları karşı tarafa ver
        for (var e : items.get(a).entrySet()) gw.give(b, e.getKey(), e.getValue());
        for (var e : items.get(b).entrySet()) gw.give(a, e.getKey(), e.getValue());
        state = State.COMPLETED;
        return true;
    }

    private void rollbackItems(List<Object[]> taken, ItemGateway gw) {
        for (Object[] t : taken) gw.give((UUID) t[0], (String) t[1], (Integer) t[2]);
    }
    private boolean fail() { state = State.FAILED; return false; }
}
