# V6 değişiklik raporu (bu tur)

## Yapıldı ve test edildi (saf mantık; javac ile derlendi, çalıştırıldı)
- Ada seviyesi/puanı/geliştirme KALDIRILDI: IslandLevel silindi, Island'dan level/worth/sizeLvl/memberLvl/genLvl çıkarıldı,
  /is upgrade, /is level, /is top, cobblestone jeneratör seviyesi, tarama kodu, DB sütunları (V2__ada_seviyesi_kaldir.sql ile DROP) ve YAML yedek alanları kaldırıldı.
  Yarıçap (100) ve üye limiti (8) sabit. Testler: "Island'da seviye alanı yok", "upgrade/top yok", sabit limit.
- Başlangıç adası: 1 ağaç + sandık + crafting table. Sandık YALNIZCA 1 Lava Bucket, 1 Water Bucket, 2 Sapling. (Paper kodu: derlenmedi/denenmedi)
- /ada artık yeni sistemi açar (create/home/invite/accept/visit/settings/shop + Türkçe takma adlar). /island = /ada. Eski YAML adaları /eskiada ile erişilebilir (veri korunur).
- /ada shop: SkyShop (6 kategori, 38 ürün, config fiyatları: skyblock.shop.prices). Testler: yetersiz bakiye, dolu envanter, iade, çift tıklama kilidi, satılamaz/alınamaz ürün. GUI/spawner yerleştirme Paper kodudur, denenmedi.
- Duels Elo: tek kalıcı (global) Elo; ligler Bakır/Demir/Altın/Elmas/Zümrüt/Netherite (config: duels.elo.leagues); rakip Elo'suna göre kazanç/kayıp; üst ligde kazanç azalır/kayıp artar; aynı çiftle tekrar maçta kazanç düşer (PairHistory); dövüş başlamadan biten maç Elo'yu değiştirmez; /duel top (SQL'den, async). Eski kit bazlı Elo verisi ilk yüklemede en yüksek değerle devralınır.
- BedWars: yalnızca SOLO 8 takım; tam 8 oyuncuyla başlar; takımlar rastgele ve farklı (Mavi, Kırmızı, Sarı, Mor, Yeşil, Koyu Yeşil, Siyah, Gri); durum satırı ✓/✗.
- Murder: min 5 oyuncu; RoleChance (şerif/katil bağımsız ağırlık, tavan, sıfırlama); şerif ölünce YALNIZCA OK düşer; ok sahibi 5 sn cooldown (MurderGame.tryShoot + EntityShootBowEvent).

## Test sonuçları (bu ortamda gerçekten çalıştırıldı)
- V6Tests: 6070 geçti, 0 kaldı. CoreTests: 108 geçti, 0 kaldı.
- NewTests: DB bölümüne kadar geçti; H2 sürücüsü bu ortamda yok, DB testi ÇALIŞTIRILAMADI.
- Paper'a bağımlı sınıflar (GUI, komutlar, listener'lar) DERLENMEDİ: bu ortamda paper-api yok. GitHub Actions'ta derleyin.
- JUnit değil, projenin mevcut main() tabanlı test düzeni kullanıldı.

## YAPILMADI / eksik
- Murder: RoleChance, MurderManager'a bağlanmadı (rol seçimi hâlâ eski rastgele); şans DB'ye yazılmıyor; ActionBar şans gösterimi yok.
- Duels: Crystal/Mace/Diamond kitleri yok (config'te nodebuff/classic/sumo), kit enchant desteği yok, 2v2 ve party takım mantığı yok (DuelMatch yalnızca 2 oyunculu).
- TAB ve Scoreboard sistemi bu kaynakta yok (yalnızca yeni JAR'da HudManager var, kaynağı yok).
- BedWars: Paper katmanı (BedwarsManager) 8-takım kurallarına ve yeni mağaza fiyatlarına uyarlanmadı; mağaza/upgrade listesi eksik; takım renkleri TAB/scoreboard'da yok.
- Lobi: /spawn, /ayrıl komutu, koruma, NPC konumları bu kaynakta kontrol edilmedi.
- Harita koordinatları (yatak, jeneratör, spawn) çıkarılmadı; Maplar.zip içindeki haritalar entegre EDİLMEDİ.
