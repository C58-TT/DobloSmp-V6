package xyz.doblosmp.core;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.anticheat.Suspicion;
import xyz.doblosmp.arena.ArenaManager;
import xyz.doblosmp.backup.BackupService;
import xyz.doblosmp.clan.ClanService;
import xyz.doblosmp.db.Database;
import xyz.doblosmp.discord.DiscordNotifier;
import xyz.doblosmp.economy.AuctionHouse;
import xyz.doblosmp.economy.Ledger;
import xyz.doblosmp.game.*;
import xyz.doblosmp.glue.*;
import xyz.doblosmp.glue.sky.Skyblock;
import xyz.doblosmp.gui.*;
import xyz.doblosmp.progression.ProgressionService;
import xyz.doblosmp.quest.QuestEngine;
import xyz.doblosmp.sb.IslandRegistry;
import xyz.doblosmp.security.HeuristicGuard;
import xyz.doblosmp.skyblock.IslandService;
import xyz.doblosmp.social.FriendService;
import xyz.doblosmp.social.PartyService;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class DobloSuite extends JavaPlugin {
    private ArenaManager arenas; private ProgressionService progression; private IslandService oldIslands; private Store store; private LobbyManager lobby;
    private BackupService backups; private EconomyCommands economyCommands; private BedwarsManager bedwars; private DuelsManager duels; private MurderManager murder; private DiscordHooks discordHooks; private PlayerState playerState;
    private boolean started;

    private PluginCommand cmd(String n) { PluginCommand c = getCommand(n); if (c == null) throw new IllegalStateException("plugin.yml'de komut yok: " + n); return c; }

    @Override public void onEnable() {
        saveDefaultConfig(); Ctx.plugin = this; var cfg = getConfig();
        try {
            // ---- veritabanı (isteğe bağlı) ----
            Database db = null;
            if (cfg.getBoolean("database.enabled", false)) {
                String pass = System.getenv("DOBLO_DB_PASSWORD"); if (pass == null || pass.isBlank()) pass = cfg.getString("database.password", "");
                String url = "jdbc:mariadb://" + cfg.getString("database.host", "127.0.0.1") + ":" + cfg.getInt("database.port", 3306) + "/" + cfg.getString("database.name", "doblosmp") + cfg.getString("database.params", "?useUnicode=true&characterEncoding=utf8");
                db = new Database(url, cfg.getString("database.user", "doblo"), pass, cfg.getInt("database.pool-size", 6), getLogger(), "org.mariadb.jdbc.Driver", getClassLoader());
                db.migrate("/db/V1__init.sql", "/db/V2__ada_seviyesi_kaldir.sql"); getLogger().info("MariaDB bağlantısı hazır (havuz " + cfg.getInt("database.pool-size", 6) + ").");
            }
            store = new Store(this); Ctx.persist = new Persist(this, store, db);

            // ---- servisler ----
            Ctx.ledger = new Ledger(5000); Ctx.market = new AuctionHouse(Ctx.ledger, Ctx.mode("market"), cfg.getDouble("economy.market-tax", 0.05));
            Ctx.clans = new ClanService(cfg.getInt("clan.base-members", 10)); Ctx.quests = new QuestEngine(cfg.getString("quests.season", "S1"), cfg.getInt("quests.pass-xp-per-tier", 100)); registerQuests();
            Ctx.islands = new IslandRegistry(new HashSet<>(cfg.getStringList("skyblock.templates")), 120_000L, cfg.getLong("skyblock.reset-cooldown-seconds", 3600) * 1000L);
            Ctx.parties = new PartyService(cfg.getInt("party.max-size", 8), 60_000L); Ctx.friends = new FriendService(cfg.getInt("friends.max", 100), 5 * 60_000L);
            Ctx.suspicion = new Suspicion(cfg.getDouble("anticheat.decay-per-second", 0.25), 2000); Ctx.punishments = new Punishments(this);
            Ctx.persist.load();

            // ---- Discord ----
            String hook = env("DOBLO_DISCORD_WEBHOOK", cfg.getString("discord.webhook-url", "")), tok = env("DOBLO_DISCORD_BOT_TOKEN", ""), ch = cfg.getString("discord.channel-id", "");
            Ctx.discord = new DiscordNotifier(hook, tok, ch, null, 1200, getLogger());
            if (cfg.getString("discord.webhook-url", "").contains("discord.com/api/webhooks")) getLogger().warning("Webhook URL'si config.yml'de düz metin; ortam değişkeni DOBLO_DISCORD_WEBHOOK kullanmak daha güvenlidir.");
            discordHooks = new DiscordHooks(this);

            // ---- eski sistemler (korunuyor) ----
            arenas = new ArenaManager(this); progression = new ProgressionService(this); oldIslands = new IslandService(this); Ctx.xp = (p, n) -> progression.addXp(p, n);
            getServer().getPluginManager().registerEvents(oldIslands, this); getServer().getPluginManager().registerEvents(new HeuristicGuard(this), this);
            cmd("doblo").setExecutor((s, c, l, a) -> { s.sendMessage("§bDobloSmp §7| DobloSuite " + getPluginMeta().getVersion() + " §aaktif §7| " + (Ctx.persist.sql() ? "MariaDB" : "YAML")); return true; });
            cmd("arena").setExecutor(arenas); cmd("gunluk").setExecutor(progression); cmd("gorev").setExecutor(progression); cmd("eskiada").setExecutor(oldIslands);

            // ---- GUI / NPC / kasa ----
            Menus.prefs = new Prefs(this); Menus.vaults = new Vaults(this); Ctx.npcs = new NpcManager(this); playerState = new PlayerState(this);
            var pm = getServer().getPluginManager(); pm.registerEvents(new Menu.Events(), this); pm.registerEvents(Menus.vaults, this); pm.registerEvents(Ctx.npcs, this);
            cmd("dnpc").setExecutor(Ctx.npcs);
            cmd("menu").setExecutor((s, c, l, a) -> { if (!(s instanceof Player p)) return true;
                boolean form = BedrockSupport.simpleForm(p, "DobloSmp", "Bir seçenek seç", List.of("Oyun Modları", "Profil", "Market", "Görevler", "Günlük Ödül"), i -> Bukkit.getScheduler().runTask(this, () -> { switch (i) { case 0 -> Menus.games(p); case 1 -> Menus.profile(p); case 2 -> Menus.market(p, 0); case 3 -> Menus.quests(p); default -> p.performCommand("gorevler gunluk"); } }));
                if (!form) Menus.main(p); return true; });
            cmd("discord").setExecutor((s, c, l, a) -> { s.sendMessage("§9Discord: §f" + getConfig().getString("discord.invite", "https://discord.gg/b9stca6MAU")); return true; });

            // ---- ekonomi / sosyal / görev ----
            economyCommands = new EconomyCommands(this, Ctx.ledger, Ctx.market, Ctx.mode("market")); for (String c : List.of("bakiye", "pay", "takas", "market")) cmd(c).setExecutor(economyCommands);
            ClanQuestCommands cq = new ClanQuestCommands(Ctx.clans, Ctx.quests, Ctx.ledger, Ctx.mode("quest")); cmd("klan").setExecutor(cq); cmd("gorevler").setExecutor(cq);
            SocialCommands social = new SocialCommands(); cmd("arkadas").setExecutor(social); cmd("parti").setExecutor(social); pm.registerEvents(social, this);
            pm.registerEvents(new QuestListener(this), this);
            cmd("rapor").setExecutor((s, c, l, a) -> { if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("§c/rapor <oyuncu> <sebep>"); return true; } Ctx.punishments.report(p.getName(), a[0], String.join(" ", Arrays.copyOfRange(a, 1, a.length))); p.sendMessage("§aRaporun iletildi."); return true; });

            // ---- lobi / hub ----
            lobby = new LobbyManager(this); pm.registerEvents(lobby, this);
            cmd("lobby").setExecutor((sender, command, label, args) -> { if (!(sender instanceof Player player)) { sender.sendMessage("Bu komut oyuncu içindir."); return true; } var loc = lobby.spawn(); if (loc == null) { player.sendMessage("§cLobi dünyası hazır değil."); return true; } player.teleport(loc); player.sendMessage("§aLobiye ışınlandın."); return true; });
            cmd("lobbyspawn").setExecutor((sender, command, label, args) -> { if (!(sender instanceof Player player) || !player.hasPermission("doblo.admin")) { sender.sendMessage("§cBu komut için doblo.admin gerekir."); return true; } if (!player.getWorld().getName().equalsIgnoreCase(getConfig().getString("lobby.world", "lobby"))) { player.sendMessage("§cLobi dünyasında olmalısın."); return true; } var loc = player.getLocation(); getConfig().set("lobby.spawn.x", loc.getX()); getConfig().set("lobby.spawn.y", loc.getY()); getConfig().set("lobby.spawn.z", loc.getZ()); getConfig().set("lobby.spawn.yaw", loc.getYaw()); getConfig().set("lobby.spawn.pitch", loc.getPitch()); saveConfig(); player.sendMessage("§aLobi spawn kaydedildi."); return true; });

            // ---- oyun modları ----
            Skyblock sky = new Skyblock(this); cmd("is").setExecutor(sky); cmd("ada").setExecutor(sky); pm.registerEvents(sky, this); pm.registerEvents(xyz.doblosmp.gui.SkyShopMenu.init(this), this);
            ArenaStore arenaStore = new ArenaStore(this);
            bedwars = new BedwarsManager(this, arenaStore, playerState); cmd("bw").setExecutor(bedwars); pm.registerEvents(bedwars, this);
            duels = new DuelsManager(this, arenaStore, playerState); cmd("duel").setExecutor(duels); pm.registerEvents(duels, this);
            murder = new MurderManager(this, arenaStore, playerState); cmd("mm").setExecutor(murder); pm.registerEvents(murder, this);

            // ---- anti-cheat / performans ----
            pm.registerEvents(new AntiCheatListener(this, Ctx.suspicion), this); pm.registerEvents(Ctx.punishments, this);
            cmd("dac").setExecutor((s, c, l, a) -> { if (!s.hasPermission("doblo.admin")) { s.sendMessage("§cYetkin yok."); return true; } if (a.length < 1) { s.sendMessage("§c/dac <oyuncu> [sifirla]"); return true; }
                Player t = Bukkit.getPlayerExact(a[0]); if (t == null) { s.sendMessage("§cOyuncu çevrimiçi değil."); return true; }
                if (a.length > 1 && a[1].equalsIgnoreCase("sifirla")) { Ctx.suspicion.reset(t.getUniqueId()); s.sendMessage("§aŞüphe puanı sıfırlandı."); return true; }
                s.sendMessage("§eToplam şüphe: " + String.format("%.1f", Ctx.suspicion.total(t.getUniqueId(), System.currentTimeMillis()))); Ctx.suspicion.history(t.getUniqueId(), 10).forEach(v -> s.sendMessage("§7" + v.check() + " +" + v.points() + " §8" + v.detail())); return true; });
            PerfService perf = new PerfService(this); cmd("perf").setExecutor(perf); pm.registerEvents(perf, this); pm.registerEvents(discordHooks, this);
            pm.registerEvents(new Listener() {
                @EventHandler public void onJoin(PlayerJoinEvent e) { Player p = e.getPlayer(); Bukkit.getScheduler().runTaskLater(DobloSuite.this, () -> { if (playerState.pending(p.getUniqueId()) && !Activities.busy(p.getUniqueId())) { playerState.restoreIfPending(p); p.sendMessage("§eÖnceki oyundan kalan envanterin geri yüklendi."); } }, 10L); duels.loadElo(p.getUniqueId()); }
            }, this);
            cmd("yedek").setExecutor((s, c, l, a) -> { if (!s.hasPermission("doblo.admin")) { s.sendMessage("§cYetkin yok."); return true; } String sub = a.length > 0 ? a[0] : "liste";
                try { switch (sub) { case "al" -> { runBackup(); s.sendMessage("§aYedekleme başlatıldı."); } case "dogrula" -> { for (Path p : backups.list()) s.sendMessage((backups.verify(p) ? "§a✔ " : "§c✖ ") + p.getFileName()); }
                    default -> backups.list().forEach(p -> s.sendMessage("§7" + p.getFileName())); } } catch (IOException e) { s.sendMessage("§cYedek hatası: " + e.getMessage()); } return true; });

            // ---- zamanlayıcılar ----
            long auto = 20L * cfg.getLong("settings.autosave-seconds", 300);
            Bukkit.getScheduler().runTaskTimer(this, () -> { Ctx.persist.saveAsync(); Ctx.punishments.save(); Menus.vaults.saveAllOpen(); }, auto, auto);
            Bukkit.getScheduler().runTaskTimer(this, () -> economyCommands.settleAuctions(), 200L, 200L);
            startBackups(); started = true;
            Ctx.discord(DiscordNotifier.Kind.SUCCESS, "Sunucu açıldı", "DobloSuite " + getPluginMeta().getVersion() + " — " + Bukkit.getVersion());
            long st = 20L * 60 * cfg.getLong("discord.status-minutes", 0); if (st > 0) Bukkit.getScheduler().runTaskTimer(this, () -> Ctx.discord(DiscordNotifier.Kind.INFO, "Sunucu durumu", Bukkit.getOnlinePlayers().size() + " oyuncu, TPS " + String.format("%.1f", Math.min(20, Bukkit.getTPS()[0]))), st, st);
            getLogger().info("DobloSuite etkin. Depolama: " + (Ctx.persist.sql() ? "MariaDB" : "YAML"));
        } catch (Exception e) {
            getLogger().severe("DobloSuite başlatılamadı: " + e.getMessage() + " — veri bütünlüğü için eklenti devre dışı bırakılıyor."); e.printStackTrace(); getServer().getPluginManager().disablePlugin(this);
        }
    }
    private static String env(String k, String def) { String v = System.getenv(k); return v == null || v.isBlank() ? (def == null ? "" : def) : v; }

    private void registerQuests() {
        var q = Ctx.quests; var D = QuestEngine.Period.DAILY; var W = QuestEngine.Period.WEEKLY; var S = QuestEngine.Period.SEASONAL;
        q.register(new QuestEngine.Quest("gunluk_blok_kir", "blocks_mined", 200, D, 40, 100, null)); q.register(new QuestEngine.Quest("gunluk_blok_koy", "blocks_placed", 150, D, 40, 100, null));
        q.register(new QuestEngine.Quest("gunluk_oldur", "player_kills", 5, D, 50, 150, null)); q.register(new QuestEngine.Quest("gunluk_sure", "playtime_min", 30, D, 40, 100, null));
        q.register(new QuestEngine.Quest("gunluk_mac", "match_played", 3, D, 60, 150, null)); q.register(new QuestEngine.Quest("gunluk_ada_blok", "island_blocks_placed", 100, D, 40, 100, null));
        q.register(new QuestEngine.Quest("haftalik_bedwars", "bedwars_win", 5, W, 200, 600, null)); q.register(new QuestEngine.Quest("haftalik_duels", "duels_win", 10, W, 200, 600, null));
        q.register(new QuestEngine.Quest("haftalik_murder", "murder_win", 5, W, 200, 600, null)); q.register(new QuestEngine.Quest("haftalik_ada_seviye", "island_level_up", 3, W, 200, 500, null));
 q.register(new QuestEngine.Quest("sezon_galibiyet", "match_won", 100, S, 800, 4000, "sezon_unvan"));
        q.register(new QuestEngine.Quest("ilk_ada", "island_created", 1, QuestEngine.Period.ONCE, 50, 250, null));
    }

    private void startBackups() {
        var cfg = getConfig(); Path root = getServer().getWorldContainer().toPath().toAbsolutePath().normalize(); Path dir = getDataFolder().toPath();
        backups = new BackupService(dir.resolve("backups"), cfg.getInt("backup.keep", 7));
        long mins = cfg.getLong("backup.interval-minutes", 0); if (mins > 0) Bukkit.getScheduler().runTaskTimer(this, this::runBackup, 20L * 60 * mins, 20L * 60 * mins);
    }


    /** Dünyaları ana thread'de kaydeder, veri anlık görüntüsünü alır, sıkıştırmayı asenkron yapar. Sıcak yedek: kritik yedek için sunucuyu durdur. */
    public void runBackup() {
        for (World w : Bukkit.getWorlds()) w.save(); Ctx.persist.saveAsync(); Ctx.punishments.save();
        Path root = getServer().getWorldContainer().toPath().toAbsolutePath().normalize(); Path dir = getDataFolder().toPath(); Path snap = dir.resolve("data-snapshot");
        Map<String, Path> src = new LinkedHashMap<>();
        for (World w : Bukkit.getWorlds()) { Path wf = w.getWorldFolder().toPath().toAbsolutePath().normalize(); if (wf.startsWith(root)) src.put("server/" + root.relativize(wf).toString().replace('\\', '/'), wf); }
        try {
            if (Files.exists(snap)) try (var w = Files.walk(snap)) { for (Path p : (Iterable<Path>) w.sorted(Comparator.reverseOrder())::iterator) Files.delete(p); }
            Files.createDirectories(snap);
            try (var w = Files.walk(dir)) { for (Path p : (Iterable<Path>) w.filter(Files::isRegularFile)::iterator) { String rel = dir.relativize(p).toString(); if (rel.startsWith("backups") || rel.startsWith("data-snapshot") || rel.startsWith("restore-staging") || rel.endsWith(".log") || rel.endsWith(".tmp") || rel.contains(".bak-")) continue;
                Path d = snap.resolve(rel); Files.createDirectories(d.getParent()); Files.copy(p, d, StandardCopyOption.REPLACE_EXISTING); } }
            src.put("plugin-data", snap);
        } catch (IOException e) { getLogger().warning("Veri anlık görüntüsü alınamadı: " + e.getMessage()); }
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try { Path z = backups.create("yedek", src); boolean ok = backups.verify(z); getLogger().info("Yedek: " + z.getFileName() + " doğrulama=" + ok);
                if (Ctx.persist.sql()) Ctx.persist.run(() -> { Ctx.persist.store().addBackupHistory(z.getFileName().toString(), ok, "otomatik/manuel"); return null; });
                Ctx.discord(ok ? DiscordNotifier.Kind.SUCCESS : DiscordNotifier.Kind.ERROR, ok ? "Yedek alındı" : "YEDEK DOĞRULANAMADI", z.getFileName().toString());
            } catch (IOException e) { getLogger().severe("Yedek başarısız: " + e.getMessage()); Ctx.discord(DiscordNotifier.Kind.ERROR, "Yedek başarısız", String.valueOf(e.getMessage())); }
        });
    }

    @Override public void onDisable() {
        if (bedwars != null) bedwars.shutdown(); if (duels != null) duels.shutdown(); if (murder != null) murder.shutdown();
        if (Menus.vaults != null) Menus.vaults.saveAllOpen();
        if (started && Ctx.persist != null) { Ctx.persist.saveBlocking(); if (Ctx.punishments != null) Ctx.punishments.save(); }
        if (Ctx.discord != null) { if (started) Ctx.discord(DiscordNotifier.Kind.WARN, "Sunucu kapanıyor", "DobloSuite devre dışı bırakılıyor."); Ctx.discord.flush(4000); Ctx.discord.close(); }
        if (discordHooks != null) discordHooks.close();
    }
}
