package xyz.doblosmp.clan;

import java.util.*;

public final class ClanService {
    public static final class Clan {
        public final String tag; public String name; public UUID leader;
        public final Set<UUID> members = new LinkedHashSet<>();
        public long points; public int wins, losses;
        Clan(String tag, String name, UUID leader) { this.tag = tag; this.name = name; this.leader = leader; members.add(leader); }
        public int level() { return 1 + (int) Math.floor(Math.sqrt(points / 100.0)); }
    }

    private final Map<String, Clan> clans = new HashMap<>();
    private final Map<UUID, String> byPlayer = new HashMap<>();
    private final Map<UUID, Set<String>> invites = new HashMap<>();
    private final int maxMembersBase;

    public ClanService(int maxMembersBase) { this.maxMembersBase = maxMembersBase; }

    public synchronized Clan create(UUID leader, String tag, String name) {
        tag = tag.toUpperCase(Locale.ROOT);
        if (!tag.matches("[A-Z0-9]{2,5}") || name.isBlank() || name.length() > 24) return null;
        if (clans.containsKey(tag) || byPlayer.containsKey(leader)) return null;
        Clan c = new Clan(tag, name, leader); clans.put(tag, c); byPlayer.put(leader, tag); return c;
    }
    /** Kayıttan yükleme (yalnızca başlangıçta). */
    public synchronized void load(String tag, String name, UUID leader, Collection<UUID> members, long points, int wins, int losses) {
        Clan c = new Clan(tag, name, leader); c.members.clear(); c.members.addAll(members); c.members.add(leader);
        c.points = points; c.wins = wins; c.losses = losses; clans.put(tag, c); c.members.forEach(m -> byPlayer.put(m, tag));
    }
    public synchronized Clan of(UUID p) { String t = byPlayer.get(p); return t == null ? null : clans.get(t); }
    public synchronized Clan byTag(String tag) { return clans.get(tag.toUpperCase(Locale.ROOT)); }
    public int capacity(Clan c) { return maxMembersBase + 5 * (c.level() - 1); }

    public synchronized boolean invite(UUID by, UUID target) {
        Clan c = of(by);
        if (c == null || !c.leader.equals(by) || byPlayer.containsKey(target) || c.members.size() >= capacity(c)) return false;
        invites.computeIfAbsent(target, k -> new HashSet<>()).add(c.tag); return true;
    }
    public synchronized boolean accept(UUID p, String tag) {
        tag = tag.toUpperCase(Locale.ROOT);
        Set<String> inv = invites.get(p); Clan c = clans.get(tag);
        if (c == null || inv == null || !inv.contains(tag) || byPlayer.containsKey(p) || c.members.size() >= capacity(c)) return false;
        c.members.add(p); byPlayer.put(p, tag); invites.remove(p); return true;
    }
    public synchronized boolean kick(UUID by, UUID target) {
        Clan c = of(by);
        if (c == null || !c.leader.equals(by) || by.equals(target) || !c.members.remove(target)) return false;
        byPlayer.remove(target); return true;
    }
    /** Lider ayrılırsa lider devredilir; son üye ayrılırsa klan silinir. */
    public synchronized boolean leave(UUID p) {
        Clan c = of(p); if (c == null) return false;
        c.members.remove(p); byPlayer.remove(p);
        if (c.members.isEmpty()) clans.remove(c.tag);
        else if (c.leader.equals(p)) c.leader = c.members.iterator().next();
        return true;
    }
    public synchronized boolean transfer(UUID by, UUID to) {
        Clan c = of(by);
        if (c == null || !c.leader.equals(by) || !c.members.contains(to)) return false;
        c.leader = to; return true;
    }
    public synchronized boolean disband(UUID by) {
        Clan c = of(by); if (c == null || !c.leader.equals(by)) return false;
        c.members.forEach(byPlayer::remove); clans.remove(c.tag); return true;
    }
    public synchronized void addPoints(Clan c, long n) { if (n > 0) c.points += n; }

    /** Klan savaşı sonucu: galip puan kazanır, mağlup puan kaybeder (0'ın altına inmez). */
    public synchronized boolean recordWar(String winnerTag, String loserTag, long points) {
        Clan w = byTag(winnerTag), l = byTag(loserTag);
        if (w == null || l == null || w == l || points <= 0) return false;
        w.wins++; l.losses++; w.points += points; l.points = Math.max(0, l.points - points / 2);
        return true;
    }
    public synchronized List<Clan> ranking(int limit) {
        return clans.values().stream().sorted(Comparator.comparingLong((Clan c) -> c.points).reversed()).limit(limit).toList();
    }
    /** Eşzamansız kayıt için derin kopya. */
    public synchronized List<Clan> snapshot() {
        List<Clan> out = new ArrayList<>();
        for (Clan c : clans.values()) { Clan k = new Clan(c.tag, c.name, c.leader); k.members.clear(); k.members.addAll(c.members); k.points = c.points; k.wins = c.wins; k.losses = c.losses; out.add(k); }
        return out;
    }
    public synchronized Collection<Clan> all() { return new ArrayList<>(clans.values()); }
}
