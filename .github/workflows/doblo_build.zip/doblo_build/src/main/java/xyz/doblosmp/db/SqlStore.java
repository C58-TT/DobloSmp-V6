package xyz.doblosmp.db;

import xyz.doblosmp.clan.ClanService;
import xyz.doblosmp.economy.AuctionHouse;
import xyz.doblosmp.economy.Ledger;
import xyz.doblosmp.sb.*;

import java.sql.*;
import java.util.*;

/** Tüm kalıcı veriler için hazır ifadeli (PreparedStatement) SQL erişimi. Her snapshot tek transaction'dır. */
public final class SqlStore {
    private final Database db;
    public SqlStore(Database db) { this.db = db; }

    // ---------- ekonomi ----------
    public void saveBalances(Map<String, Map<UUID, Long>> snap) throws SQLException {
        db.tx(c -> {
            try (Statement s = c.createStatement()) { s.executeUpdate("DELETE FROM balances"); }
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO balances(mode_name,uuid,amount) VALUES(?,?,?)")) {
                for (var m : snap.entrySet()) for (var e : m.getValue().entrySet()) { ps.setString(1, m.getKey()); ps.setString(2, e.getKey().toString()); ps.setLong(3, e.getValue()); ps.addBatch(); }
                ps.executeBatch();
            }
            return null; });
    }
    public Map<String, Map<UUID, Long>> loadBalances() throws SQLException {
        return db.read(c -> { Map<String, Map<UUID, Long>> out = new HashMap<>();
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT mode_name,uuid,amount FROM balances")) {
                while (rs.next()) out.computeIfAbsent(rs.getString(1), k -> new HashMap<>()).put(UUID.fromString(rs.getString(2)), rs.getLong(3)); }
            return out; });
    }
    public void appendLedger(List<Ledger.Entry> entries) throws SQLException {
        if (entries.isEmpty()) return;
        db.tx(c -> { try (PreparedStatement ps = c.prepareStatement("INSERT INTO ledger_log(ts,mode_name,from_uuid,to_uuid,amount,reason) VALUES(?,?,?,?,?,?)")) {
            for (var e : entries) { ps.setLong(1, e.time()); ps.setString(2, e.mode()); ps.setString(3, e.from().toString()); ps.setString(4, e.to().toString()); ps.setLong(5, e.amount()); ps.setString(6, e.reason().length() > 64 ? e.reason().substring(0, 64) : e.reason()); ps.addBatch(); }
            ps.executeBatch(); } return null; });
    }
    public long ledgerCount() throws SQLException { return db.read(c -> { try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT COUNT(*) FROM ledger_log")) { rs.next(); return rs.getLong(1); } }); }

    // ---------- klan ----------
    public void saveClans(Collection<ClanService.Clan> clans) throws SQLException {
        db.tx(c -> {
            try (Statement s = c.createStatement()) { s.executeUpdate("DELETE FROM clan_members"); s.executeUpdate("DELETE FROM clans"); }
            try (PreparedStatement a = c.prepareStatement("INSERT INTO clans(tag,clan_name,leader,points,wins,losses) VALUES(?,?,?,?,?,?)");
                 PreparedStatement b = c.prepareStatement("INSERT INTO clan_members(uuid,tag) VALUES(?,?)")) {
                for (var k : clans) { a.setString(1, k.tag); a.setString(2, k.name); a.setString(3, k.leader.toString()); a.setLong(4, k.points); a.setInt(5, k.wins); a.setInt(6, k.losses); a.addBatch();
                    for (UUID m : k.members) { b.setString(1, m.toString()); b.setString(2, k.tag); b.addBatch(); } }
                a.executeBatch(); b.executeBatch(); }
            return null; });
    }
    public void loadClans(ClanService svc) throws SQLException {
        db.read(c -> { Map<String, List<UUID>> mem = new HashMap<>();
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT uuid,tag FROM clan_members")) { while (rs.next()) mem.computeIfAbsent(rs.getString(2), k -> new ArrayList<>()).add(UUID.fromString(rs.getString(1))); }
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT tag,clan_name,leader,points,wins,losses FROM clans")) {
                while (rs.next()) svc.load(rs.getString(1), rs.getString(2), UUID.fromString(rs.getString(3)), mem.getOrDefault(rs.getString(1), List.of()), rs.getLong(4), rs.getInt(5), rs.getInt(6)); }
            return null; });
    }

    // ---------- arkadaşlar ----------
    public void saveFriends(Map<UUID, Set<UUID>> friends) throws SQLException {
        db.tx(c -> { try (Statement s = c.createStatement()) { s.executeUpdate("DELETE FROM friends"); }
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO friends(a,b) VALUES(?,?)")) {
                for (var e : friends.entrySet()) for (UUID b : e.getValue()) { ps.setString(1, e.getKey().toString()); ps.setString(2, b.toString()); ps.addBatch(); } ps.executeBatch(); }
            return null; });
    }
    public Map<UUID, Set<UUID>> loadFriends() throws SQLException {
        return db.read(c -> { Map<UUID, Set<UUID>> out = new HashMap<>();
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT a,b FROM friends")) { while (rs.next()) out.computeIfAbsent(UUID.fromString(rs.getString(1)), k -> new HashSet<>()).add(UUID.fromString(rs.getString(2))); }
            return out; });
    }

    // ---------- cezalar ----------
    public void addPunishment(long ts, String type, String player, String reason, long seconds, String staff) throws SQLException {
        db.tx(c -> { try (PreparedStatement ps = c.prepareStatement("INSERT INTO punishments(ts,ptype,player,reason,seconds,staff) VALUES(?,?,?,?,?,?)")) {
            ps.setLong(1, ts); ps.setString(2, type); ps.setString(3, player); ps.setString(4, reason.length() > 255 ? reason.substring(0, 255) : reason); ps.setLong(5, seconds); ps.setString(6, staff); ps.executeUpdate(); } return null; });
    }
    public List<Map<String, Object>> punishments(String player, int limit) throws SQLException {
        return db.read(c -> { List<Map<String, Object>> out = new ArrayList<>();
            String sql = "SELECT ts,ptype,player,reason,seconds,staff FROM punishments" + (player == null || player.isBlank() ? "" : " WHERE LOWER(player)=LOWER(?)") + " ORDER BY id DESC LIMIT ?";
            try (PreparedStatement ps = c.prepareStatement(sql)) { int i = 1; if (player != null && !player.isBlank()) ps.setString(i++, player); ps.setInt(i, limit);
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) { Map<String, Object> m = new LinkedHashMap<>(); m.put("time", rs.getLong(1)); m.put("type", rs.getString(2)); m.put("player", rs.getString(3)); m.put("reason", rs.getString(4)); m.put("seconds", rs.getLong(5)); m.put("staff", rs.getString(6)); out.add(m); } } }
            return out; });
    }
    public void setMute(String player, long untilTs) throws SQLException {
        db.tx(c -> { try (PreparedStatement d = c.prepareStatement("DELETE FROM mutes WHERE player=?"); PreparedStatement i = c.prepareStatement("INSERT INTO mutes(player,until_ts) VALUES(?,?)")) {
            d.setString(1, player.toLowerCase(Locale.ROOT)); d.executeUpdate(); if (untilTs >= 0) { i.setString(1, player.toLowerCase(Locale.ROOT)); i.setLong(2, untilTs); i.executeUpdate(); } } return null; });
    }
    public Map<String, Long> loadMutes() throws SQLException {
        return db.read(c -> { Map<String, Long> m = new HashMap<>(); try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT player,until_ts FROM mutes")) { while (rs.next()) m.put(rs.getString(1), rs.getLong(2)); } return m; });
    }

    // ---------- açık artırma ----------
    public void saveAuctions(List<AuctionHouse.Listing> ls) throws SQLException {
        db.tx(c -> { try (Statement s = c.createStatement()) { s.executeUpdate("DELETE FROM auctions"); }
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO auctions(id,seller,item,amount,price,is_auction,ends_at,top_bidder,top_bid) VALUES(?,?,?,?,?,?,?,?,?)")) {
                for (var l : ls) { ps.setLong(1, l.id()); ps.setString(2, l.seller().toString()); ps.setString(3, l.item()); ps.setInt(4, l.amount()); ps.setLong(5, l.price()); ps.setBoolean(6, l.auction()); ps.setLong(7, l.endsAt());
                    ps.setString(8, l.topBidder() == null ? null : l.topBidder().toString()); ps.setLong(9, l.topBid()); ps.addBatch(); } ps.executeBatch(); }
            return null; });
    }
    public void loadAuctions(AuctionHouse ah) throws SQLException {
        db.read(c -> { try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT id,seller,item,amount,price,is_auction,ends_at,top_bidder,top_bid FROM auctions")) {
            while (rs.next()) { String tb = rs.getString(8); ah.restore(new AuctionHouse.Listing(rs.getLong(1), UUID.fromString(rs.getString(2)), rs.getString(3), rs.getInt(4), rs.getLong(5), rs.getBoolean(6), rs.getLong(7), tb == null ? null : UUID.fromString(tb), rs.getLong(9))); } }
            return null; });
    }

    // ---------- adalar ----------
    private static String enc(Map<?, ?> m) { StringBuilder b = new StringBuilder(); m.forEach((k, v) -> b.append(k).append('=').append(v).append(';')); return b.toString(); }
    public void saveIslands(Collection<Island> all) throws SQLException {
        db.tx(c -> {
            try (Statement s = c.createStatement()) { for (String t : List.of("island_ratings", "island_bans", "island_members", "islands")) s.executeUpdate("DELETE FROM " + t); }
            try (PreparedStatement a = c.prepareStatement("INSERT INTO islands(id,owner,slot,template,resets,home_x,home_y,home_z,flags,required,created) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
                 PreparedStatement m = c.prepareStatement("INSERT INTO island_members(island_id,uuid,role_name) VALUES(?,?,?)");
                 PreparedStatement b = c.prepareStatement("INSERT INTO island_bans(island_id,uuid) VALUES(?,?)");
                 PreparedStatement r = c.prepareStatement("INSERT INTO island_ratings(island_id,uuid,score) VALUES(?,?,?)")) {
                for (Island i : all) {
                    a.setLong(1, i.id); a.setString(2, i.owner.toString()); a.setInt(3, i.slot); a.setString(4, i.template); a.setInt(5, i.resets);
                    a.setDouble(6, i.homeX); a.setDouble(7, i.homeY); a.setDouble(8, i.homeZ); a.setString(9, enc(i.flags)); a.setString(10, enc(i.required)); a.setLong(11, i.createdAt); a.addBatch();
                    i.members.forEach((u, role) -> { try { m.setLong(1, i.id); m.setString(2, u.toString()); m.setString(3, role.name()); m.addBatch(); } catch (SQLException e) { throw new IllegalStateException(e); } });
                    for (UUID u : i.bans) { b.setLong(1, i.id); b.setString(2, u.toString()); b.addBatch(); }
                    i.ratings.forEach((u, sc) -> { try { r.setLong(1, i.id); r.setString(2, u.toString()); r.setInt(3, sc); r.addBatch(); } catch (SQLException e) { throw new IllegalStateException(e); } });
                }
                a.executeBatch(); m.executeBatch(); b.executeBatch(); r.executeBatch();
            }
            return null; });
    }
    public void loadIslands(IslandRegistry reg) throws SQLException {
        db.read(c -> {
            Map<Long, Island> map = new HashMap<>();
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT id,owner,slot,template,resets,home_x,home_y,home_z,flags,required FROM islands")) {
                while (rs.next()) { Island i = reg.restore(rs.getLong(1), UUID.fromString(rs.getString(2)), rs.getInt(3), rs.getString(4));
                    i.resets = rs.getInt(5); i.homeX = rs.getDouble(6); i.homeY = rs.getDouble(7); i.homeZ = rs.getDouble(8);
                    String fl = rs.getString(9); if (fl != null) for (String kv : fl.split(";")) { String[] p = kv.split("=", 2); if (p.length == 2) i.flags.put(p[0], Boolean.parseBoolean(p[1])); }
                    String rq = rs.getString(10); if (rq != null) for (String kv : rq.split(";")) { String[] p = kv.split("=", 2); if (p.length == 2) try { i.required.put(Perm.valueOf(p[0]), Role.valueOf(p[1])); } catch (IllegalArgumentException ignored) {} }
                    map.put(i.id, i); } }
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT island_id,uuid,role_name FROM island_members")) { while (rs.next()) { Island i = map.get(rs.getLong(1)); if (i != null) reg.restoreMember(i, UUID.fromString(rs.getString(2)), Role.valueOf(rs.getString(3))); } }
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT island_id,uuid FROM island_bans")) { while (rs.next()) { Island i = map.get(rs.getLong(1)); if (i != null) i.bans.add(UUID.fromString(rs.getString(2))); } }
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT island_id,uuid,score FROM island_ratings")) { while (rs.next()) { Island i = map.get(rs.getLong(1)); if (i != null) i.ratings.put(UUID.fromString(rs.getString(2)), rs.getInt(3)); } }
            return null; });
    }

    // ---------- istatistik / duels / yedek ----------
    /** Atomik upsert: eşzamanlı ilk yazımda bile satır kaybı/çakışma olmaz. */
    public void addStat(UUID p, String game, String stat, long delta) throws SQLException {
        db.tx(c -> { try (PreparedStatement ps = c.prepareStatement("INSERT INTO stats(uuid,game,stat,amount) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE amount=amount+VALUES(amount)")) {
            ps.setString(1, p.toString()); ps.setString(2, game); ps.setString(3, stat); ps.setLong(4, delta); ps.executeUpdate(); } return null; });
    }
    public long stat(UUID p, String game, String stat) throws SQLException {
        return db.read(c -> { try (PreparedStatement ps = c.prepareStatement("SELECT amount FROM stats WHERE uuid=? AND game=? AND stat=?")) { ps.setString(1, p.toString()); ps.setString(2, game); ps.setString(3, stat); try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getLong(1) : 0L; } } });
    }
    public void setElo(UUID p, String kit, int elo) throws SQLException {
        db.tx(c -> { try (PreparedStatement ps = c.prepareStatement("INSERT INTO duel_elo(uuid,kit,elo) VALUES(?,?,?) ON DUPLICATE KEY UPDATE elo=VALUES(elo)")) {
            ps.setString(1, p.toString()); ps.setString(2, kit); ps.setInt(3, elo); ps.executeUpdate(); } return null; });
    }
    public int elo(UUID p, String kit) throws SQLException {
        return db.read(c -> { try (PreparedStatement ps = c.prepareStatement("SELECT elo FROM duel_elo WHERE uuid=? AND kit=?")) { ps.setString(1, p.toString()); ps.setString(2, kit); try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 1000; } } });
    }
    /** Elo sıralaması (en yüksekten): {uuid, elo}. */
    public List<Map.Entry<UUID, Integer>> topElo(String kit, int n) throws SQLException {
        return db.read(c -> { try (PreparedStatement ps = c.prepareStatement("SELECT uuid,elo FROM duel_elo WHERE kit=? ORDER BY elo DESC LIMIT ?")) {
            ps.setString(1, kit); ps.setInt(2, Math.max(1, Math.min(50, n))); List<Map.Entry<UUID, Integer>> out = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(Map.entry(UUID.fromString(rs.getString(1)), rs.getInt(2))); } return out; } });
    }
    public void addDuelHistory(String kit, UUID w, UUID l, int delta, boolean ranked) throws SQLException {
        db.tx(c -> { try (PreparedStatement ps = c.prepareStatement("INSERT INTO duel_history(ts,kit,winner,loser,elo_delta,ranked) VALUES(?,?,?,?,?,?)")) { ps.setLong(1, System.currentTimeMillis()); ps.setString(2, kit); ps.setString(3, w.toString()); ps.setString(4, l.toString()); ps.setInt(5, delta); ps.setBoolean(6, ranked); ps.executeUpdate(); } return null; });
    }
    public void addBackupHistory(String name, boolean ok, String note) throws SQLException {
        db.tx(c -> { try (PreparedStatement ps = c.prepareStatement("INSERT INTO backup_history(ts,name,ok,note) VALUES(?,?,?,?)")) { ps.setLong(1, System.currentTimeMillis()); ps.setString(2, name); ps.setBoolean(3, ok); ps.setString(4, note); ps.executeUpdate(); } return null; });
    }
    public List<Map<String, Object>> backupHistory(int n) throws SQLException {
        return db.read(c -> { List<Map<String, Object>> out = new ArrayList<>(); try (PreparedStatement ps = c.prepareStatement("SELECT ts,name,ok,note FROM backup_history ORDER BY id DESC LIMIT ?")) { ps.setInt(1, n);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(Map.of("time", rs.getLong(1), "name", rs.getString(2), "ok", rs.getBoolean(3), "note", String.valueOf(rs.getString(4)))); } } return out; });
    }

    // ---------- görevler ----------
    private static String join(Collection<?> c) { StringBuilder b = new StringBuilder(); for (Object o : c) b.append(o).append(','); return b.toString(); }
    private static List<String> split(String s) { List<String> l = new ArrayList<>(); if (s != null) for (String x : s.split(",")) if (!x.isBlank()) l.add(x); return l; }
    public void saveQuests(xyz.doblosmp.quest.QuestEngine q) throws SQLException {
        db.tx(c -> {
            try (Statement s = c.createStatement()) { s.executeUpdate("DELETE FROM quest_progress"); s.executeUpdate("DELETE FROM quest_player"); }
            try (PreparedStatement a = c.prepareStatement("INSERT INTO quest_player(uuid,pass_xp,streak,last_login,cosmetics,achievements,pass_claimed,claimed) VALUES(?,?,?,?,?,?,?,?)");
                 PreparedStatement b = c.prepareStatement("INSERT INTO quest_progress(uuid,quest_id,progress,period_key) VALUES(?,?,?,?)")) {
                for (var e : q.all().entrySet()) { var d = e.getValue(); String u = e.getKey().toString();
                    a.setString(1, u); a.setLong(2, d.passXp); a.setInt(3, d.streak); a.setString(4, d.lastLogin == null ? null : d.lastLogin.toString());
                    a.setString(5, join(d.cosmetics)); a.setString(6, join(d.achievements)); a.setString(7, join(d.passClaimed)); a.setString(8, join(d.claimed)); a.addBatch();
                    for (var pr : d.progress.entrySet()) { b.setString(1, u); b.setString(2, pr.getKey()); b.setInt(3, pr.getValue()); b.setString(4, d.periodKey.getOrDefault(pr.getKey(), "")); b.addBatch(); } }
                a.executeBatch(); b.executeBatch(); }
            return null; });
    }
    public void loadQuests(xyz.doblosmp.quest.QuestEngine q) throws SQLException {
        db.read(c -> {
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT uuid,pass_xp,streak,last_login,cosmetics,achievements,pass_claimed,claimed FROM quest_player")) {
                while (rs.next()) { var d = q.of(UUID.fromString(rs.getString(1))); d.passXp = rs.getLong(2); d.streak = rs.getInt(3); String ll = rs.getString(4); if (ll != null) d.lastLogin = java.time.LocalDate.parse(ll);
                    d.cosmetics.addAll(split(rs.getString(5))); d.achievements.addAll(split(rs.getString(6))); split(rs.getString(7)).forEach(x -> d.passClaimed.add(Integer.parseInt(x))); d.claimed.addAll(split(rs.getString(8))); } }
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT uuid,quest_id,progress,period_key FROM quest_progress")) {
                while (rs.next()) { var d = q.of(UUID.fromString(rs.getString(1))); d.progress.put(rs.getString(2), rs.getInt(3)); d.periodKey.put(rs.getString(2), rs.getString(4)); } }
            return null; });
    }
    // ---------- oyuncular ----------
    public void touchPlayer(UUID p, String name, boolean bedrock, long addMinutes) throws SQLException {
        long now = System.currentTimeMillis();
        db.tx(c -> { try (PreparedStatement ps = c.prepareStatement("INSERT INTO players(uuid,name,first_seen,last_seen,playtime_min,bedrock) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name), last_seen=VALUES(last_seen), bedrock=VALUES(bedrock), playtime_min=playtime_min+VALUES(playtime_min)")) {
            ps.setString(1, p.toString()); ps.setString(2, name); ps.setLong(3, now); ps.setLong(4, now); ps.setLong(5, addMinutes); ps.setBoolean(6, bedrock); ps.executeUpdate(); } return null; });
    }
}
