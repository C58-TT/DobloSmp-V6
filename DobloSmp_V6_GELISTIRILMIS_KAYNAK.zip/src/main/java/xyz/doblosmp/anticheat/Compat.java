package xyz.doblosmp.anticheat;

import java.util.Set;

/** GrimAC/Vulcan gibi bakımı yapılan anti-cheat varsa çakışmayı önler: hareket/savaş yaptırımları kapanır, yalnızca tamamlayıcı kontroller çalışır. */
public final class Compat {
    private Compat() {}
    public enum Mode { STANDALONE, COMPLEMENT }
    public static Mode detect(Set<String> installedPlugins, String configured) {
        if ("standalone".equalsIgnoreCase(configured)) return Mode.STANDALONE;
        if ("complement".equalsIgnoreCase(configured)) return Mode.COMPLEMENT;
        for (String p : installedPlugins) { String l = p.toLowerCase(); if (l.equals("grimac") || l.equals("grim") || l.equals("vulcan") || l.equals("themis") || l.equals("matrix")) return Mode.COMPLEMENT; }
        return Mode.STANDALONE;
    }
    /** COMPLEMENT modunda Grim'in zaten kapsadığı kontroller bizde kapalıdır. */
    public static boolean checkActive(Mode m, String check) {
        if (m == Mode.STANDALONE) return true;
        return switch (check) { case "speed", "fly", "reach", "killaura", "nofall", "scaffold" -> false; default -> true; };
    }
}
