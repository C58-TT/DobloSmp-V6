package xyz.doblosmp.anticheat;

/**
 * Saf, durumsuz kontrol hesapları. Hepsi yanlış pozitifi azaltmak için ping/TPS toleransı alır;
 * dönen değer 0 ise ihlal yok, >0 ise eklenecek şüphe puanıdır.
 */
public final class Checks {
    private Checks() {}

    /** Sunucu ağır yükteyse veya ping çok yüksekse kontrol atlanır. */
    public static boolean shouldSkip(double tps, int pingMs, double minTps, int maxPing) { return tps < minTps || pingMs > maxPing; }

    /** Reach: ölçülen mesafe izin verilenden (3.0 + ping toleransı) büyükse puan. */
    public static double reach(double distance, int pingMs, boolean creative) {
        if (creative) return 0;
        double allowed = 3.1 + Math.min(0.6, pingMs / 1000.0 * 2.0);
        return distance > allowed + 0.35 ? Math.min(5.0, (distance - allowed) * 2.0) : 0;
    }

    /** Yatay hız: izin verilen azami (hız iksiri/zemin dahil) değerin %15 üstü ihlaldir. */
    public static double speed(double horizontalPerTick, int speedAmp, boolean onIce, boolean sprinting, int pingMs) {
        double max = sprinting ? 0.36 : 0.28;
        max *= 1.0 + 0.2 * (speedAmp + 1) * (speedAmp >= 0 ? 1 : 0);
        if (onIce) max *= 1.8;
        max *= 1.15 + Math.min(0.25, pingMs / 1000.0);
        return horizontalPerTick > max ? Math.min(4.0, (horizontalPerTick - max) * 10.0) : 0;
    }

    /** Fly: havada üst üste N tick boyunca dikey hız ~0 veya yükseliyorsa puan. */
    public static double fly(int airTicks, double deltaY, boolean nearClimbableOrLiquid, boolean slowFalling) {
        if (nearClimbableOrLiquid || slowFalling || airTicks < 10) return 0;
        return deltaY >= -0.02 ? 1.0 + Math.min(2.0, airTicks / 20.0) : 0;
    }

    /** NoFall: düşme mesafesi 3 bloktan fazla ama hasar sunucuda uygulanmadı / yerde bayrağı sahte. */
    public static double noFall(double fallDistance, boolean claimedOnGround, boolean actuallyOnGround, boolean damageWillApply) {
        if (fallDistance <= 3.5) return 0;
        return (claimedOnGround && !actuallyOnGround) || (!damageWillApply && claimedOnGround) ? 2.0 : 0;
    }

    /** KillAura: aynı tick penceresinde farklı hedeflere vuruş ve/veya baktığı yönden büyük sapma. */
    public static double killAura(int distinctTargetsIn500ms, double aimErrorDegrees, double cps) {
        double p = 0;
        if (distinctTargetsIn500ms >= 3) p += 2.0;
        if (aimErrorDegrees > 55) p += 1.5;
        if (cps > 18) p += 1.0;
        return p;
    }

    /** Scaffold: arkaya bakmadan yüksek hızla blok koyma + sprint. */
    public static double scaffold(double blocksPerSecond, double pitchDeg, boolean sprinting, boolean placedBelowWhileMoving) {
        if (!placedBelowWhileMoving) return 0;
        double p = 0;
        if (blocksPerSecond > 8.5) p += 2.0;
        if (sprinting && blocksPerSecond > 5.5) p += 1.5;
        if (pitchDeg < 20) p += 1.0; // yere bakmadan aşağıya blok
        return p;
    }

    /** X-Ray: kazılan taşa oranla ender cevher oranı. */
    public static double xray(int diamondOrAncientDebris, int totalMined, int unlitOrCaveExposed) {
        if (totalMined < 40) return 0;
        double ratio = (double) diamondOrAncientDebris / totalMined;
        double directness = totalMined == 0 ? 0 : 1.0 - (double) unlitOrCaveExposed / Math.max(1, diamondOrAncientDebris);
        return ratio > 0.12 && directness > 0.7 ? Math.min(5.0, ratio * 20) : 0;
    }

    /** Envanter hilesi: hareket ederken/saldırırken envanter açık. */
    public static double inventory(boolean inventoryOpen, double horizontalSpeed, boolean attacked) {
        return inventoryOpen && (horizontalSpeed > 0.12 || attacked) ? 1.0 : 0;
    }

    /** AutoTotem: totem patladıktan sonra 50 ms'den hızlı geri koyma. */
    public static double autoTotem(long msBetweenPopAndReequip) { return msBetweenPopAndReequip >= 0 && msBetweenPopAndReequip < 50 ? 2.0 : 0; }

    /** AutoCrystal: kristal koyma+patlatma aralığı insan hızının altında. */
    public static double autoCrystal(long msBetweenPlaceAndBreak, int streak) { return msBetweenPlaceAndBreak < 60 && streak >= 4 ? 2.5 : 0; }

    /** Paket exploit: saniyedeki paket sayısı veya NaN/aşırı koordinat. */
    public static double packet(int packetsPerSecond, double x, double y, double z) {
        if (Double.isNaN(x + y + z) || Double.isInfinite(x + y + z) || Math.abs(x) > 3.0E7 || Math.abs(z) > 3.0E7) return 10.0;
        return packetsPerSecond > 400 ? 3.0 : 0;
    }
}
