# DobloSuite V6 derleme (Türkçe)

## Gereksinimler
- Linux veya Windows üzerinde Java 21 JDK
- İlk derlemede internet erişimi (Maven ve Paper API/bağımlılıkları indirilir)
- Yaklaşık birkaç yüz MB boş disk alanı

## Linux / VPS
Proje klasöründe:

```bash
chmod +x mvnw scripts/build.sh
./scripts/build.sh
```

İlk çalıştırmada Maven 3.9.9 indirilir (sistemde Maven varsa mevcut Maven kullanılır). Başarılı derlemede dosya `dist/DobloSuite-6.0.0.jar` konumuna kopyalanır.

## Windows
Java 21 ve Maven kuruluysa proje klasöründe:

```bat
mvn -U clean package
```

JAR: `target\DobloSuite-6.0.0.jar`

## Sunucuya kurulum
1. Sunucuyu durdurun ve `plugins` klasörünü yedekleyin.
2. Yalnızca `DobloSuite-6.0.0.jar` dosyasını `plugins/` klasörüne koyun.
3. Lobi haritasını proje içindeki `worlds/lobby-world/` klasöründen sunucu ana dizinine `lobby/` adıyla kopyalayın. Mevcut `lobby/` varsa üzerine yazmayın.
4. Sunucuyu başlatın ve konsolda `DobloSuite etkin` mesajını kontrol edin.
5. Oyuncu olarak `/lobby`, `/menu`, `/dnpc list` komutlarını test edin. `/dnpc` yönetici izni ister.
6. Lobi spawn konumuna gidip `/lobbyspawn` çalıştırın.

## Önemli sınırlar
- Paper 1.21.11 üzerinde bu paket için gerçek derleme ve canlı sunucu testi henüz yapılmış değildir.
- İlk derleme sırasında Paper deposu erişilebilir olmalıdır. DNS/internet yoksa Maven bağımlılıkları indirilemez.
- Bu JAR tek başına ayrı oyun sunucuları/arenalar oluşturmaz. BedWars, Duels ve Murder Mystery için arena konumlarının yönetim komutlarıyla ayarlanması gerekir.
- Geyser/Floodgate, LuckPerms gibi harici eklentiler ayrıca kurulur ve yapılandırılır.
- `database.enabled` varsayılan olarak `false`; başlangıçta YAML saklama kullanılır.
