package xyz.doblosmp.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.function.BiConsumer;

/**
 * Kendi hafif NPC sistemi (Villager, AI kapalı, ölümsüz, kalıcı). Citizens GEREKTİRMEZ; Citizens entegrasyonu yapılmadı.
 * Eylemler: skyblock, bedwars, duels, murder, market, kasa, profil, quests, friends, party, clan, menu.
 * Oyun içi mağaza NPC'leri oyun tarafından "bw-shop"/"bw-upgrade" etiketiyle yaratılır.
 */
public final class NpcManager implements CommandExecutor, Listener {
    private final NamespacedKey key; private final Map<String, BiConsumer<Player, String>> actions = new LinkedHashMap<>(); private final JavaPlugin plugin;
    public NpcManager(JavaPlugin plugin) {
        this.plugin = plugin; key = new NamespacedKey(plugin, "npc_action");
        actions.put("skyblock", (p, a) -> p.performCommand("is"));
        actions.put("bedwars", (p, a) -> Menus.bedwars(p));
        actions.put("duels", (p, a) -> Menus.duels(p));
        actions.put("murder", (p, a) -> p.performCommand("mm join"));
        actions.put("market", (p, a) -> Menus.market(p, 0));
        actions.put("kasa", (p, a) -> Menus.vaults.open(p));
        actions.put("profil", (p, a) -> Menus.profile(p));
        actions.put("quests", (p, a) -> Menus.quests(p));
        actions.put("friends", (p, a) -> Menus.friends(p));
        actions.put("party", (p, a) -> Menus.party(p));
        actions.put("clan", (p, a) -> Menus.clan(p));
        actions.put("menu", (p, a) -> Menus.main(p));
        // LobbyManager aynı açılış akışında biraz sonra dünyayı yükler.
        Bukkit.getScheduler().runTaskLater(plugin, this::ensureDefaultLobbyNpcs, 40L);
    }
    /** Oyun modülleri kendi NPC eylemlerini kaydeder (ör. bw-shop). */
    public void register(String action, BiConsumer<Player, String> h) { actions.put(action, h); }
    public NamespacedKey key() { return key; }

    /** Lobi dünyasında eksik varsayılan NPC'leri bir kez oluşturur; mevcut NPC'lere dokunmaz. */
    private void ensureDefaultLobbyNpcs() {
        if (!plugin.getConfig().getBoolean("lobby.npcs.enabled", true)) return;
        String worldName = plugin.getConfig().getString("lobby.world", "lobby");
        org.bukkit.World world = Bukkit.getWorld(worldName);
        if (world == null) {
            plugin.getLogger().warning("Lobi NPC'leri oluşturulamadı: '" + worldName + "' dünyası yüklü değil.");
            return;
        }
        Location base = world.getSpawnLocation().clone();
        if (plugin.getConfig().contains("lobby.spawn.x")) {
            base = new Location(world,
                plugin.getConfig().getDouble("lobby.spawn.x"),
                plugin.getConfig().getDouble("lobby.spawn.y"),
                plugin.getConfig().getDouble("lobby.spawn.z"),
                (float) plugin.getConfig().getDouble("lobby.spawn.yaw", 0),
                (float) plugin.getConfig().getDouble("lobby.spawn.pitch", 0));
        }
        record DefaultNpc(String action, String title, int dx, int dz) {}
        List<DefaultNpc> defaults = List.of(
            new DefaultNpc("skyblock", "§a§lSKYBLOCK", -5, 0),
            new DefaultNpc("bedwars", "§c§lBEDWARS", -4, 3),
            new DefaultNpc("duels", "§b§lDUELS", -2, 5),
            new DefaultNpc("murder", "§4§lMURDER MYSTERY", 2, 5),
            new DefaultNpc("market", "§6§lMARKET", 4, 3),
            new DefaultNpc("quests", "§e§lGÖREVLER", 5, 0),
            new DefaultNpc("friends", "§d§lARKADAŞLAR", 3, -4),
            new DefaultNpc("menu", "§b§lANA MENÜ", -3, -4)
        );
        // NPC'lerin kayıtlı olduğu spawn çevresi chunk'larını yükle; aksi hâlde yeniden
        // başlatmada yüklenmemiş chunk'taki NPC görünmeyip kopyası üretilebilir.
        for (DefaultNpc npc : defaults) {
            int x = base.getBlockX() + npc.dx();
            int z = base.getBlockZ() + npc.dz();
            world.getChunkAt(x >> 4, z >> 4).load();
        }
        Set<String> present = new HashSet<>();
        for (Villager villager : world.getEntitiesByClass(Villager.class)) {
            String action = actionOf(villager);
            if (action != null) present.add(action);
        }
        int created = 0;
        for (DefaultNpc npc : defaults) {
            if (present.contains(npc.action())) continue;
            int x = base.getBlockX() + npc.dx();
            int z = base.getBlockZ() + npc.dz();
            org.bukkit.block.Block floor = world.getHighestBlockAt(x, z);
            Location at = floor.getType().isSolid()
                ? floor.getLocation().add(0.5, 1.0, 0.5)
                : new Location(world, x + 0.5, base.getY(), z + 0.5);
            at.setYaw(base.getYaw());
            spawn(at, npc.action(), npc.title());
            created++;
        }
        if (created > 0) plugin.getLogger().info("Lobi için " + created + " varsayılan NPC oluşturuldu.");
        else plugin.getLogger().info("Lobi NPC'leri zaten mevcut; yeni NPC oluşturulmadı.");
    }

    public Villager spawn(Location l, String action, String title) {
        Villager v = (Villager) l.getWorld().spawnEntity(l, EntityType.VILLAGER);
        v.setAI(false); v.setInvulnerable(true); v.setSilent(true); v.setPersistent(true); v.setRemoveWhenFarAway(false); v.setCollidable(false);
        v.setCanPickupItems(false);
        v.customName(Menu.color(title)); v.setCustomNameVisible(true); v.getPersistentDataContainer().set(key, PersistentDataType.STRING, action); return v;
    }
    public String actionOf(Entity e) { return e.getPersistentDataContainer().get(key, PersistentDataType.STRING); }

    @EventHandler(priority = EventPriority.HIGH) public void onClick(PlayerInteractEntityEvent e) {
        String a = actionOf(e.getRightClicked()); if (a == null) return; e.setCancelled(true);
        BiConsumer<Player, String> h = actions.get(a.contains(":") ? a.substring(0, a.indexOf(':')) : a);
        if (h != null) h.accept(e.getPlayer(), a);
    }
    @EventHandler public void onDamage(EntityDamageEvent e) { if (actionOf(e.getEntity()) != null) e.setCancelled(true); }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p) || !p.hasPermission("doblo.admin")) { s.sendMessage("§cYetkin yok."); return true; }
        if (a.length == 0) { p.sendMessage("§e/dnpc create <" + String.join("|", actions.keySet()) + "> | remove | list"); return true; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> { if (a.length < 2 || !actions.containsKey(a[1].toLowerCase(Locale.ROOT))) { p.sendMessage("§cGeçerli eylem: " + String.join(", ", actions.keySet())); return true; }
                String action = a[1].toLowerCase(Locale.ROOT);
                String title = a.length > 2 ? String.join(" ", Arrays.copyOfRange(a, 2, a.length)).replace('&', '§') : "§b§l" + action.toUpperCase(Locale.ROOT);
                spawn(p.getLocation(), action, title); p.sendMessage("§a" + action + " NPC'si oluşturuldu."); }
            case "remove" -> { Entity best = null; double bd = 16;
                for (Entity e : p.getNearbyEntities(4, 4, 4)) if (actionOf(e) != null && e.getLocation().distanceSquared(p.getLocation()) < bd) { best = e; bd = e.getLocation().distanceSquared(p.getLocation()); }
                if (best == null) p.sendMessage("§cYakında NPC yok."); else { best.remove(); p.sendMessage("§aNPC silindi."); } }
            case "list" -> { int n = 0; for (org.bukkit.World w : Bukkit.getWorlds()) for (Entity e : w.getEntitiesByClass(Villager.class)) { String act = actionOf(e); if (act != null) { n++; p.sendMessage("§7" + act + " §8@ " + w.getName() + " " + e.getLocation().getBlockX() + "," + e.getLocation().getBlockY() + "," + e.getLocation().getBlockZ()); } }
                p.sendMessage("§aToplam: " + n); }
            default -> p.sendMessage("§cBilinmeyen alt komut.");
        }
        return true;
    }
}
