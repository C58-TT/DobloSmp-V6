package xyz.doblosmp.sb;

import java.util.*;

/** Ada kayıt defteri: tüm iş kuralları burada, Paper'dan bağımsız ve iş parçacığı güvenli. */
public final class IslandRegistry {
    public enum Result { OK, HAS_ISLAND, NO_ISLAND, NOT_OWNER, NO_PERMISSION, TARGET_HAS_ISLAND, ALREADY_MEMBER, NOT_MEMBER, FULL, NO_INVITE,
        BANNED, SELF, COOLDOWN, UNKNOWN_TEMPLATE, INVALID }

    private final Map<Long, Island> islands = new HashMap<>();
    private final Map<UUID, Long> byPlayer = new HashMap<>();            // sahip veya üye -> ada
    private final Map<UUID, Object[]> invites = new HashMap<>();         // hedef -> {adaId, bitiş ms}
    private final Map<UUID, Long> resetAt = new HashMap<>();
    private final Deque<Integer> freeSlots = new ArrayDeque<>();
    private final Set<String> templates; private final long inviteTtlMs, resetCooldownMs;
    private final Map<Integer, Island> slotMap = new HashMap<>();
    private long idSeq; private int nextSlot;

    public IslandRegistry(Set<String> templates, long inviteTtlMs, long resetCooldownMs) {
        this.templates = templates; this.inviteTtlMs = inviteTtlMs; this.resetCooldownMs = resetCooldownMs;
    }

    public synchronized Island islandOf(UUID p) { Long id = byPlayer.get(p); return id == null ? null : islands.get(id); }
    public synchronized Island byId(long id) { return islands.get(id); }
    public synchronized Island bySlot(int slot) { return slotMap.get(slot); }
    public synchronized int slotLimit() { return nextSlot; }
    public synchronized Collection<Island> all() { return new ArrayList<>(islands.values()); }

    /** Hata durumunda null döner ve Result'ı out[0]'a yazar. */
    public synchronized Island create(UUID owner, String template, Result[] out) {
        if (!templates.contains(template)) { out[0] = Result.UNKNOWN_TEMPLATE; return null; }
        if (byPlayer.containsKey(owner)) { out[0] = Result.HAS_ISLAND; return null; }
        int slot = freeSlots.isEmpty() ? nextSlot++ : freeSlots.pollFirst();
        Island i = new Island(++idSeq, owner, slot, template);
        islands.put(i.id, i); slotMap.put(slot, i); byPlayer.put(owner, i.id); out[0] = Result.OK; return i;
    }

    public synchronized Result delete(UUID by) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!i.owner.equals(by)) return Result.NOT_OWNER;
        islands.remove(i.id); slotMap.remove(i.slot); byPlayer.remove(i.owner); i.members.keySet().forEach(byPlayer::remove);
        invites.values().removeIf(v -> (Long) v[0] == i.id); freeSlots.addLast(i.slot); return Result.OK;
    }

    /** Sıfırlama: üyeler ve ayarlar kalır; seviye/değer/yükseltme sıfırlanır. Dünya temizliği Paper tarafında. */
    public synchronized Result reset(UUID by, long now) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!i.owner.equals(by)) return Result.NOT_OWNER;
        if (now - resetAt.getOrDefault(by, 0L) < resetCooldownMs) return Result.COOLDOWN;
        resetAt.put(by, now); i.resets++; i.ratings.clear();
        i.homeX = 0; i.homeY = 65; i.homeZ = 0; return Result.OK;
    }

    private boolean can(Island i, UUID p, Perm perm) { return i.roleOf(p).atLeast(i.need(perm)); }

    public synchronized Result invite(UUID by, UUID target, long now) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!can(i, by, Perm.INVITE)) return Result.NO_PERMISSION;
        if (by.equals(target)) return Result.SELF; if (byPlayer.containsKey(target)) return Result.TARGET_HAS_ISLAND;
        if (i.bans.contains(target)) return Result.BANNED;
        if (i.memberCount() >= IslandUpgrades.memberLimit(i)) return Result.FULL;
        invites.put(target, new Object[]{i.id, now + inviteTtlMs}); return Result.OK;
    }
    public synchronized Result accept(UUID p, long now) {
        Object[] inv = invites.remove(p); if (inv == null || (Long) inv[1] < now) return Result.NO_INVITE;
        Island i = islands.get((Long) inv[0]); if (i == null) return Result.NO_INVITE;
        if (byPlayer.containsKey(p)) return Result.HAS_ISLAND; if (i.memberCount() >= IslandUpgrades.memberLimit(i)) return Result.FULL;
        i.members.put(p, Role.MEMBER); byPlayer.put(p, i.id); return Result.OK;
    }
    public synchronized Result kick(UUID by, UUID target) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!can(i, by, Perm.KICK)) return Result.NO_PERMISSION;
        if (!i.members.containsKey(target)) return Result.NOT_MEMBER;
        if (i.roleOf(target).atLeast(i.roleOf(by))) return Result.NO_PERMISSION;       // eşit/üst rol atılamaz
        i.members.remove(target); byPlayer.remove(target); return Result.OK;
    }
    public synchronized Result leave(UUID p) {
        Island i = islandOf(p); if (i == null) return Result.NO_ISLAND; if (i.owner.equals(p)) return Result.NOT_MEMBER;
        i.members.remove(p); byPlayer.remove(p); return Result.OK;
    }
    public synchronized Result transfer(UUID by, UUID to) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!i.owner.equals(by)) return Result.NOT_OWNER;
        if (!i.members.containsKey(to)) return Result.NOT_MEMBER;
        i.members.remove(to); i.members.put(by, Role.MODERATOR); i.owner = to; return Result.OK;
    }
    public synchronized Result setRole(UUID by, UUID target, Role r) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!i.owner.equals(by)) return Result.NOT_OWNER;
        if (!i.members.containsKey(target) || r == Role.OWNER || r == Role.VISITOR) return Result.INVALID;
        i.members.put(target, r); return Result.OK;
    }
    public synchronized Result ban(UUID by, UUID target) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!can(i, by, Perm.BAN)) return Result.NO_PERMISSION;
        if (by.equals(target) || target.equals(i.owner) || i.members.containsKey(target)) return Result.INVALID;
        i.bans.add(target); return Result.OK;
    }
    public synchronized Result unban(UUID by, UUID target) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!can(i, by, Perm.BAN)) return Result.NO_PERMISSION;
        return i.bans.remove(target) ? Result.OK : Result.NOT_MEMBER;
    }
    public synchronized Result setFlag(UUID by, String flag, boolean v) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!can(i, by, Perm.SETTINGS)) return Result.NO_PERMISSION;
        if (!i.flags.containsKey(flag)) return Result.INVALID; i.flags.put(flag, v); return Result.OK;
    }
    public synchronized Result setRequired(UUID by, Perm perm, Role min) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!can(i, by, Perm.SETTINGS)) return Result.NO_PERMISSION;
        if (min == Role.VISITOR && perm != Perm.DOORS) return Result.INVALID;      // ziyaretçiye yalnızca kapı izni verilebilir
        i.required.put(perm, min); return Result.OK;
    }
    public synchronized Result setHome(UUID by, double x, double y, double z, int radius) {
        Island i = islandOf(by); if (i == null) return Result.NO_ISLAND; if (!can(i, by, Perm.SETHOME)) return Result.NO_PERMISSION;
        if (Math.abs(x) > radius || Math.abs(z) > radius) return Result.INVALID; i.homeX = x; i.homeY = y; i.homeZ = z; return Result.OK;
    }
    public synchronized Result canVisit(UUID visitor, Island i) {
        if (i == null) return Result.NO_ISLAND; if (i.bans.contains(visitor)) return Result.BANNED;
        if (!i.roleOf(visitor).atLeast(Role.MEMBER) && !i.flags.getOrDefault("visitors", true)) return Result.NO_PERMISSION;
        return Result.OK;
    }
    public synchronized Result rate(UUID by, Island i, int score) {
        if (i == null) return Result.NO_ISLAND; if (score < 1 || score > 5) return Result.INVALID;
        if (i.roleOf(by) != Role.VISITOR) return Result.SELF; i.ratings.put(by, score); return Result.OK;
    }

    public synchronized List<Island> snapshot() { List<Island> l = new ArrayList<>(); for (Island i : islands.values()) l.add(i.copy()); return l; }
    /** Kalıcılıktan yükleme için. */
    public synchronized Island restore(long id, UUID owner, int slot, String template) {
        Island i = new Island(id, owner, slot, template); islands.put(id, i); slotMap.put(slot, i); byPlayer.put(owner, id);
        idSeq = Math.max(idSeq, id); nextSlot = Math.max(nextSlot, slot + 1); return i;
    }
    public synchronized void restoreMember(Island i, UUID p, Role r) { i.members.put(p, r); byPlayer.put(p, i.id); }
}
