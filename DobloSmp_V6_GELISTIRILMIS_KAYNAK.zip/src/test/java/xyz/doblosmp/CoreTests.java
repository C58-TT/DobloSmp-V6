package xyz.doblosmp;

import xyz.doblosmp.anticheat.*;
import xyz.doblosmp.backup.BackupService;
import xyz.doblosmp.bedwars.*;
import xyz.doblosmp.clan.ClanService;
import xyz.doblosmp.duels.*;
import xyz.doblosmp.economy.*;
import xyz.doblosmp.murder.MurderGame;
import xyz.doblosmp.quest.QuestEngine;
import xyz.doblosmp.security.Totp;
import xyz.doblosmp.security.Passwords;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

/** Bağımsız test koşucusu (JUnit gerektirmez): java -cp target/classes:target/test-classes xyz.doblosmp.CoreTests */
public class CoreTests {
    static int pass, fail;
    static void check(String name, boolean cond) { if (cond) pass++; else { fail++; System.out.println("BAŞARISIZ: " + name); } }
    static UUID u() { return UUID.randomUUID(); }

    public static void main(String[] a) throws Exception {
        economy(); trade(); auction(); duels(); murder(); bedwars(); quests(); clan(); anticheat(); totp(); backup();
        System.out.println("Geçen: " + pass + "  Kalan: " + fail);
        if (fail > 0) throw new AssertionError("Core test failures: " + fail);
    }

    static void economy() {
        Ledger l = new Ledger(1000); UUID x = u(), y = u();
        check("deposit", l.deposit("sb", x, 100, "t")); check("negatif reddedilir", !l.deposit("sb", x, -5, "t"));
        check("yetersiz bakiye", !l.transfer("sb", x, y, 101, "t")); check("transfer", l.transfer("sb", x, y, 60, "t"));
        check("kendine transfer", !l.transfer("sb", x, x, 1, "t"));
        check("mod izolasyonu", l.balance("bw", x) == 0 && l.balance("sb", x) == 40);
        check("audit tutarlı", l.audit("sb")); check("taşma", !l.deposit("sb", x, Long.MAX_VALUE, "t") && l.audit("sb"));
        l.withdraw("sb", y, 10, "buy"); check("audit withdraw sonrası", l.audit("sb"));
        // eşzamanlı transfer: toplam sabit kalmalı
        UUID p = u(), q = u(); l.deposit("c", p, 1000, "t"); l.deposit("c", q, 1000, "t");
        Thread[] th = new Thread[8];
        for (int i = 0; i < th.length; i++) { final int k = i; th[i] = new Thread(() -> { for (int j = 0; j < 2000; j++) { if (k % 2 == 0) l.transfer("c", p, q, 3, "r"); else l.transfer("c", q, p, 2, "r"); } }); th[i].start(); }
        for (Thread t : th) try { t.join(); } catch (InterruptedException ignored) {}
        check("eşzamanlı toplam sabit", l.balance("c", p) + l.balance("c", q) == 2000 && l.audit("c"));
        Ledger r = new Ledger(10); r.restore(l.snapshot()); check("restore sonrası audit", r.audit("sb") && r.audit("c"));
    }

    static class Gw implements TradeSession.ItemGateway {
        Map<String, Integer> inv = new HashMap<>(); boolean failGive;
        String k(UUID p, String i) { return p + i; }
        public boolean has(UUID p, String i, int n) { return inv.getOrDefault(k(p, i), 0) >= n; }
        public boolean take(UUID p, String i, int n) { if (!has(p, i, n)) return false; inv.merge(k(p, i), -n, Integer::sum); return true; }
        public void give(UUID p, String i, int n) { inv.merge(k(p, i), n, Integer::sum); }
    }
    static void trade() {
        Ledger l = new Ledger(100); UUID x = u(), y = u(); Gw g = new Gw();
        l.deposit("sb", x, 100, "t"); g.give(y, "DIAMOND", 5);
        TradeSession t = new TradeSession(x, y, "sb", 60_000);
        t.setCoins(x, 50); t.setItem(y, "DIAMOND", 3); t.confirm(x);
        check("tek onayla yürümez", !t.execute(l, g));
        t.setCoins(x, 40); check("teklif değişince onay sıfırlanır", !t.bothConfirmed());
        t.confirm(x); t.confirm(y); check("iki onayla yürür", t.execute(l, g));
        check("takas sonucu", l.balance("sb", y) == 40 && g.has(x, "DIAMOND", 3) && g.has(y, "DIAMOND", 2) && l.audit("sb"));
        check("ikinci kez yürümez", !t.execute(l, g));
        // sahtecilik: teklif edilen eşya yok
        TradeSession t2 = new TradeSession(x, y, "sb", 60_000); t2.setItem(x, "NETHERITE", 1); t2.confirm(x); t2.confirm(y);
        check("olmayan eşya reddedilir", !t2.execute(l, g) && t2.state() == TradeSession.State.FAILED);
        // para yetersiz -> eşyalar iade
        TradeSession t3 = new TradeSession(x, y, "sb", 60_000); t3.setCoins(x, 9999); t3.setItem(y, "DIAMOND", 1); t3.confirm(x); t3.confirm(y);
        check("yetersiz para reddedilir, eşya yerinde", !t3.execute(l, g) && g.has(y, "DIAMOND", 2));
        TradeSession t4 = new TradeSession(x, y, "sb", -1); check("zaman aşımı", !t4.confirm(x) && t4.state() == TradeSession.State.EXPIRED);
    }

    static void auction() {
        Ledger l = new Ledger(100); UUID s = u(), b1 = u(), b2 = u(); l.deposit("sb", b1, 1000, "t"); l.deposit("sb", b2, 1000, "t");
        AuctionHouse ah = new AuctionHouse(l, "sb", 0.05);
        long id = ah.list(s, "DIAMOND", 1, 100, true, 50);
        check("düşük teklif", !ah.bid(id, b1, 50)); check("teklif1", ah.bid(id, b1, 100) && l.balance("sb", b1) == 900);
        check("teklif2 iade", ah.bid(id, b2, 200) && l.balance("sb", b1) == 1000 && l.balance("sb", b2) == 800);
        check("satıcı kendi ilanına teklif veremez", !ah.bid(id, s, 500));
        try { Thread.sleep(80); } catch (InterruptedException ignored) {}
        var sales = ah.settle(); check("açık artırma kapandı", sales.size() == 1 && l.balance("sb", s) == 190 && l.audit("sb"));
        long mk = ah.list(s, "IRON", 10, 30, false, 0); check("market al", ah.buyNow(mk, b1) && l.balance("sb", b1) == 970 && l.audit("sb"));
        check("geçmiş", ah.salesOf(b1).size() == 1);
    }

    static void duels() {
        check("elo eşit", Elo.expectedDelta(1000, 1000, true, 32) == 16);
        check("elo favori az kazanır", Elo.expectedDelta(1400, 1000, true, 32) < 16);
        check("lig", Elo.league(1000).equals("Demir") && Elo.league(2000).equals("Netherite"));
        DuelQueue q = new DuelQueue(100, 10); UUID a = u(), b = u(), c = u();
        q.join(a, "nodebuff", 1, 1000); q.join(b, "nodebuff", 1, 1050); q.join(c, "sumo", 1, 1000);
        check("çift kayıt reddi", !q.join(a, "nodebuff", 1, 1000));
        var m = q.poll(System.currentTimeMillis()); check("eşleşme (kit aynı, elo yakın)", m.size() == 1 && q.size() == 1);
        UUID d = u(), e = u(); q.join(d, "sumo", 1, 1600);
        check("elo uzak eşleşmez", q.poll(System.currentTimeMillis()).isEmpty());
        check("bekleyince genişler", q.poll(System.currentTimeMillis() + 120_000).size() == 1);
        DuelMatch dm = new DuelMatch(a, b, 3, 60_000); dm.startFight();
        check("raund1", !dm.roundWon(a)); dm.startFight(); check("raund2 biter", dm.roundWon(a));
        var r = dm.finish(1000, 1000, 32); check("sonuç", r.winner().equals(a) && r.winnerDelta() == 16 && r.loserDelta() == -16);
    }

    static void murder() {
        List<UUID> ps = new ArrayList<>(); for (int i = 0; i < 6; i++) ps.add(u());
        MurderGame g = new MurderGame(ps, new Random(7), 60_000);
        long m = ps.stream().filter(p -> g.role(p) == MurderGame.Role.MURDERER).count(), d = ps.stream().filter(p -> g.role(p) == MurderGame.Role.DETECTIVE).count();
        check("1 katil 1 dedektif", m == 1 && d == 1);
        UUID murderer = ps.stream().filter(p -> g.role(p) == MurderGame.Role.MURDERER).findFirst().get();
        UUID det = ps.stream().filter(p -> g.role(p) == MurderGame.Role.DETECTIVE).findFirst().get();
        g.kill(murderer, det); check("dedektif ölünce yay düşer", g.bowDropped());
        UUID inn = ps.stream().filter(p -> g.role(p) == MurderGame.Role.INNOCENT).findFirst().get();
        check("masum yayı alır", g.pickupBow(inn)); check("katil yayı alamaz", !g.pickupBow(murderer));
        UUID inn2 = ps.stream().filter(p -> g.role(p) == MurderGame.Role.INNOCENT && !p.equals(inn)).findFirst().get();
        g.kill(inn, inn2); check("masum masumu vurursa kendi de ölür", !g.isAlive(inn) && !g.isAlive(inn2));
        MurderGame g2 = new MurderGame(ps, new Random(1), 60_000); UUID mm = ps.stream().filter(p -> g2.role(p) == MurderGame.Role.MURDERER).findFirst().get();
        UUID other = ps.stream().filter(p -> !p.equals(mm)).findFirst().get();
        check("katil ölünce masumlar kazanır", g2.kill(other, mm) == MurderGame.Winner.INNOCENTS);
        MurderGame g3 = new MurderGame(ps, new Random(2), 60_000); UUID m3 = ps.stream().filter(p -> g3.role(p) == MurderGame.Role.MURDERER).findFirst().get();
        MurderGame.Winner w = MurderGame.Winner.NONE; for (UUID p : ps) if (!p.equals(m3)) w = g3.kill(m3, p);
        check("herkes ölünce katil kazanır", w == MurderGame.Winner.MURDERER);
        MurderGame g4 = new MurderGame(ps, new Random(3), -1); check("süre dolunca masumlar", g4.tick() == MurderGame.Winner.INNOCENTS);
        UUID favored = u(); List<UUID> weightedPlayers = new ArrayList<>(); weightedPlayers.add(favored); for (int i = 0; i < 4; i++) weightedPlayers.add(u());
        int sheriffPicks = 0; Random weightedRandom = new Random(55);
        for (int i = 0; i < 500; i++) { MurderGame weighted = new MurderGame(weightedPlayers, id -> id.equals(favored) ? 100.0 : 1.0, id -> id.equals(favored) ? 0.0001 : 1.0, weightedRandom, 60_000); if (weighted.role(favored) == MurderGame.Role.DETECTIVE) sheriffPicks++; }
        check("ağırlıklı şerif seçimi", sheriffPicks > 450);
        boolean minFive = false; try { new MurderGame(weightedPlayers.subList(0, 4), new Random(1), 60_000); } catch (IllegalArgumentException expected) { minFive = true; }
        check("Murder en az 5 oyuncu", minFive);
    }

    static void bedwars() {
        BedwarsMatch m = new BedwarsMatch(BedwarsMode.SOLO); List<UUID> players = new ArrayList<>();
        for (int i = 0; i < 8; i++) { UUID p = u(); players.add(p); check("solo takım ataması " + i, m.join(p, null)); }
        check("sekiz ayrı takım", m.teams().stream().filter(t -> t.members.size() == 1).count() == 8);
        check("sekizden az başlatılamaz", !new BedwarsMatch(BedwarsMode.SOLO).startCountdown(8));
        check("tam sekiz oyuncuyla geri sayım", m.startCountdown(8)); check("başla", m.begin());
        UUID first = players.get(0); var firstTeam = m.teamOf(first);
        int victimTeam = m.teams().stream().filter(t -> t != firstTeam).findFirst().orElseThrow().index;
        check("kendi yatağını kıramaz", !m.breakBed(first, firstTeam.index)); check("rakip yatağı kırılır", m.breakBed(first, victimTeam));
        UUID victim = m.teams().get(victimTeam).members.iterator().next();
        check("yatak kırık, ölünce elenir", m.onDeath(victim, first) == BedwarsMatch.DeathResult.ELIMINATED);
        check("seyirci", m.isSpectator(victim));
        check("yatak dururken yeniden doğar", m.onDeath(first, null) == BedwarsMatch.DeathResult.RESPAWN);
        for (var t : m.teams()) if (t != firstTeam && !t.members.isEmpty()) { t.bed = false; for (UUID p : new ArrayList<>(t.alive)) m.onDeath(p, first); }
        check("kazanan belirlendi", m.state() == BedwarsMatch.State.ENDING && m.winner() == firstTeam);
        check("istatistik", m.stats(first)[2] == 1);
        BedwarsMatch shop = new BedwarsMatch(BedwarsMode.SOLO); UUID p = u();
        for (int i = 0; i < 8; i++) shop.join(i == 0 ? p : u(), null);
        shop.startCountdown(8); shop.begin();
        check("parasız alım reddi", !shop.buy(p, "WOOL16")); shop.addResource(p, BedwarsMatch.Res.IRON, 4);
        check("alım", shop.buy(p, "WOOL16") && shop.resource(p, BedwarsMatch.Res.IRON) == 0); check("olmayan eşya", !shop.buy(p, "HACK"));
        shop.addResource(p, BedwarsMatch.Res.DIAMOND, 6);
        check("keskinlik", shop.buyUpgrade(p, BedwarsMatch.Upgrade.SHARPNESS) && shop.teamOf(p).sharpness == 1);
        check("keskinlik azami", !shop.buyUpgrade(p, BedwarsMatch.Upgrade.SHARPNESS));
        check("koruma 1 (2 elmas)", shop.buyUpgrade(p, BedwarsMatch.Upgrade.PROTECTION));
        check("üretici hızlanır", BedwarsMatch.ironIntervalTicks(3) < BedwarsMatch.ironIntervalTicks(0));
    }

    static void quests() {
        QuestEngine q = new QuestEngine("S1", 100); UUID p = u();
        q.register(new QuestEngine.Quest("win3", "bw_win", 3, QuestEngine.Period.DAILY, 150, 100, "cape_red"));
        LocalDate d = LocalDate.of(2026, 11, 17);
        check("ilerleme", q.add(p, "bw_win", 2, d).isEmpty() && q.add(p, "bw_win", 5, d).contains("win3") && q.progress(p, "win3", d) == 3);
        check("ödül", q.claim(p, "win3", d) != null && q.claim(p, "win3", d) == null);
        check("ertesi gün sıfırlanır", q.progress(p, "win3", d.plusDays(1)) == 0);
        check("pass tier", q.passTier(p) == 1 && q.claimPassTier(p, 1) && !q.claimPassTier(p, 1) && !q.claimPassTier(p, 2));
        check("kozmetik", q.of(p).cosmetics.contains("cape_red"));
        check("seri 1", q.dailyLogin(p, d) == 1); check("aynı gün", q.dailyLogin(p, d) == null);
        check("seri 2", q.dailyLogin(p, d.plusDays(1)) == 2); check("seri kırılır", q.dailyLogin(p, d.plusDays(5)) == 1);
    }

    static void clan() {
        ClanService c = new ClanService(10); UUID l = u(), m = u(), x = u();
        check("oluştur", c.create(l, "dbl", "Doblo Klan") != null); check("tag çakışma", c.create(m, "DBL", "X") == null);
        check("davet+kabul", c.invite(l, m) && c.accept(m, "DBL")); check("lider değil davet edemez", !c.invite(m, x));
        check("devir", c.transfer(l, m) && c.of(m).leader.equals(m));
        c.create(x, "TST", "Test"); check("savaş", c.recordWar("DBL", "TST", 200) && c.byTag("DBL").points == 200 && c.byTag("TST").points == 0);
        check("seviye", c.byTag("DBL").level() == 2); check("sıralama", c.ranking(5).get(0).tag.equals("DBL"));
        check("lider ayrılınca devir", c.leave(m) && c.byTag("DBL").leader.equals(l));
    }

    static void anticheat() {
        check("reach normal", Checks.reach(3.0, 50, false) == 0); check("reach ihlal", Checks.reach(4.8, 50, false) > 0);
        check("reach yüksek pingde tolerans", Checks.reach(3.6, 300, false) == 0);
        check("speed normal sprint", Checks.speed(0.34, -1, false, true, 40) == 0); check("speed ihlal", Checks.speed(0.9, -1, false, true, 40) > 0);
        check("speed iksir toleransı", Checks.speed(0.5, 1, false, true, 40) == 0);
        check("fly merdiven/sıvı muaf", Checks.fly(40, 0, true, false) == 0); check("fly ihlal", Checks.fly(40, 0, false, false) > 0);
        check("nofall", Checks.noFall(10, true, false, false) > 0 && Checks.noFall(2, true, false, false) == 0);
        check("killaura", Checks.killAura(3, 10, 8) > 0 && Checks.killAura(1, 10, 8) == 0);
        check("scaffold", Checks.scaffold(10, 10, true, true) > 0 && Checks.scaffold(10, 10, true, false) == 0);
        check("xray", Checks.xray(20, 100, 2) > 0 && Checks.xray(2, 100, 2) == 0 && Checks.xray(5, 10, 0) == 0);
        check("autototem", Checks.autoTotem(10) > 0 && Checks.autoTotem(200) == 0);
        check("autocrystal", Checks.autoCrystal(20, 5) > 0 && Checks.autoCrystal(200, 5) == 0);
        check("paket", Checks.packet(10, Double.NaN, 0, 0) > 0 && Checks.packet(10, 1, 1, 1) == 0);
        check("düşük TPS'te atla", Checks.shouldSkip(15.0, 50, 18, 400) && !Checks.shouldSkip(20, 50, 18, 400));
        Suspicion s = new Suspicion(0.5, 100); UUID p = u(); long t0 = 1_000_000L;
        s.add(p, "reach", 4, "x", t0); check("puan birikir", s.get(p, "reach", t0) == 4);
        check("puan azalır", s.get(p, "reach", t0 + 4000) == 2); check("geçmiş", s.history(p, 5).size() == 1);
        Sanction sa = new Sanction(5, 10, 15, 25, false), sb = new Sanction(5, 10, 15, 25, true);
        check("auto kapalı: en fazla uyarı", sa.decide(100) == Sanction.Action.ALERT && sa.decide(1) == Sanction.Action.NONE);
        check("auto açık: ban", sb.decide(30) == Sanction.Action.BAN && sb.decide(12) == Sanction.Action.SETBACK);
    }

    static void totp() {
        // RFC 6238 test vektörü: secret "12345678901234567890", T=59 -> 94287082 (8 hane) => son 6 hane 287082
        String secret = Totp.base32("12345678901234567890".getBytes());
        check("RFC6238 vektörü", Totp.code(secret, 59_000L).equals("287082"));
        check("doğrulama", Totp.verify(secret, "287082", 59_000L) && !Totp.verify(secret, "000000", 59_000L));
        String salt = Passwords.newSalt(), h = Passwords.hash("Gizli12345", salt);
        check("parola", Passwords.verify("Gizli12345", salt, h) && !Passwords.verify("yanlis", salt, h));
        check("parola gücü", Passwords.strong("abcdefgh12") && !Passwords.strong("kisa1") && !Passwords.strong("sadeceharfler"));
    }

    static void backup() throws Exception {
        Path tmp = Files.createTempDirectory("bk"); Path world = tmp.resolve("world"); Files.createDirectories(world.resolve("region"));
        Files.writeString(world.resolve("level.dat"), "abc"); Files.writeString(world.resolve("region/r.0.0.mca"), "chunkdata");
        BackupService bs = new BackupService(tmp.resolve("backups"), 2);
        Path z = bs.create("world", Map.of("world", world)); check("yedek oluştu", Files.exists(z) && bs.verify(z));
        Path out = tmp.resolve("restored"); bs.restore(z, out);
        check("geri yükleme", Files.readString(out.resolve("world/level.dat")).equals("abc"));
        // bozma
        byte[] b = Files.readAllBytes(z); b[b.length / 2] ^= 0x55; Path bad = tmp.resolve("backups/bad.zip"); Files.write(bad, b);
        check("bozuk yedek reddedilir", !bs.verify(bad));
        Path bad2 = Path.of(z + ""); byte[] c = Files.readAllBytes(bad2); c[20] ^= 1; Files.write(bad2, c);
        check("sayısal özet uyuşmaz", !bs.verify(bad2));
        for (int i = 0; i < 3; i++) { Thread.sleep(5); bs.create("w" + i, Map.of("world", world)); }
        check("eski yedekler silinir", bs.list().stream().filter(p -> !p.getFileName().toString().startsWith("bad")).count() <= 3);
    }


}
