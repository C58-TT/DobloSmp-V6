# DobloSmp kurulum notları

1. Java 21 kur ve Paper 1.21.11 sunucusunu hazırla.
2. Bu eklentinin JAR'ını `plugins/` içine koy; derlenmiş V6 JAR henüz bu paketle sağlanmamıştır.
3. `worlds/lobby-world/` içeriğini sunucu kökünde `lobby/` adlı klasöre kopyala. Mevcut `lobby/` klasörünün üzerine yazma.
4. Discord Webhook için `DOBLO_DISCORD_WEBHOOK` ortam değişkeni tanımla. URL'yi config'e gömme.
5. MariaDB kullanacaksan database ayarlarını `config.yml` içinde aç ve parola için `DOBLO_DB_PASSWORD` kullan.
6. İlk açılışta `/lobby` komutunu dene. `lobby.npcs.enabled: true` ise sekiz varsayılan NPC otomatik oluşturulur; spawn konumu uygun değilse `/lobbyspawn` ile konumu kaydet ve sunucuyu yeniden başlat. NPC'lere sağ tıklayarak menüleri test et.
7. BedWars, Duels ve Murder Mystery için hazır arena haritası bu pakette yoktur. `arenas.yml` içindeki arena noktalarını yönetici komutlarıyla kurmadan maçlar başlayamaz.
8. LuckPerms, GrimAC, Vault, Geyser/Floodgate ve gerekiyorsa AuthMe gibi dış eklentileri yalnızca uyumlu sürümlerini doğrulayıp kur.
9. systemd servisiyle yönet: `sudo systemctl start doblosmp`, `status`, `restart`, `stop`.

Bu kaynak paketin Paper API ile derlenip gerçek sunucuda çalıştırıldığı doğrulanmış değildir.
