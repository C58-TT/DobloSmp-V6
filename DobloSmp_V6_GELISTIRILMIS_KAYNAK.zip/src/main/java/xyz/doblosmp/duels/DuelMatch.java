package xyz.doblosmp.duels;

import java.util.*;

/** Best-of-N raund mantığı, ELO güncellemesi ve maç geçmişi kaydı. */
public final class DuelMatch {
    public record Result(UUID winner, UUID loser, int winnerDelta, int loserDelta, int roundsW, int roundsL) {}
    public enum State { COUNTDOWN, FIGHTING, ROUND_END, FINISHED }

    public final UUID a, b; private final int toWin;
    private final Map<UUID, Integer> rounds = new HashMap<>();
    private State state = State.COUNTDOWN;
    private final long deadline; // maç zamanlayıcısı
    private UUID winner;

    public DuelMatch(UUID a, UUID b, int bestOf, long maxDurationMs) {
        this.a = a; this.b = b; this.toWin = bestOf / 2 + 1;
        rounds.put(a, 0); rounds.put(b, 0);
        this.deadline = System.currentTimeMillis() + maxDurationMs;
    }
    public State state() { return state; }
    public void startFight() { if (state == State.COUNTDOWN || state == State.ROUND_END) state = State.FIGHTING; }
    public int rounds(UUID p) { return rounds.getOrDefault(p, 0); }
    public boolean timedOut() { return System.currentTimeMillis() > deadline; }

    /** Bir oyuncu raundu kazandı. Maç bittiyse true. */
    public boolean roundWon(UUID p) {
        if (state != State.FIGHTING || !rounds.containsKey(p)) return false;
        int r = rounds.merge(p, 1, Integer::sum);
        if (r >= toWin) { winner = p; state = State.FINISHED; return true; }
        state = State.ROUND_END; return false;
    }
    /** Zaman aşımında raund farkına göre, eşitse beraberlik (null). */
    public UUID resolveTimeout() {
        int ra = rounds(a), rb = rounds(b);
        state = State.FINISHED;
        winner = ra == rb ? null : (ra > rb ? a : b);
        return winner;
    }
    public Result finish(int eloA, int eloB, int k) {
        if (winner == null) return null;
        UUID loser = winner.equals(a) ? b : a;
        int rw = winner.equals(a) ? eloA : eloB, rl = winner.equals(a) ? eloB : eloA;
        int d = Elo.expectedDelta(rw, rl, true, k);
        return new Result(winner, loser, d, -d, rounds(winner), rounds(loser));
    }
}
