package xyz.doblosmp.sb;

/** Kare spiral ada yuvası dağıtıcısı: 0 → (0,0), 1 → (1,0), 2 → (1,1) ... Dünya koordinatı = yuva * aralık. */
public final class IslandGrid {
    private IslandGrid() {}
    public static int[] cell(int n) {
        if (n == 0) return new int[]{0, 0};
        int k = (int) Math.ceil((Math.sqrt(n + 1) - 1) / 2);          // halka
        int t = 2 * k + 1, m = t * t;                                    // halkanın son yuvası: m-1
        t--;
        if (n >= m - t) return new int[]{k - (m - 1 - n), -k};
        m -= t;
        if (n >= m - t) return new int[]{-k, -k + (m - 1 - n)};
        m -= t;
        if (n >= m - t) return new int[]{-k + (m - 1 - n), k};
        return new int[]{k, k - (m - n - 1 - t)};
    }
    public static int[] center(int slot, int spacing) { int[] c = cell(slot); return new int[]{c[0] * spacing, c[1] * spacing}; }
    /** Dünya koordinatı hangi ızgara hücresine ait? */
    public static int[] cellAt(int x, int z, int spacing) { return new int[]{Math.floorDiv(x + spacing / 2, spacing), Math.floorDiv(z + spacing / 2, spacing)}; }
}
