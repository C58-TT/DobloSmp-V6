# V6 harici eklentiler ve sunucu güvenliği

Bu dosya eklentilerin gerçek sunucuya kurulum sırasını gösterir. Paket, bunları otomatik indirmez; uyumlu sürümleri Paper 1.21.11 ve Java 21 ile doğrulayıp resmi kaynaklarından alın.


## Öncelik 1 – Yetki
- LuckPerms kur.
- `doblo.admin` yalnızca sunucu yöneticilerine verilmelidir. Başlangıçta OP yetkisini sadece kendi yönetici hesabında tut.
- LuckPerms örnek komutları:
  - `/lp creategroup oyuncu`
  - `/lp creategroup vip`
  - `/lp creategroup vipplus`
  - `/lp creategroup rehber`
  - `/lp creategroup moderatör`
  - `/lp creategroup developer`
  - `/lp creategroup kurucu`
  - `/lp group oyuncu permission set doblo.lobby true`
  - Yönetici grubuna: `/lp group kurucu permission set doblo.admin true`
  - Grupları prefix, inheritance ve kullanıcı atamalarıyla yapılandır; ayrı bir test oyuncusunda doğrula.
- Plugin'in `doblo.admin` iznini kullanır; LuckPerms grup ataması dışında otomatik rank sistemi henüz entegre değildir.


## Öncelik 2 – Hile koruması
- GrimAC kur ve test et. DobloSuite heuristik kontrolleri ile birlikte çalıştırmadan önce false-positive ölçümü yap.
- Paket kontrolü için ProtocolLib veya PacketEvents yalnızca uyumlu eklenti gerektiriyorsa kur; bunlar tek başına anti-cheat değildir.
- Test sunucusunda tespit loglarını incelemeden otomatik cezayı açma.


## Öncelik 3 – Java/Bedrock
- Geyser ve Floodgate kur. UDP 19132 portunu hosting panelinde ve firewall'da aç.
- Floodgate ayarlarını online-mode/premium giriş yönteminle uyumlu hale getir. Floodgate key dosyasını paylaşma.
- Java ve Bedrock test hesaplarıyla giriş, menü, komut, NPC ve oyun modlarını ayrı test et.


## Öncelik 4 – Ekonomi ve giriş
- Vault kur. DobloSuite'nin kendi Ledger bakiyesi şu an Vault API sağlayıcısı olarak doğrulanmadı; entegrasyon kodu gerekir.
- Offline/cracked giriş kullanacaksan AuthMe Reloaded gibi bir login plugin kurup parola güvenliğini ve spawn korumasını ayrıca ayarla. Premium-only ise `online-mode=true` kullan.


## Öncelik 5 – TAB / Scoreboard
- TAB eklentisi kur. Rank prefixlerini LuckPerms gruplarından al.
- Scoreboard başlığı, çevrimiçi oyuncu, ping, oyun modu ve DobloSmp marka satırlarını TAB config'inde kur.
- Bu pakette TAB için hazır ve gerçek sunucuda doğrulanmış config bulunmuyor.


## VPS güvenliği
- Sunucu panelindeki DDoS korumasını etkinleştir/hosting desteğiyle doğrula.
- UFW'de yalnızca SSH, Minecraft Java portu ve gerekiyorsa Bedrock UDP portunu aç.
- SSH anahtar kullan; root SSH girişini kapat; sistem güncellemelerini yap.
- Web panel yoktur. SSH/systemd ile yönetilir.
