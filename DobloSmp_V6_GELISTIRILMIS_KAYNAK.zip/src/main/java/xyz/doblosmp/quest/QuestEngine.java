package xyz.doblosmp.quest;

import java.time.*;
import java.time.temporal.IsoFields;
import java.util.*;

/** Günlük/haftalık/sezonluk görevler, başarımlar, giriş serisi ve Battle Pass. Dönem geçişinde otomatik sıfırlanır. */
public final class QuestEngine {
    public enum Period { DAILY, WEEKLY, SEASONAL, ONCE }
    public record Quest(String id, String metric, int target, Period period, int xp, long coins, String cosmetic) {}

    public static final class PlayerData {
        public final Map<String, Integer> progress = new HashMap<>();
        public final Map<String, String> periodKey = new HashMap<>();
        public final Set<String> claimed = new HashSet<>();
        public final Set<String> achievements = new HashSet<>();
        public final Set<String> cosmetics = new HashSet<>();
        public final Set<Integer> passClaimed = new HashSet<>();
        public LocalDate lastLogin; public int streak; public long passXp;
    }

    private final Map<String, Quest> quests = new LinkedHashMap<>();
    private final Map<UUID, PlayerData> data = new HashMap<>();
    private final String season;
    private final int passXpPerTier;

    public QuestEngine(String season, int passXpPerTier) { this.season = season; this.passXpPerTier = Math.max(1, passXpPerTier); }

    /** Eşzamansız kayıt için verinin derin kopyası. */
    public synchronized QuestEngine copyData() {
        QuestEngine c = new QuestEngine(season, passXpPerTier);
        for (var e : data.entrySet()) { PlayerData s = e.getValue(), d = c.of(e.getKey());
            d.progress.putAll(s.progress); d.periodKey.putAll(s.periodKey); d.claimed.addAll(s.claimed); d.achievements.addAll(s.achievements);
            d.cosmetics.addAll(s.cosmetics); d.passClaimed.addAll(s.passClaimed); d.lastLogin = s.lastLogin; d.streak = s.streak; d.passXp = s.passXp; }
        return c;
    }
    public void register(Quest q) { quests.put(q.id(), q); }
    public Collection<Quest> quests() { return quests.values(); }
    public synchronized PlayerData of(UUID p) { return data.computeIfAbsent(p, k -> new PlayerData()); }
    public Map<UUID, PlayerData> all() { return data; }

    String keyFor(Quest q, LocalDate d) {
        return switch (q.period()) {
            case DAILY -> d.toString();
            case WEEKLY -> d.get(IsoFields.WEEK_BASED_YEAR) + "-W" + d.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
            case SEASONAL -> season;
            case ONCE -> "once";
        };
    }

    private void rollover(PlayerData pd, Quest q, LocalDate today) {
        String k = keyFor(q, today);
        if (!k.equals(pd.periodKey.get(q.id()))) {
            pd.periodKey.put(q.id(), k); pd.progress.put(q.id(), 0); pd.claimed.remove(q.id());
        }
    }

    /** Bir metrik arttı (ör. "bedwars_win", "blocks_mined"). Tamamlanan görev id'lerini döndürür. */
    public synchronized List<String> add(UUID p, String metric, int amount, LocalDate today) {
        if (amount <= 0) return List.of();
        PlayerData pd = of(p); List<String> done = new ArrayList<>();
        for (Quest q : quests.values()) {
            if (!q.metric().equals(metric)) continue;
            rollover(pd, q, today);
            int before = pd.progress.getOrDefault(q.id(), 0);
            if (before >= q.target()) continue;
            int now = (int) Math.min(q.target(), (long) before + amount);
            pd.progress.put(q.id(), now);
            if (now >= q.target()) done.add(q.id());
        }
        return done;
    }

    public synchronized int progress(UUID p, String questId, LocalDate today) {
        Quest q = quests.get(questId); if (q == null) return 0;
        PlayerData pd = of(p); rollover(pd, q, today);
        return pd.progress.getOrDefault(questId, 0);
    }

    /** Ödül talebi: tamamlanmış ve alınmamışsa true; ödül değerlerini çağıran uygular. */
    public synchronized Quest claim(UUID p, String questId, LocalDate today) {
        Quest q = quests.get(questId); if (q == null) return null;
        PlayerData pd = of(p); rollover(pd, q, today);
        if (pd.progress.getOrDefault(questId, 0) < q.target() || !pd.claimed.add(questId)) return null;
        pd.passXp += q.xp();
        if (q.cosmetic() != null && !q.cosmetic().isBlank()) pd.cosmetics.add(q.cosmetic());
        return q;
    }

    /** Günlük giriş: seri artar, bir gün kaçırılırsa 1'e döner. Ödül miktarı seriye göre (üst sınır 7). null = bugün alındı. */
    public synchronized Integer dailyLogin(UUID p, LocalDate today) {
        PlayerData pd = of(p);
        if (today.equals(pd.lastLogin)) return null;
        pd.streak = (pd.lastLogin != null && pd.lastLogin.plusDays(1).equals(today)) ? pd.streak + 1 : 1;
        pd.lastLogin = today;
        return Math.min(pd.streak, 7);
    }

    public synchronized boolean grantAchievement(UUID p, String id) { return of(p).achievements.add(id); }

    public synchronized int passTier(UUID p) { return (int) (of(p).passXp / passXpPerTier); }
    public synchronized boolean claimPassTier(UUID p, int tier) {
        PlayerData pd = of(p);
        return tier >= 1 && tier <= passTier(p) && pd.passClaimed.add(tier);
    }
}
