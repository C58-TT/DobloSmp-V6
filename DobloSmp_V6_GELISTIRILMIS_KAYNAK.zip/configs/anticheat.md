# Anti-cheat katmanı
- GrimAC gibi güncel, Paper sürümünüzle uyumlu bir anti-cheat'i ayrı kurun.
- DobloGuard içindeki sezgisel kontroller yalnızca yönetici uyarısı üretir; otomatik ceza vermez.
- X-Ray için ore-obfuscation/anti-xray yapılandırmasını Paper'da etkinleştirin; bu tek başına oyuncuyu kesin hileli ilan etmez.
- KillAura/Reach/Scaffold tespitinde paket ve hareket analizi için bakımı süren bir anti-cheat gerekir.
- Önce test dünyasında false-positive ölçün. Otomatik banı ilk kurulumda açmayın.
