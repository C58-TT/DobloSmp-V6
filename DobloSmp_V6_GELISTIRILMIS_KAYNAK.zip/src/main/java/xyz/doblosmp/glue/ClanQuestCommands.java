package xyz.doblosmp.glue;

import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import xyz.doblosmp.clan.ClanService;
import xyz.doblosmp.economy.Ledger;
import xyz.doblosmp.quest.QuestEngine;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

public final class ClanQuestCommands implements CommandExecutor {
    private final ClanService clans; private final QuestEngine quests; private final Ledger ledger; private final String mode;
    public ClanQuestCommands(ClanService clans, QuestEngine quests, Ledger ledger, String mode) {
        this.clans = clans; this.quests = quests; this.ledger = ledger; this.mode = mode;
    }
    private static LocalDate today() { return LocalDate.now(ZoneId.systemDefault()); }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Oyuncu komutu."); return true; }
        if (c.getName().equalsIgnoreCase("klan")) clan(p, a); else quest(p, a);
        return true;
    }

    private void clan(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length == 0) { p.sendMessage("§e/klan olustur <TAG> <ad> | davet <oyuncu> | kabul <TAG> | at <oyuncu> | ayril | devret <oyuncu> | dagit | bilgi | top"); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "olustur" -> { if (a.length < 3) { p.sendMessage("§c/klan olustur <TAG> <ad>"); return; }
                String name = String.join(" ", Arrays.copyOfRange(a, 2, a.length));
                p.sendMessage(clans.create(id, a[1], name) != null ? "§aKlan kuruldu." : "§cOluşturulamadı (TAG 2-5 harf/rakam, ad ≤24, TAG boş ve klansız olmalısın)."); }
            case "davet" -> { Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null;
                if (t == null || !clans.invite(id, t.getUniqueId())) { p.sendMessage("§cDavet gönderilemedi (lider olmalısın, hedef klansız ve kapasite dolu olmamalı)."); return; }
                t.sendMessage("§e" + clans.of(id).name + " klanına davet edildin: /klan kabul " + clans.of(id).tag); p.sendMessage("§aDavet gönderildi."); }
            case "kabul" -> p.sendMessage(a.length > 1 && clans.accept(id, a[1]) ? "§aKlana katıldın." : "§cDavet geçersiz.");
            case "at" -> { OfflinePlayerLookup t = OfflinePlayerLookup.of(a.length > 1 ? a[1] : "");
                p.sendMessage(t != null && clans.kick(id, t.id) ? "§aÜye atıldı." : "§cİşlem başarısız."); }
            case "ayril" -> p.sendMessage(clans.leave(id) ? "§eKlandan ayrıldın." : "§cKlanın yok.");
            case "devret" -> { Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null;
                p.sendMessage(t != null && clans.transfer(id, t.getUniqueId()) ? "§aLiderlik devredildi." : "§cİşlem başarısız."); }
            case "dagit" -> p.sendMessage(clans.disband(id) ? "§eKlan dağıtıldı." : "§cYetkin yok.");
            case "bilgi" -> { var k = clans.of(id); if (k == null) { p.sendMessage("§cKlanın yok."); return; }
                p.sendMessage("§b[" + k.tag + "] " + k.name + " §7| Seviye " + k.level() + " | Puan " + k.points + " | Üye " + k.members.size() + "/" + clans.capacity(k) + " | " + k.wins + "G-" + k.losses + "M"); }
            case "top" -> { int i = 1; for (var k : clans.ranking(10)) p.sendMessage("§e" + (i++) + ". §f[" + k.tag + "] " + k.name + " §7- " + k.points + " puan"); }
            default -> p.sendMessage("§cBilinmeyen alt komut.");
        }
    }

    private void quest(Player p, String[] a) {
        UUID id = p.getUniqueId(); LocalDate d = today();
        String sub = a.length == 0 ? "liste" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "liste" -> { for (var q : quests.quests()) p.sendMessage("§f" + q.id() + " §7[" + q.period() + "] §a" + quests.progress(id, q.id(), d) + "/" + q.target()
                    + (quests.of(id).claimed.contains(q.id()) ? " §8(alındı)" : ""));
                p.sendMessage("§bBattle Pass kademe: " + quests.passTier(id) + " | Giriş serisi: " + quests.of(id).streak); }
            case "al" -> { var q = a.length > 1 ? quests.claim(id, a[1], d) : null;
                if (q == null) { p.sendMessage("§cÖdül alınamaz (tamamlanmamış veya zaten alındı)."); return; }
                if (q.coins() > 0) ledger.deposit(mode, id, q.coins(), "quest:" + q.id());
                p.sendMessage("§a" + q.id() + " ödülü: " + q.xp() + " pass XP, " + q.coins() + " para" + (q.cosmetic() == null ? "" : ", kozmetik: " + q.cosmetic())); }
            case "gunluk" -> { Integer day = quests.dailyLogin(id, d);
                if (day == null) { p.sendMessage("§cBugünkü ödülünü zaten aldın."); return; }
                long coins = 50L * day; ledger.deposit(mode, id, coins, "daily-login"); quests.of(id).passXp += 20L * day;
                p.sendMessage("§aGünlük giriş serisi " + day + ". gün: " + coins + " para + " + (20 * day) + " pass XP"); }
            default -> p.sendMessage("§e/gorevler liste | al <id> | gunluk");
        }
    }

    private record OfflinePlayerLookup(UUID id) {
        static OfflinePlayerLookup of(String name) {
            if (name.isBlank()) return null;
            var op = Bukkit.getOfflinePlayerIfCached(name);
            return op == null ? null : new OfflinePlayerLookup(op.getUniqueId());
        }
    }
}
