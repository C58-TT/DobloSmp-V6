# Android ile VPS yönetimi
- Android SSH istemcisi (ör. Termius/JuiceSSH) ile VPS'e bağlan.
- Sunucu durumunu: `sudo systemctl status doblosmp`
- Başlat: `sudo systemctl start doblosmp`
- Durdur: `sudo systemctl stop doblosmp`
- Yeniden başlat: `sudo systemctl restart doblosmp`
- Log izle: `sudo journalctl -u doblosmp -f`
- Konsol komutları için Paper console erişimi sağlayan güvenli SSH oturumu kullan.
- Web panel bu pakette bulunmaz.
