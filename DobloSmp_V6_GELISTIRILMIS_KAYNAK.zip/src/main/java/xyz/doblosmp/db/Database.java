package xyz.doblosmp.db;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.concurrent.*;
import java.util.function.Function;
import java.util.logging.Logger;

/**
 * Basit, bağımlılıksız bağlantı havuzu + otomatik migration. Tüm yazmalar PreparedStatement ile;
 * {@link #tx} işlemi tek transaction'da çalıştırır, hata olursa geri alır.
 */
public final class Database implements AutoCloseable {
    @FunctionalInterface public interface Work<T> { T run(Connection c) throws SQLException; }

    private final String url, user, pass; private final BlockingQueue<Connection> pool; private final int size;
    private final ExecutorService writer = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "DobloSuite-DB"); t.setDaemon(true); return t; });
    private final Logger log; private volatile boolean closed;

    public Database(String url, String user, String pass, int size, Logger log, String driverClass, ClassLoader cl) throws SQLException {
        if (driverClass != null && !driverClass.isBlank()) { try { Class.forName(driverClass, true, cl); } catch (ClassNotFoundException e) { throw new SQLException("JDBC sürücüsü yok: " + driverClass); } }
        this.url = url; this.user = user; this.pass = pass; this.size = Math.max(2, size); this.log = log;
        pool = new ArrayBlockingQueue<>(this.size);
        for (int i = 0; i < this.size; i++) pool.add(open());
    }
    private Connection open() throws SQLException { Connection c = DriverManager.getConnection(url, user, pass); c.setAutoCommit(true); return c; }

    private Connection borrow() throws SQLException {
        try {
            Connection c = pool.poll(10, TimeUnit.SECONDS);
            if (c == null) throw new SQLException("Bağlantı havuzu dolu (10 sn zaman aşımı)");
            if (c.isClosed() || !c.isValid(2)) { try { c.close(); } catch (SQLException ignored) {} c = open(); }
            return c;
        } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new SQLException(e); }
    }
    private void giveBack(Connection c) { if (!pool.offer(c)) try { c.close(); } catch (SQLException ignored) {} }

    public <T> T read(Work<T> w) throws SQLException { Connection c = borrow(); try { return w.run(c); } finally { giveBack(c); } }

    /** Tek transaction: başarısızsa rollback. */
    public <T> T tx(Work<T> w) throws SQLException {
        Connection c = borrow();
        try { c.setAutoCommit(false); T r = w.run(c); c.commit(); return r; }
        catch (SQLException | RuntimeException e) { try { c.rollback(); } catch (SQLException ignored) {} throw e; }
        finally { try { c.setAutoCommit(true); } catch (SQLException ignored) {} giveBack(c); }
    }

    /** Ana thread'i bloklamadan sıralı yazma. */
    public Future<?> async(Work<?> w) {
        if (closed) return CompletableFuture.completedFuture(null);
        return writer.submit(() -> { try { tx(w); } catch (Exception e) { log.severe("DB yazma hatası: " + e.getMessage()); } });
    }

    /** classpath'teki db/V{n}__*.sql dosyalarını sırayla uygular; uygulananları schema_version'da tutar. */
    public void migrate(String... resources) throws SQLException {
        read(c -> { try (Statement s = c.createStatement()) { s.execute("CREATE TABLE IF NOT EXISTS schema_version (version INT NOT NULL PRIMARY KEY, script VARCHAR(128) NOT NULL, applied BIGINT NOT NULL)"); } return null; });
        for (String res : resources) {
            int v = Integer.parseInt(res.replaceAll(".*/V(\\d+)__.*", "$1"));
            boolean done = read(c -> { try (PreparedStatement ps = c.prepareStatement("SELECT 1 FROM schema_version WHERE version=?")) { ps.setInt(1, v); try (ResultSet rs = ps.executeQuery()) { return rs.next(); } } });
            if (done) continue;
            String sql;
            try (InputStream in = Database.class.getResourceAsStream(res)) {
                if (in == null) throw new SQLException("Migration bulunamadı: " + res);
                sql = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            } catch (java.io.IOException e) { throw new SQLException(e); }
            tx(c -> {
                for (String stmt : sql.split(";\\s*\\n|;\\s*$")) { if (stmt.isBlank()) continue; try (Statement s = c.createStatement()) { s.execute(stmt); } }
                try (PreparedStatement ps = c.prepareStatement("INSERT INTO schema_version(version,script,applied) VALUES(?,?,?)")) { ps.setInt(1, v); ps.setString(2, res); ps.setLong(3, System.currentTimeMillis()); ps.executeUpdate(); }
                return null; });
            log.info("DB migration uygulandı: " + res);
        }
    }

    @Override public void close() {
        closed = true; writer.shutdown();
        try { writer.awaitTermination(15, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        Connection c; while ((c = pool.poll()) != null) try { c.close(); } catch (SQLException ignored) {}
    }
    public static <T> Function<T, T> id() { return x -> x; }
}
