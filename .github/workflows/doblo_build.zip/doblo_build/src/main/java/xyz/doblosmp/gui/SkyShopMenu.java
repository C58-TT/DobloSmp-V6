package xyz.doblosmp.gui;

import org.bukkit.*;
import org.bukkit.block.BlockState;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.economy.SkyShop;

import java.util.*;

/** /ada shop menüsü. Yalnızca komutla açılır. Fiyatlar config: skyblock.shop.prices.<ÜRÜN_ID>: [alış, satış]. */
public final class SkyShopMenu implements Listener {
    private static SkyShop shop = new SkyShop();
    private static NamespacedKey spawnerKey;

    private SkyShopMenu() {}

    public static SkyShopMenu init(JavaPlugin plugin) {
        spawnerKey = new NamespacedKey(plugin, "spawner_type");
        shop = new SkyShop();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("skyblock.shop.prices");
        if (sec != null) {
            Map<String, long[]> o = new HashMap<>();
            for (String id : sec.getKeys(false)) { List<Long> v = sec.getLongList(id); if (v.size() >= 2) o.put(id, new long[]{v.get(0), v.get(1)}); }
            int n = shop.applyOverrides(o); plugin.getLogger().info("Ada marketi: " + n + " ürün fiyatı config'ten yüklendi.");
        }
        return new SkyShopMenu();
    }

    private static String mode() { return Ctx.mode("skyblock"); }
    private static String money(long v) { return String.format(Locale.forLanguageTag("tr"), "%,d$", v); }

    public static void open(Player p) {
        Menu m = new Menu("§6§lAda Marketi", 3);
        Material[] icons = {Material.WHEAT, Material.DIAMOND_PICKAXE, Material.BRICKS, Material.BONE, Material.SPAWNER, Material.NETHER_STAR};
        int[] slots = {10, 11, 12, 14, 15, 16};
        for (SkyShop.Category c : SkyShop.Category.values())
            m.set(slots[c.ordinal()], Menu.item(icons[c.ordinal()], "§e" + c.label, "§7Ürün sayısı: §f" + shop.in(c).size(), "§7Tıkla ve ürünleri gör"), pl -> category(pl, c));
        m.set(22, Menu.item(Material.GOLD_INGOT, "§6Bakiyen", "§f" + money(Ctx.ledger.balance(mode(), p.getUniqueId()))), null);
        m.fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }

    private static void category(Player p, SkyShop.Category c) {
        List<SkyShop.Product> l = shop.in(c);
        Menu m = new Menu("§6" + c.label, 6);
        for (int i = 0; i < l.size() && i < 45; i++) { SkyShop.Product pr = l.get(i); m.set(i, icon(pr), pl -> detail(pl, pr)); }
        m.set(49, Menu.item(Material.GOLD_INGOT, "§6Bakiyen", "§f" + money(Ctx.ledger.balance(mode(), p.getUniqueId()))), null);
        m.back(SkyShopMenu::open).open(p);
    }

    private static void detail(Player p, SkyShop.Product pr) {
        Menu m = new Menu("§6" + pr.display(), 3);
        m.set(4, icon(pr), null);
        if (pr.canBuy()) m.set(11, Menu.item(Material.LIME_CONCRETE, "§aSatın Al", "§7Miktar: §f" + pr.amount(), "§7Fiyat: §f" + money(pr.buy())), pl -> { act(pl, pr, true); detail(pl, pr); });
        else m.set(11, Menu.item(Material.RED_CONCRETE, "§cSatın alınamaz"), null);
        if (pr.canSell()) m.set(15, Menu.item(Material.ORANGE_CONCRETE, "§6Sat", "§7Miktar: §f" + pr.amount(), "§7Kazanç: §f" + money(pr.sell())), pl -> { act(pl, pr, false); detail(pl, pr); });
        else m.set(15, Menu.item(Material.RED_CONCRETE, "§cSatılamaz"), null);
        m.set(22, Menu.item(Material.GOLD_INGOT, "§6Bakiyen", "§f" + money(Ctx.ledger.balance(mode(), p.getUniqueId()))), null);
        m.back(pl -> category(pl, pr.cat())).fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }

    private static void act(Player p, SkyShop.Product pr, boolean buy) {
        Inv inv = new Inv(p.getInventory());
        SkyShop.Result r = buy ? shop.buy(Ctx.ledger, mode(), p.getUniqueId(), pr.id(), inv) : shop.sell(Ctx.ledger, mode(), p.getUniqueId(), pr.id(), inv);
        p.sendMessage(r == SkyShop.Result.OK ? (buy ? "§a" + pr.amount() + "x " + pr.display() + " satın alındı: §f-" + money(pr.buy()) : "§a" + pr.amount() + "x " + pr.display() + " satıldı: §f+" + money(pr.sell())) : SkyShop.message(r));
    }

    private static ItemStack icon(SkyShop.Product pr) {
        ItemStack it = stack(pr, Math.min(pr.amount(), 64));
        var meta = it.getItemMeta(); List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        lore.add(Menu.color("§7Miktar: §f" + pr.amount()));
        lore.add(Menu.color(pr.canBuy() ? "§7Alış: §a" + money(pr.buy()) : "§7Alış: §cSatın alınamaz"));
        lore.add(Menu.color(pr.canSell() ? "§7Satış: §6" + money(pr.sell()) : "§7Satış: §cSatılamaz"));
        lore.add(Menu.color("§8Tıkla")); meta.lore(lore); meta.displayName(Menu.color("§f" + pr.display())); it.setItemMeta(meta); return it;
    }

    /** Ürünün gerçek eşyası. Spawner: BlockStateMeta + PDC etiketi (yerleştirirken tür garanti edilir). */
    static ItemStack stack(SkyShop.Product pr, int amount) {
        Material mat = Material.valueOf(pr.material()); ItemStack it = new ItemStack(mat, Math.max(1, amount));
        if (pr.entity() != null) {
            var meta = (BlockStateMeta) it.getItemMeta(); BlockState bs = meta.getBlockState();
            if (bs instanceof CreatureSpawner cs) { cs.setSpawnedType(EntityType.valueOf(pr.entity())); meta.setBlockState(cs); }
            meta.displayName(Menu.color("§e" + pr.display()));
            meta.getPersistentDataContainer().set(spawnerKey, PersistentDataType.STRING, pr.entity()); it.setItemMeta(meta);
        }
        return it;
    }

    /** Spawner yerleştirilince türü eşyadan okunur (mob üretimi garantisi). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (e.getBlockPlaced().getType() != Material.SPAWNER) return;
        var meta = e.getItemInHand().getItemMeta(); if (meta == null) return;
        String t = meta.getPersistentDataContainer().get(spawnerKey, PersistentDataType.STRING); if (t == null) return;
        try { if (e.getBlockPlaced().getState() instanceof CreatureSpawner cs) { cs.setSpawnedType(EntityType.valueOf(t)); cs.update(); } } catch (IllegalArgumentException ignored) {}
    }

    /** Bukkit envanteri ↔ SkyShop.InventoryPort. Yalnızca 36 depolama yuvası kullanılır (zırh/off-hand hariç). */
    private static final class Inv implements SkyShop.InventoryPort {
        private final PlayerInventory inv; Inv(PlayerInventory i) { inv = i; }
        public int count(SkyShop.Product p) {
            if (p.entity() != null) return 0; Material m = Material.valueOf(p.material()); int n = 0;
            for (ItemStack s : inv.getStorageContents()) if (s != null && s.getType() == m && !s.hasItemMeta()) n += s.getAmount(); return n;
        }
        public boolean canFit(SkyShop.Product p, int amount) {
            ItemStack proto = stack(p, 1); int max = proto.getMaxStackSize(), room = 0;
            for (ItemStack s : inv.getStorageContents()) { if (s == null || s.getType().isAir()) room += max; else if (s.isSimilar(proto)) room += Math.max(0, max - s.getAmount()); }
            return room >= amount;
        }
        public boolean add(SkyShop.Product p, int amount) {
            ItemStack proto = stack(p, 1); int max = proto.getMaxStackSize(), left = amount;
            while (left > 0) { int n = Math.min(max, left); if (!inv.addItem(stack(p, n)).isEmpty()) return false; left -= n; } return true;
        }
        public boolean remove(SkyShop.Product p, int amount) {
            if (p.entity() != null || count(p) < amount) return false; Material m = Material.valueOf(p.material()); int left = amount;
            ItemStack[] c = inv.getStorageContents();
            for (int i = 0; i < c.length && left > 0; i++) { ItemStack s = c[i]; if (s == null || s.getType() != m || s.hasItemMeta()) continue;
                int t = Math.min(left, s.getAmount()); if (t == s.getAmount()) c[i] = null; else s.setAmount(s.getAmount() - t); left -= t; }
            inv.setStorageContents(c); return left == 0;
        }
    }
}
