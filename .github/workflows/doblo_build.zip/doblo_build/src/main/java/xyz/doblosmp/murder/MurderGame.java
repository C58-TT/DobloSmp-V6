package xyz.doblosmp.murder;

import java.util.*;

/** Murder Mystery saf oyun mantığı: rol dağıtımı, ölüm, yay düşürme, kazanma koşulları. */
public final class MurderGame {
    public enum Role { MURDERER, DETECTIVE, INNOCENT }
    public enum Winner { NONE, MURDERER, INNOCENTS }

    private final Map<UUID, Role> roles = new LinkedHashMap<>();
    private final Set<UUID> alive = new HashSet<>();
    private final long endsAt;
    private boolean bowDropped;
    private UUID bowHolder;
    private Winner result = Winner.NONE;

    public MurderGame(Collection<UUID> players, Random rng, long durationMs) {
        if (players.size() < 2) throw new IllegalArgumentException("En az 2 oyuncu gerekir");
        List<UUID> l = new ArrayList<>(players);
        Collections.shuffle(l, rng);
        roles.put(l.get(0), Role.MURDERER);
        int idx = 1;
        if (l.size() >= 3) { roles.put(l.get(1), Role.DETECTIVE); bowHolder = l.get(1); idx = 2; }
        for (; idx < l.size(); idx++) roles.put(l.get(idx), Role.INNOCENT);
        alive.addAll(roles.keySet());
        endsAt = System.currentTimeMillis() + durationMs;
    }

    /** Önceden seçilmiş rollerle (RoleChance) oluşturur; tek katil, tek şerif. */
    public MurderGame(Collection<UUID> players, UUID murderer, UUID sheriff, long durationMs) {
        if (players.size() < 2 || !players.contains(murderer) || (sheriff != null && (!players.contains(sheriff) || sheriff.equals(murderer))))
            throw new IllegalArgumentException("Geçersiz rol ataması");
        for (UUID u : players) roles.put(u, u.equals(murderer) ? Role.MURDERER : u.equals(sheriff) ? Role.DETECTIVE : Role.INNOCENT);
        bowHolder = sheriff; alive.addAll(roles.keySet());
        endsAt = System.currentTimeMillis() + durationMs;
    }

    public static final long SHOT_COOLDOWN_MS = 5000;
    private final Map<UUID, Long> lastShot = new HashMap<>();
    /** Ok atma izni: yalnızca ok sahibi (şerif veya oku alan masum), yaşıyor ve 5 sn cooldown dolmuş. */
    public boolean tryShoot(UUID p, long now) {
        if (result != Winner.NONE || !alive.contains(p) || !p.equals(bowHolder)) return false;
        Long last = lastShot.get(p);
        if (last != null && now - last < SHOT_COOLDOWN_MS) return false;
        lastShot.put(p, now); return true;
    }
    public long cooldownLeft(UUID p, long now) { Long l = lastShot.get(p); return l == null ? 0 : Math.max(0, SHOT_COOLDOWN_MS - (now - l)); }
    /** Şerif öldüğünde YAY düşmez; yalnızca OK düşer (bowDropped = "ok yerde"). */
    public boolean arrowDropped() { return bowDropped; }

    public Role role(UUID p) { return roles.get(p); }
    public boolean isAlive(UUID p) { return alive.contains(p); }
    public Set<UUID> alive() { return Collections.unmodifiableSet(alive); }
    public Winner winner() { return result; }
    public boolean bowDropped() { return bowDropped; }
    public UUID bowHolder() { return bowHolder; }

    /** killer, victim'i öldürdü (kılıç veya ok). Masum masumu vurursa killer da ölür. */
    public Winner kill(UUID killer, UUID victim) {
        if (result != Winner.NONE || !alive.contains(victim) || (killer != null && !alive.contains(killer))) return result;
        alive.remove(victim);
        if (victim.equals(bowHolder)) { bowHolder = null; bowDropped = true; }
        if (killer != null && roles.get(killer) != Role.MURDERER && roles.get(victim) == Role.INNOCENT) {
            alive.remove(killer);                       // masumu vuran masum cezalandırılır
            if (killer.equals(bowHolder)) { bowHolder = null; bowDropped = true; }
        }
        return evaluate();
    }

    /** Yay yerden alındı (yalnızca yaşayan masum/dedektif). */
    public boolean pickupBow(UUID p) {
        if (!bowDropped || !alive.contains(p) || roles.get(p) == Role.MURDERER) return false;
        bowHolder = p; bowDropped = false; return true;
    }

    public Winner leave(UUID p) { alive.remove(p); return evaluate(); }

    public Winner tick() {
        if (result == Winner.NONE && System.currentTimeMillis() > endsAt) result = Winner.INNOCENTS;
        return result;
    }

    private Winner evaluate() {
        UUID m = roles.entrySet().stream().filter(e -> e.getValue() == Role.MURDERER).map(Map.Entry::getKey).findFirst().orElse(null);
        boolean murdererAlive = m != null && alive.contains(m);
        long others = alive.stream().filter(u -> !u.equals(m)).count();
        if (!murdererAlive) result = Winner.INNOCENTS;
        else if (others == 0) result = Winner.MURDERER;
        return result;
    }
}
