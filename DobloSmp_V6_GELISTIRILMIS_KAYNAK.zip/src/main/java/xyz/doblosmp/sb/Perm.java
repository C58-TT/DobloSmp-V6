package xyz.doblosmp.sb;

/** Ada izinleri. Her izin için gereken asgari rol ada başına /is settings ile değiştirilebilir. */
public enum Perm {
    BREAK(Role.MEMBER), PLACE(Role.MEMBER), CONTAINERS(Role.MEMBER), DOORS(Role.MEMBER), ANIMALS(Role.MEMBER), FARM(Role.MEMBER),
    INVITE(Role.MODERATOR), KICK(Role.MODERATOR), BAN(Role.MODERATOR), SETHOME(Role.MODERATOR), UPGRADE(Role.OWNER), SETTINGS(Role.OWNER);
    public final Role def;
    Perm(Role d) { def = d; }
}
