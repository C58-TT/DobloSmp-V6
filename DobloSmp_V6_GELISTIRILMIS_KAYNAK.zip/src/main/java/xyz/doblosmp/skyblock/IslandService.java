package xyz.doblosmp.skyblock;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.*;
import java.util.*;

/** Basic grid island allocator with owner/member protection. Not a full SkyBlock engine. */
public final class IslandService implements CommandExecutor, Listener {
 private final JavaPlugin plugin; private final File file; private final YamlConfiguration data;
 private final Map<UUID,UUID> pending = new HashMap<>();
 public IslandService(JavaPlugin p){plugin=p;file=new File(p.getDataFolder(),"islands.yml");data=YamlConfiguration.loadConfiguration(file);}
 public void save(){try{data.save(file);}catch(IOException e){plugin.getLogger().warning("Ada verisi kaydedilemedi: "+e.getMessage());}}
 private String key(UUID id){return id.toString();}
 private boolean ownsOrMember(Player p, String owner){return p.getUniqueId().toString().equals(owner)||data.getStringList(owner+".members").contains(p.getUniqueId().toString());}
 private String islandOwnerAt(Location loc){if(loc.getWorld()==null||!loc.getWorld().getName().equals(plugin.getConfig().getString("skyblock.world","skyblock")))return null;int spacing=Math.max(64,plugin.getConfig().getInt("skyblock.island-spacing",256));int x=Math.floorDiv(loc.getBlockX(),spacing)*spacing;int z=Math.floorDiv(loc.getBlockZ(),spacing)*spacing;for(String id:data.getKeys(false)){if(data.getInt(id+".x",Integer.MIN_VALUE)==x&&data.getInt(id+".z",Integer.MIN_VALUE)==z)return id;}return null;}
 private boolean protectedAction(Player p, Location loc){String owner=islandOwnerAt(loc);return owner!=null&&!ownsOrMember(p,owner);}
 @EventHandler(ignoreCancelled=true) public void onBreak(BlockBreakEvent e){if(protectedAction(e.getPlayer(),e.getBlock().getLocation())){e.setCancelled(true);e.getPlayer().sendMessage("§cBu ada sana ait değil.");}}
 @EventHandler(ignoreCancelled=true) public void onPlace(BlockPlaceEvent e){if(protectedAction(e.getPlayer(),e.getBlock().getLocation())){e.setCancelled(true);e.getPlayer().sendMessage("§cBu ada sana ait değil.");}}
 @EventHandler(ignoreCancelled=true) public void onInteract(PlayerInteractEvent e){Block b=e.getClickedBlock();if(b!=null&&protectedAction(e.getPlayer(),b.getLocation())){e.setCancelled(true);e.getPlayer().sendMessage("§cBu ada sana ait değil.");}}
 @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){if(!(sender instanceof Player p)){sender.sendMessage("Bu komut oyuncu içindir.");return true;}if(args.length==0){p.sendMessage("/ada <olustur|bilgi|ev|davet|kabul|at>");return true;}String k=key(p.getUniqueId());switch(args[0].toLowerCase(Locale.ROOT)){
 case "olustur"->{if(data.contains(k+".x")){p.sendMessage("§cZaten adan var.");return true;}World w=Bukkit.getWorld(plugin.getConfig().getString("skyblock.world","skyblock"));if(w==null){p.sendMessage("§cSkyBlock dünyası bulunamadı. Önce ayrı bir void dünya oluştur.");return true;}int spacing=Math.max(64,plugin.getConfig().getInt("skyblock.island-spacing",256));int n=data.getKeys(false).size(),x=n*spacing,z=0;data.set(k+".world",w.getName());data.set(k+".x",x);data.set(k+".z",z);data.set(k+".owner",p.getName());data.set(k+".members",new ArrayList<String>());w.getBlockAt(x,64,z).setType(Material.GRASS_BLOCK);w.getBlockAt(x,63,z).setType(Material.DIRT);w.getBlockAt(x,62,z).setType(Material.DIRT);save();p.teleport(new Location(w,x+0.5,65,z+0.5));p.sendMessage("§aAda oluşturuldu. Ada koruması temel seviyededir.");}
 case "ev"->{if(!data.contains(k+".x")){p.sendMessage("§cÖnce /ada olustur.");return true;}World w=Bukkit.getWorld(data.getString(k+".world"));if(w!=null)p.teleport(new Location(w,data.getInt(k+".x")+0.5,65,data.getInt(k+".z")+0.5));}
 case "bilgi"->{String owner=k;if(!data.contains(owner+".x")){p.sendMessage("§cHenüz adan yok.");return true;}p.sendMessage("§bAda sahibi: "+data.getString(owner+".owner")+" §7| Üye: "+data.getStringList(owner+".members").size());}
 case "davet"->{if(args.length<2||!data.contains(k+".x")){p.sendMessage("§cKullanım: /ada davet <oyuncu> (ada sahibi olmalısın)");return true;}Player target=Bukkit.getPlayerExact(args[1]);if(target==null){p.sendMessage("§cOyuncu çevrimiçi değil.");return true;}pending.put(target.getUniqueId(),p.getUniqueId());target.sendMessage("§e"+p.getName()+" seni adasına davet etti. /ada kabul");p.sendMessage("§aDavet gönderildi.");}
 case "kabul"->{UUID owner=pending.remove(p.getUniqueId());if(owner==null||!data.contains(key(owner)+".x")){p.sendMessage("§cGeçerli ada davetin yok.");return true;}List<String> members=data.getStringList(key(owner)+".members");if(!members.contains(k))members.add(k);data.set(key(owner)+".members",members);save();p.sendMessage("§aAdaya üye oldun.");}
 case "at"->{if(args.length<2||!data.contains(k+".x")){p.sendMessage("§cKullanım: /ada at <oyuncu> (yalnızca ada sahibi)");return true;}OfflinePlayer target=Bukkit.getOfflinePlayer(args[1]);List<String> members=data.getStringList(k+".members");if(members.remove(target.getUniqueId().toString())){data.set(k+".members",members);save();p.sendMessage("§aÜye adadan çıkarıldı.");}else p.sendMessage("§cBu oyuncu ada üyesi değil.");}
 default->p.sendMessage("/ada <olustur|bilgi|ev|davet|kabul|at>");}return true;}
}
