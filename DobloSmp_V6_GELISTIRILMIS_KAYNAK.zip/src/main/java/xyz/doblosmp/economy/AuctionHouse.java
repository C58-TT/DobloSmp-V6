package xyz.doblosmp.economy;

import java.util.*;

/** Açık artırma + oyuncu marketi (sabit fiyat). Bahis blokajı Ledger üzerinden güvenli yapılır. */
public final class AuctionHouse {
    public record Listing(long id, UUID seller, String item, int amount, long price, boolean auction,
                          long endsAt, UUID topBidder, long topBid) {}
    public record Sale(long listingId, UUID seller, UUID buyer, String item, int amount, long price, long time) {}

    private final Ledger ledger; private final String mode;
    private final Map<Long, Listing> listings = new LinkedHashMap<>();
    private final List<Sale> sales = new ArrayList<>();
    private final double taxRate;
    private long seq;

    public AuctionHouse(Ledger ledger, String mode, double taxRate) {
        this.ledger = ledger; this.mode = mode; this.taxRate = Math.min(0.5, Math.max(0, taxRate));
    }

    public synchronized long list(UUID seller, String item, int amount, long price, boolean auction, long durationMs) {
        if (amount <= 0 || price <= 0) return -1;
        long id = ++seq;
        listings.put(id, new Listing(id, seller, item, amount, price, auction,
                System.currentTimeMillis() + durationMs, null, 0));
        return id;
    }

    public synchronized boolean buyNow(long id, UUID buyer) {
        Listing l = listings.get(id);
        if (l == null || l.auction() || l.seller().equals(buyer)) return false;
        long tax = (long) (l.price() * taxRate);
        if (!ledger.transfer(mode, buyer, l.seller(), l.price(), "market")) return false;
        if (tax > 0) ledger.withdraw(mode, l.seller(), tax, "market-tax");
        listings.remove(id);
        sales.add(new Sale(id, l.seller(), buyer, l.item(), l.amount(), l.price(), System.currentTimeMillis()));
        return true;
    }

    /** Teklif: yeni teklif sahibinin parası bloke edilir, önceki teklif sahibine iade edilir. */
    public synchronized boolean bid(long id, UUID bidder, long amount) {
        Listing l = listings.get(id);
        if (l == null || !l.auction() || System.currentTimeMillis() > l.endsAt() || l.seller().equals(bidder)) return false;
        long min = l.topBid() == 0 ? l.price() : l.topBid() + Math.max(1, l.topBid() / 20);
        if (amount < min) return false;
        if (!ledger.withdraw(mode, bidder, amount, "bid-escrow")) return false;
        if (l.topBidder() != null) ledger.deposit(mode, l.topBidder(), l.topBid(), "bid-refund");
        listings.put(id, new Listing(id, l.seller(), l.item(), l.amount(), l.price(), true, l.endsAt(), bidder, amount));
        return true;
    }

    /** Süresi dolan açık artırmaları kapatır; satılan ve satılmayanları döndürür. */
    public synchronized List<Sale> settle() {
        long now = System.currentTimeMillis(); List<Sale> done = new ArrayList<>();
        for (Listing l : new ArrayList<>(listings.values())) {
            if (!l.auction() || now <= l.endsAt()) continue;
            listings.remove(l.id());
            if (l.topBidder() == null) continue;           // satılmadı; eşya satıcıya iade edilir (gateway'de)
            long tax = (long) (l.topBid() * taxRate);
            ledger.deposit(mode, l.seller(), l.topBid() - tax, "auction-proceeds");
            Sale s = new Sale(l.id(), l.seller(), l.topBidder(), l.item(), l.amount(), l.topBid(), now);
            sales.add(s); done.add(s);
        }
        return done;
    }

    public synchronized boolean cancel(long id, UUID seller) {
        Listing l = listings.get(id);
        if (l == null || !l.seller().equals(seller) || l.topBidder() != null) return false;
        listings.remove(id); return true;
    }
    /** Kalıcılık için: ilanları geri yükle (bahis blokajı dahil). */
    public synchronized void restore(Listing l) { listings.put(l.id(), l); seq = Math.max(seq, l.id()); }
    public synchronized List<Listing> active() { return new ArrayList<>(listings.values()); }
    public synchronized List<Sale> salesOf(UUID p) {
        return sales.stream().filter(s -> s.seller().equals(p) || s.buyer().equals(p)).toList();
    }
}
