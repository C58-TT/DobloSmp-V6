package xyz.doblosmp.social;

import java.util.*;

/** Parti: lider, davet (süreli), atma, devir, dağıtma. Paper'dan bağımsız. */
public final class PartyService {
    public static final class Party { public UUID leader; public final Set<UUID> members = new LinkedHashSet<>(); Party(UUID l) { leader = l; members.add(l); } }
    private final Map<UUID, Party> byPlayer = new HashMap<>();
    private final Map<UUID, Object[]> invites = new HashMap<>();     // hedef -> {lider, bitiş}
    private final int max; private final long ttl;
    public PartyService(int max, long inviteTtlMs) { this.max = max; this.ttl = inviteTtlMs; }

    public synchronized Party of(UUID p) { return byPlayer.get(p); }
    public synchronized Party create(UUID leader) { if (byPlayer.containsKey(leader)) return null; Party p = new Party(leader); byPlayer.put(leader, p); return p; }
    public synchronized boolean invite(UUID by, UUID target, long now) {
        Party p = byPlayer.get(by); if (p == null) p = create(by);
        if (!p.leader.equals(by) || byPlayer.containsKey(target) || p.members.size() >= max || by.equals(target)) return false;
        invites.put(target, new Object[]{by, now + ttl}); return true;
    }
    public synchronized boolean accept(UUID target, long now) {
        Object[] inv = invites.remove(target); if (inv == null || (Long) inv[1] < now) return false;
        Party p = byPlayer.get((UUID) inv[0]); if (p == null || byPlayer.containsKey(target) || p.members.size() >= max) return false;
        p.members.add(target); byPlayer.put(target, p); return true;
    }
    public synchronized boolean kick(UUID by, UUID target) {
        Party p = byPlayer.get(by); if (p == null || !p.leader.equals(by) || by.equals(target) || !p.members.remove(target)) return false;
        byPlayer.remove(target); return true;
    }
    /** Lider ayrılırsa lider devredilir; tek kişi kalırsa parti dağılır. */
    public synchronized boolean leave(UUID p) {
        Party party = byPlayer.remove(p); if (party == null) return false;
        party.members.remove(p);
        if (party.members.size() <= 1) { party.members.forEach(byPlayer::remove); party.members.clear(); }
        else if (party.leader.equals(p)) party.leader = party.members.iterator().next();
        return true;
    }
    public synchronized boolean transfer(UUID by, UUID to) {
        Party p = byPlayer.get(by); if (p == null || !p.leader.equals(by) || !p.members.contains(to)) return false; p.leader = to; return true;
    }
    public synchronized boolean disband(UUID by) {
        Party p = byPlayer.get(by); if (p == null || !p.leader.equals(by)) return false;
        p.members.forEach(byPlayer::remove); p.members.clear(); return true;
    }
    public synchronized List<UUID> members(UUID p) { Party x = byPlayer.get(p); return x == null ? List.of(p) : new ArrayList<>(x.members); }
}
