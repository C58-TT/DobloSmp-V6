package xyz.doblosmp.glue;

import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;
import java.util.function.IntConsumer;

/**
 * Bedrock desteği (Geyser + Floodgate DIŞ PLUGİN gerekir). Tanıma: Floodgate API (yansıma ile) → yoksa UUID'nin üst bitleri 0 olması / "." öneki.
 * Menüler zaten sandık envanteridir; Geyser bunları Bedrock'ta otomatik gösterir. Floodgate varsa ana menü ek olarak Bedrock FORMU ile açılır.
 * UYARI: Form kodu Floodgate/Cumulus API adlarına yansıma ile bağlanır ve gerçek sunucuda DOĞRULANMADI.
 */
public final class BedrockSupport {
    private BedrockSupport() {}
    private static Object api; private static boolean tried;

    private static Object api() {
        if (!tried) { tried = true; try { Class<?> c = Class.forName("org.geysermc.floodgate.api.FloodgateApi"); api = c.getMethod("getInstance").invoke(null); } catch (ReflectiveOperationException | LinkageError e) { api = null; } }
        return api;
    }
    public static boolean floodgate() { return api() != null; }
    public static boolean isBedrock(Player p) { return isBedrock(p.getUniqueId(), p.getName()); }
    public static boolean isBedrock(UUID id, String name) {
        Object a = api();
        if (a != null) try { return (boolean) a.getClass().getMethod("isFloodgatePlayer", UUID.class).invoke(a, id); } catch (ReflectiveOperationException ignored) {}
        return id.getMostSignificantBits() == 0L || name.startsWith(".");
    }

    /** Basit liste formu. Başarılıysa true; Floodgate yoksa/başarısızsa false (çağıran sandık menüsüne düşer). */
    public static boolean simpleForm(Player p, String title, String content, List<String> buttons, IntConsumer onClick) {
        Object a = api(); if (a == null || !isBedrock(p)) return false;
        try {
            Class<?> sf = Class.forName("org.geysermc.cumulus.form.SimpleForm"); Object b = sf.getMethod("builder").invoke(null);
            Class<?> bc = b.getClass(); Method titleM = find(bc, "title", String.class), contentM = find(bc, "content", String.class), btnM = find(bc, "button", String.class);
            titleM.invoke(b, title); contentM.invoke(b, content); for (String s : buttons) btnM.invoke(b, s);
            Class<?> resp = Class.forName("org.geysermc.cumulus.response.SimpleFormResponse");
            Method handler = find(bc, "validResultHandler", java.util.function.Consumer.class);
            java.util.function.Consumer<Object> cons = r -> { try { onClick.accept((int) resp.getMethod("clickedButtonId").invoke(r)); } catch (ReflectiveOperationException ignored) {} };
            handler.invoke(b, cons); Object form = bc.getMethod("build").invoke(b);
            for (Method m : a.getClass().getMethods()) if (m.getName().equals("sendForm") && m.getParameterCount() == 2 && m.getParameterTypes()[0] == UUID.class && m.getParameterTypes()[1].isInstance(form)) { m.invoke(a, p.getUniqueId(), form); return true; }
        } catch (ReflectiveOperationException | LinkageError | RuntimeException e) { return false; }
        return false;
    }
    private static Method find(Class<?> c, String name, Class<?> arg) throws NoSuchMethodException { for (Method m : c.getMethods()) if (m.getName().equals(name) && m.getParameterCount() == 1 && m.getParameterTypes()[0].isAssignableFrom(arg)) return m; throw new NoSuchMethodException(name); }
}
