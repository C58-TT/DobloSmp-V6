package xyz.doblosmp.duels;

public final class Elo {
    private Elo() {}
    public static final int START = 1000;

    public static int expectedDelta(int ra, int rb, boolean aWon, int k) {
        double ea = 1.0 / (1.0 + Math.pow(10, (rb - ra) / 400.0));
        return (int) Math.round(k * ((aWon ? 1.0 : 0.0) - ea));
    }

    public static String league(int elo) {
        if (elo < 900) return "Bakır";
        if (elo < 1100) return "Demir";
        if (elo < 1300) return "Altın";
        if (elo < 1500) return "Elmas";
        if (elo < 1750) return "Zümrüt";
        return "Netherite";
    }
}
