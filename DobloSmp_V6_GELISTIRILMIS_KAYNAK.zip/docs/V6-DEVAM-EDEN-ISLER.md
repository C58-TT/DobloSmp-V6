# DobloSmp V6 – devam eden geliştirme / doğrulama

Bu paket V5 kaynaklarının üzerinde yapılan V6 hazırlık değişikliklerini içerir. **Paper gerçek sunucuda çalıştırma, oyun modu uçtan uca testleri ve performans ölçümü tamamlanmış sayılmaz.**

## Uygulanan değişiklikler
- Web paneli kaynak kodu, HTML, web klasörü ve panel nginx örnek yapılandırması kaldırıldı.
- `/lobby` komutu eklendi; oyuncuyu yapılandırılan lobi dünyasının spawn noktasına götürür.
- Lobi NPC yöneticisi açılışta eksik varsayılan NPC'leri oluşturacak şekilde güncellendi; sağ tıklama eylemleri oyun menülerine bağlandı. Bu davranışın gerçek Paper sunucusunda doğrulanması gerekir.
- Lobi dünyası yükleyicisi, sunucu dizininde `lobby/level.dat` varsa Paper üzerinden yükler. Lobi yoksa boş dünya oluşturmadan uyarı verir.
- Lobi NPC yöneticisi, lobi yüklendikten sonra eksik varsayılan oyun NPC'lerini oluşturur; NPC sağ tıklamaları ilgili menülere/komutlara bağlanır. Bu davranış henüz gerçek Paper sunucusunda doğrulanmadı.
- `map-e2150.zip` haritasının dosyaları `worlds/lobby-world/` içine çıkarıldı. Orijinal zip korunmuştur.
- Otomatik yedek varsayılanı günlük (1440 dakika); Discord durum bildirimi varsayılanı 15 dakika.

## Lobi kurulumu
1. Sunucu ana dizinine `worlds/lobby-world/` içindeki dosyaları `lobby/` olarak kopyalayın.
2. Sunucuyu çalıştırın; `lobby` dünyası `level.dat` kontrolünden sonra yüklenir.
3. `/lobby` ile teleport deneyin. Spawn varsayılan dünya spawn'ıdır ve koordinatlar oyun içinde doğrulanmalıdır.
4. İsterseniz `config.yml` içinde `lobby.spawn.x/y/z/yaw/pitch` alanlarını ayarlayın.

## Discord Webhook
Webhook'u `DOBLO_DISCORD_WEBHOOK` ortam değişkeniyle verin. URL gizli anahtar gibi korunmalı; loglara veya zip'e yazılmamalıdır.
## Dış bağımlılıklar / henüz doğrulanmamış
- LuckPerms: rank/permission
- GrimAC: ek anti-cheat
- Geyser + Floodgate: Bedrock
- Vault: ekonomi API
- AuthMe Reloaded: offline/cracked mod gerekiyorsa
- ProtocolLib veya PacketEvents: paket düzeyi kontroller
## Test durumu
- V5'te bildirilen 258 test sonucu bu V6 değişikliklerini kapsamıyor.
- Maven bu çalışma ortamında kurulu değil; Paper API gerçek derlemesi ve testler çalıştırılamadı.
- Paper 1.21.11 üzerinde startup, lobby, oyun akışları, Bedrock, MariaDB ve perform testleri yapılmalı.
