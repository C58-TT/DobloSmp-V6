package xyz.doblosmp.sb;

import java.util.*;

public final class Island {
    public final long id; public UUID owner; public final int slot; public final String template; public final long createdAt;
    public final Map<UUID, Role> members = new LinkedHashMap<>();      // OWNER dahil değil
    public final Set<UUID> bans = new LinkedHashSet<>();
    public final Map<UUID, Integer> ratings = new HashMap<>();
    public final Map<String, Boolean> flags = new HashMap<>();         // visitors, pvp, mob_spawning, visitor_doors ...
    public final EnumMap<Perm, Role> required = new EnumMap<>(Perm.class);
    public int sizeTier, memberTier, generatorTier; public int resets;
    public double homeX, homeY = 65, homeZ;                            // ada merkezine göre ofset

    Island(long id, UUID owner, int slot, String template) {
        this.id = id; this.owner = owner; this.slot = slot; this.template = template; this.createdAt = System.currentTimeMillis();
        flags.put("visitors", true); flags.put("pvp", false); flags.put("mob_spawning", true); flags.put("visitor_doors", false);
    }
    /** Derin kopya (eşzamansız kayıt için). */
    public Island copy() {
        Island c = new Island(id, owner, slot, template);
        c.members.putAll(members); c.bans.addAll(bans); c.ratings.putAll(ratings); c.flags.clear(); c.flags.putAll(flags); c.required.putAll(required);
        c.sizeTier = sizeTier; c.memberTier = memberTier; c.generatorTier = generatorTier; c.resets = resets; c.homeX = homeX; c.homeY = homeY; c.homeZ = homeZ;
        return c;
    }
    public Role roleOf(UUID p) { return p.equals(owner) ? Role.OWNER : members.getOrDefault(p, Role.VISITOR); }
    public Role need(Perm p) { return required.getOrDefault(p, p.def); }
    public double avgRating() { return ratings.isEmpty() ? 0 : ratings.values().stream().mapToInt(Integer::intValue).average().orElse(0); }
    public int memberCount() { return members.size() + 1; }
}
