#!/usr/bin/env bash
# Günlük MariaDB yedeği (cron: 15 4 * * * /opt/minecraft/scripts/backup-db.sh). Test EDİLMEDİ.
set -euo pipefail
OUT=/opt/minecraft/plugins/DobloSuite/backups/db; mkdir -p "$OUT"
F="$OUT/doblosmp-$(date +%F-%H%M).sql.gz"
mysqldump --single-transaction --routines doblosmp | gzip > "$F"
sha256sum "$F" > "$F.sha256"
ls -1t "$OUT"/*.sql.gz | tail -n +15 | xargs -r rm -f
