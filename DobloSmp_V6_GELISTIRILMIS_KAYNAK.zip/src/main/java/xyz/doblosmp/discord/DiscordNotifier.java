package xyz.doblosmp.discord;

import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.*;
import java.util.logging.Logger;

/**
 * Discord bildirimleri: Webhook veya Bot (REST, kanal mesajı). Token/URL kaynak koda yazılmaz; ortam değişkeni veya config'ten gelir.
 * Tek arka plan iş parçacığı, sınırlı kuyruk, 429 Retry-After desteği, @everyone/@here etkisizleştirme (allowed_mentions boş).
 * Gateway/slash komutlu tam bot YOKTUR; yalnızca mesaj gönderir.
 */
public final class DiscordNotifier implements AutoCloseable {
    public enum Kind { INFO(0x3498db), SUCCESS(0x2ecc71), WARN(0xf1c40f), ERROR(0xe74c3c), MOD(0x9b59b6);
        final int color; Kind(int c) { color = c; } }

    private final String webhook, botToken, channelId, apiBase; private final long minIntervalMs;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final BlockingQueue<String> queue = new LinkedBlockingQueue<>(200);
    private final Thread worker; private volatile boolean running = true; private final Logger log;
    public volatile int sent, failed, dropped;

    public DiscordNotifier(String webhook, String botToken, String channelId, String apiBase, long minIntervalMs, Logger log) {
        this.webhook = blank(webhook); this.botToken = blank(botToken); this.channelId = blank(channelId);
        this.apiBase = apiBase == null || apiBase.isBlank() ? "https://discord.com/api/v10" : apiBase; this.minIntervalMs = minIntervalMs; this.log = log;
        worker = new Thread(this::loop, "DobloSuite-Discord"); worker.setDaemon(true);
        if (enabled()) worker.start();
    }
    private static String blank(String s) { return s == null || s.isBlank() ? null : s.trim(); }
    public boolean enabled() { return webhook != null || (botToken != null && channelId != null); }

    static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) switch (c) { case '"' -> b.append("\\\""); case '\\' -> b.append("\\\\"); case '\n' -> b.append("\\n"); case '\r' -> {} case '\t' -> b.append(' ');
            default -> { if (c < 0x20) b.append(' '); else b.append(c); } }
        return b.toString();
    }
    /** Mention etkisizleştirme: @everyone/@here'e sıfır genişlikli boşluk koyar. */
    static String clean(String s, int max) {
        String t = s == null ? "" : s.replace("@everyone", "@\u200beveryone").replace("@here", "@\u200bhere").replaceAll("<@[&!]?\\d+>", "[mention]");
        return t.length() > max ? t.substring(0, max - 1) + "…" : t;
    }

    public void send(Kind kind, String title, String description) {
        if (!enabled()) return;
        String json = "{\"allowed_mentions\":{\"parse\":[]},\"embeds\":[{\"title\":\"" + esc(clean(title, 250)) + "\",\"description\":\"" + esc(clean(description, 3500))
                + "\",\"color\":" + kind.color + ",\"timestamp\":\"" + java.time.Instant.now() + "\"}]}";
        if (!queue.offer(json)) dropped++;
    }

    private void loop() {
        while (running || !queue.isEmpty()) {
            try {
                String body = queue.poll(500, TimeUnit.MILLISECONDS); if (body == null) continue;
                post(body, 0); Thread.sleep(minIntervalMs);
            } catch (InterruptedException e) { if (!running) break; }
        }
    }
    private void post(String body, int attempt) throws InterruptedException {
        try {
            HttpRequest.Builder rb = HttpRequest.newBuilder().timeout(Duration.ofSeconds(10)).header("Content-Type", "application/json");
            if (webhook != null) rb.uri(URI.create(webhook)); else rb.uri(URI.create(apiBase + "/channels/" + channelId + "/messages")).header("Authorization", "Bot " + botToken);
            HttpResponse<String> r = http.send(rb.POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8)).build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() == 429 && attempt < 3) {
                double wait = r.headers().firstValue("Retry-After").map(Double::parseDouble).orElse(2.0);
                Thread.sleep((long) (Math.min(30, wait) * 1000)); post(body, attempt + 1); return;
            }
            if (r.statusCode() / 100 == 2) sent++; else { failed++; log.warning("Discord HTTP " + r.statusCode()); }
        } catch (InterruptedException e) { throw e; }
        catch (Exception e) { failed++; log.warning("Discord gönderilemedi: " + e.getClass().getSimpleName()); }
    }

    /** Kuyruğu boşaltmaya çalışır (en fazla timeoutMs). Sunucu kapanış mesajı için. */
    public void flush(long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (!queue.isEmpty() && System.currentTimeMillis() < end) try { Thread.sleep(50); } catch (InterruptedException e) { return; }
    }
    @Override public void close() { running = false; worker.interrupt(); }
}
