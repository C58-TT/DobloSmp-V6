-- sudo mysql < mariadb-setup.sql   (parolayı DEĞİŞTİR; sonra ortam değişkeni DOBLO_DB_PASSWORD olarak ver)
CREATE DATABASE IF NOT EXISTS doblosmp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'doblo'@'127.0.0.1' IDENTIFIED BY 'DEGISTIR_BENI_UZUN_PAROLA';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, DROP ON doblosmp.* TO 'doblo'@'127.0.0.1';
FLUSH PRIVILEGES;
