package xyz.doblosmp.glue;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.discord.DiscordNotifier;

import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;

/** Discord olayları: giriş/çıkış, SEVERE hata günlüğü, periyodik durum. Ban/mute/rapor bildirimleri Punishments içindedir. */
public final class DiscordHooks implements Listener {
    private final JavaPlugin plugin; private final Handler errHandler; private long lastErr;
    public DiscordHooks(JavaPlugin plugin) {
        this.plugin = plugin;
        errHandler = new Handler() {
            @Override public void publish(LogRecord r) { if (r.getLevel().intValue() < Level.SEVERE.intValue()) return; long now = System.currentTimeMillis(); if (now - lastErr < 30_000L) return; lastErr = now;
                Ctx.discord(DiscordNotifier.Kind.ERROR, "Eklenti hatası", String.valueOf(r.getMessage()) + (r.getThrown() == null ? "" : "\n" + r.getThrown().getClass().getSimpleName() + ": " + r.getThrown().getMessage())); }
            @Override public void flush() {} @Override public void close() {}
        };
        plugin.getLogger().addHandler(errHandler);
    }
    public void close() { plugin.getLogger().removeHandler(errHandler); }
    @EventHandler public void onJoin(PlayerJoinEvent e) { if (plugin.getConfig().getBoolean("discord.notify-join-quit", true)) Ctx.discord(DiscordNotifier.Kind.SUCCESS, "Oyuncu girdi", e.getPlayer().getName() + (BedrockSupport.isBedrock(e.getPlayer()) ? " (Bedrock)" : " (Java)") + " — " + Bukkit.getOnlinePlayers().size() + " çevrimiçi"); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { if (plugin.getConfig().getBoolean("discord.notify-join-quit", true)) Ctx.discord(DiscordNotifier.Kind.INFO, "Oyuncu çıktı", e.getPlayer().getName() + " — " + (Bukkit.getOnlinePlayers().size() - 1) + " çevrimiçi"); }
}
