package xyz.doblosmp.anticheat;

/** Yapılandırılabilir yaptırım merdiveni: toplam şüphe puanına göre. */
public final class Sanction {
    public enum Action { NONE, ALERT, SETBACK, KICK, BAN }
    private final double alert, setback, kick, ban; private final boolean autoPunish;

    public Sanction(double alert, double setback, double kick, double ban, boolean autoPunish) {
        this.alert = alert; this.setback = setback; this.kick = kick; this.ban = ban; this.autoPunish = autoPunish;
    }
    /** autoPunish kapalıyken en fazla ALERT döner (varsayılan güvenli mod). */
    public Action decide(double total) {
        if (total >= ban) return autoPunish ? Action.BAN : Action.ALERT;
        if (total >= kick) return autoPunish ? Action.KICK : Action.ALERT;
        if (total >= setback) return autoPunish ? Action.SETBACK : Action.ALERT;
        if (total >= alert) return Action.ALERT;
        return Action.NONE;
    }
}
