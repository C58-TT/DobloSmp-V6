package xyz.doblosmp.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDropItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.scheduler.BukkitRunnable;
import java.nio.file.Files;

/** Loads the supplied lobby world if installed and sends joining players to its spawn. */
public final class LobbyManager implements Listener {
    private final DobloSuite plugin;
    private World lobbyWorld;
    public LobbyManager(DobloSuite plugin) {
        this.plugin = plugin;
        if (!plugin.getConfig().getBoolean("lobby.enabled", true)) return;
        String name = plugin.getConfig().getString("lobby.world", "lobby");
        var worldDir = Bukkit.getWorldContainer().toPath().resolve(name);
        if (!Files.isRegularFile(worldDir.resolve("level.dat"))) {
            plugin.getLogger().warning("Lobi dünyası bulunamadı: " + worldDir + " — lobby-world klasörünü sunucu ana dizinine '" + name + "' olarak kopyalayın.");
            return;
        }
        lobbyWorld = Bukkit.createWorld(new WorldCreator(name));
        if (lobbyWorld == null) { plugin.getLogger().severe("Lobi dünyası yüklenemedi: " + name); return; }
        plugin.getLogger().info("Lobi dünyası yüklendi: " + name);
    }
    public Location spawn() {
        if (lobbyWorld == null) return null;
        String path = "lobby.spawn";
        if (plugin.getConfig().contains(path + ".x")) return new Location(lobbyWorld,
            plugin.getConfig().getDouble(path + ".x"), plugin.getConfig().getDouble(path + ".y"), plugin.getConfig().getDouble(path + ".z"),
            (float)plugin.getConfig().getDouble(path + ".yaw", 0), (float)plugin.getConfig().getDouble(path + ".pitch", 0));
        return lobbyWorld.getSpawnLocation().add(0.5, 0, 0.5);
    }
    private boolean inLobby(org.bukkit.entity.Entity entity) { return lobbyWorld != null && entity.getWorld().equals(lobbyWorld); }
    @EventHandler public void onBreak(BlockBreakEvent event) { if (inLobby(event.getPlayer())) { event.setCancelled(true); event.getPlayer().sendMessage("§cLobide blok kıramazsın."); } }
    @EventHandler public void onPlace(BlockPlaceEvent event) { if (inLobby(event.getPlayer())) { event.setCancelled(true); event.getPlayer().sendMessage("§cLobide blok koyamazsın."); } }
    @EventHandler public void onDamage(EntityDamageEvent event) { if (inLobby(event.getEntity())) event.setCancelled(true); }
    @EventHandler public void onPlayerDamage(EntityDamageByEntityEvent event) { if (inLobby(event.getEntity()) || inLobby(event.getDamager())) event.setCancelled(true); }
    @EventHandler public void onPlayerDrop(PlayerDropItemEvent event) { if (inLobby(event.getPlayer())) event.setCancelled(true); }
    @EventHandler public void onEntityDrop(EntityDropItemEvent event) { if (inLobby(event.getEntity())) event.setCancelled(true); }
    @EventHandler public void onJoin(PlayerJoinEvent event) {
        if (lobbyWorld == null || !plugin.getConfig().getBoolean("lobby.teleport-on-join", true)) return;
        new BukkitRunnable() { public void run() { if (event.getPlayer().isOnline()) { Location loc = spawn(); if (loc != null) event.getPlayer().teleport(loc); } } }.runTask(plugin);
    }
}
