package xyz.doblosmp.glue;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.clan.ClanService;
import xyz.doblosmp.economy.Ledger;
import xyz.doblosmp.quest.QuestEngine;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

/** YAML kalıcılık: economy.yml, clans.yml, quests.yml. Yazma önce geçici dosyaya, sonra atomik taşıma. */
public final class Store {
    private final JavaPlugin plugin;
    public Store(JavaPlugin plugin) { this.plugin = plugin; }

    private void write(YamlConfiguration y, String name) {
        File f = new File(plugin.getDataFolder(), name), tmp = new File(plugin.getDataFolder(), name + ".tmp");
        try {
            plugin.getDataFolder().mkdirs();
            y.save(tmp);
            java.nio.file.Files.move(tmp.toPath(), f.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) { plugin.getLogger().severe(name + " kaydedilemedi: " + e.getMessage()); }
    }
    private YamlConfiguration read(String name) { return YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), name)); }

    public void saveLedger(Ledger l) {
        YamlConfiguration y = new YamlConfiguration();
        l.snapshot().forEach((mode, m) -> m.forEach((u, v) -> y.set(mode + "." + u, v)));
        write(y, "economy.yml");
    }
    public void loadLedger(Ledger l) {
        YamlConfiguration y = read("economy.yml"); Map<String, Map<UUID, Long>> data = new HashMap<>();
        for (String mode : y.getKeys(false)) {
            ConfigurationSection s = y.getConfigurationSection(mode); if (s == null) continue;
            Map<UUID, Long> m = new HashMap<>();
            for (String id : s.getKeys(false)) { try { m.put(UUID.fromString(id), s.getLong(id)); } catch (IllegalArgumentException ignored) {} }
            data.put(mode, m);
        }
        l.restore(data);
    }

    public void saveMarket(xyz.doblosmp.economy.AuctionHouse ah) {
        YamlConfiguration y = new YamlConfiguration();
        for (var l : ah.active()) {
            String b = l.id() + ".";
            y.set(b + "seller", l.seller().toString()); y.set(b + "item", l.item()); y.set(b + "amount", l.amount());
            y.set(b + "price", l.price()); y.set(b + "auction", l.auction()); y.set(b + "ends", l.endsAt());
            y.set(b + "bidder", l.topBidder() == null ? null : l.topBidder().toString()); y.set(b + "bid", l.topBid());
        }
        write(y, "market.yml");
    }
    public void loadMarket(xyz.doblosmp.economy.AuctionHouse ah) {
        YamlConfiguration y = read("market.yml");
        for (String id : y.getKeys(false)) {
            try {
                String b = id + "."; String bidder = y.getString(b + "bidder");
                ah.restore(new xyz.doblosmp.economy.AuctionHouse.Listing(Long.parseLong(id), UUID.fromString(y.getString(b + "seller", "")),
                        y.getString(b + "item", "DIRT"), y.getInt(b + "amount"), y.getLong(b + "price"), y.getBoolean(b + "auction"),
                        y.getLong(b + "ends"), bidder == null ? null : UUID.fromString(bidder), y.getLong(b + "bid")));
            } catch (RuntimeException e) { plugin.getLogger().warning("Bozuk market kaydı atlandı: " + id); }
        }
    }

    public void saveClans(ClanService c) {
        YamlConfiguration y = new YamlConfiguration();
        for (ClanService.Clan k : c.all()) {
            String b = k.tag + ".";
            y.set(b + "name", k.name); y.set(b + "leader", k.leader.toString()); y.set(b + "points", k.points);
            y.set(b + "wins", k.wins); y.set(b + "losses", k.losses);
            y.set(b + "members", k.members.stream().map(UUID::toString).toList());
        }
        write(y, "clans.yml");
    }
    public void loadClans(ClanService c) {
        YamlConfiguration y = read("clans.yml");
        for (String tag : y.getKeys(false)) {
            try {
                List<UUID> mem = y.getStringList(tag + ".members").stream().map(UUID::fromString).toList();
                c.load(tag, y.getString(tag + ".name", tag), UUID.fromString(y.getString(tag + ".leader", "")), mem,
                        y.getLong(tag + ".points"), y.getInt(tag + ".wins"), y.getInt(tag + ".losses"));
            } catch (IllegalArgumentException e) { plugin.getLogger().warning("Bozuk klan kaydı atlandı: " + tag); }
        }
    }

    public void saveQuests(QuestEngine q) {
        YamlConfiguration y = new YamlConfiguration();
        q.all().forEach((u, d) -> {
            String b = u + ".";
            d.progress.forEach((k, v) -> y.set(b + "progress." + k, v));
            d.periodKey.forEach((k, v) -> y.set(b + "period." + k, v));
            y.set(b + "claimed", new ArrayList<>(d.claimed)); y.set(b + "ach", new ArrayList<>(d.achievements));
            y.set(b + "cos", new ArrayList<>(d.cosmetics)); y.set(b + "pass", new ArrayList<>(d.passClaimed));
            y.set(b + "passxp", d.passXp); y.set(b + "streak", d.streak); y.set(b + "last", d.lastLogin == null ? null : d.lastLogin.toString());
        });
        write(y, "quests.yml");
    }
    public void loadQuests(QuestEngine q) {
        YamlConfiguration y = read("quests.yml");
        for (String id : y.getKeys(false)) {
            try {
                QuestEngine.PlayerData d = q.of(UUID.fromString(id)); String b = id + ".";
                ConfigurationSection pr = y.getConfigurationSection(b + "progress"), pk = y.getConfigurationSection(b + "period");
                if (pr != null) for (String k : pr.getKeys(false)) d.progress.put(k, pr.getInt(k));
                if (pk != null) for (String k : pk.getKeys(false)) d.periodKey.put(k, pk.getString(k, ""));
                d.claimed.addAll(y.getStringList(b + "claimed")); d.achievements.addAll(y.getStringList(b + "ach"));
                d.cosmetics.addAll(y.getStringList(b + "cos")); d.passClaimed.addAll(y.getIntegerList(b + "pass"));
                d.passXp = y.getLong(b + "passxp"); d.streak = y.getInt(b + "streak");
                String last = y.getString(b + "last"); if (last != null) d.lastLogin = LocalDate.parse(last);
            } catch (RuntimeException e) { plugin.getLogger().warning("Bozuk görev kaydı atlandı: " + id); }
        }
    }

    public void saveFriends(xyz.doblosmp.social.FriendService f) {
        YamlConfiguration y = new YamlConfiguration();
        f.snapshot().forEach((k, v) -> y.set(k.toString(), v.stream().map(UUID::toString).toList()));
        write(y, "friends.yml");
    }
    public void loadFriends(xyz.doblosmp.social.FriendService f) {
        YamlConfiguration y = read("friends.yml"); Map<UUID, Set<UUID>> d = new HashMap<>();
        for (String k : y.getKeys(false)) { try { Set<UUID> s = new HashSet<>(); for (String x : y.getStringList(k)) s.add(UUID.fromString(x)); d.put(UUID.fromString(k), s); } catch (IllegalArgumentException ignored) {} }
        f.restore(d);
    }
    public void saveIslands(xyz.doblosmp.sb.IslandRegistry reg) {
        YamlConfiguration y = new YamlConfiguration();
        for (var i : reg.snapshot()) {
            String b = i.id + ".";
            y.set(b + "owner", i.owner.toString()); y.set(b + "slot", i.slot); y.set(b + "template", i.template);
            y.set(b + "resets", i.resets);
            y.set(b + "home", List.of(i.homeX, i.homeY, i.homeZ));
            i.members.forEach((u, r) -> y.set(b + "members." + u, r.name())); y.set(b + "bans", i.bans.stream().map(UUID::toString).toList());
            i.ratings.forEach((u, sc) -> y.set(b + "ratings." + u, sc)); i.flags.forEach((k, v) -> y.set(b + "flags." + k, v)); i.required.forEach((k, v) -> y.set(b + "req." + k.name(), v.name()));
        }
        write(y, "islands-v2.yml");
    }
    public void loadIslands(xyz.doblosmp.sb.IslandRegistry reg) {
        YamlConfiguration y = read("islands-v2.yml");
        for (String id : y.getKeys(false)) {
            try {
                String b = id + "."; var i = reg.restore(Long.parseLong(id), UUID.fromString(y.getString(b + "owner", "")), y.getInt(b + "slot"), y.getString(b + "template", "classic"));
                i.resets = y.getInt(b + "resets");
                var home = y.getDoubleList(b + "home"); if (home.size() == 3) { i.homeX = home.get(0); i.homeY = home.get(1); i.homeZ = home.get(2); }
                var ms = y.getConfigurationSection(b + "members"); if (ms != null) for (String u : ms.getKeys(false)) reg.restoreMember(i, UUID.fromString(u), xyz.doblosmp.sb.Role.valueOf(ms.getString(u, "MEMBER")));
                for (String u : y.getStringList(b + "bans")) i.bans.add(UUID.fromString(u));
                var rt = y.getConfigurationSection(b + "ratings"); if (rt != null) for (String u : rt.getKeys(false)) i.ratings.put(UUID.fromString(u), rt.getInt(u));
                var fl = y.getConfigurationSection(b + "flags"); if (fl != null) for (String k : fl.getKeys(false)) i.flags.put(k, fl.getBoolean(k));
                var rq = y.getConfigurationSection(b + "req"); if (rq != null) for (String k : rq.getKeys(false)) i.required.put(xyz.doblosmp.sb.Perm.valueOf(k), xyz.doblosmp.sb.Role.valueOf(rq.getString(k, "MEMBER")));
            } catch (RuntimeException e) { plugin.getLogger().warning("Bozuk ada kaydı atlandı: " + id); }
        }
    }
}
