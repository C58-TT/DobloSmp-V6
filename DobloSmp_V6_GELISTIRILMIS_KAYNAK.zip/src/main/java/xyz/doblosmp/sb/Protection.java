package xyz.doblosmp.sb;

import java.util.UUID;

/** Saf koruma kararı: Paper olayları bu fonksiyona soru sorar. */
public final class Protection {
    private Protection() {}
    public enum Action { BREAK, PLACE, CONTAINER, DOOR, ANIMAL, FARM, PVP }

    public static boolean allowed(Island i, UUID p, Action a, boolean bypass) {
        if (bypass) return true;
        if (i == null) return true;                              // ada dışı: bu sistemin işi değil
        if (i.bans.contains(p)) return false;
        Role r = i.roleOf(p);
        return switch (a) {
            case BREAK -> r.atLeast(i.need(Perm.BREAK));
            case PLACE -> r.atLeast(i.need(Perm.PLACE));
            case CONTAINER -> r.atLeast(i.need(Perm.CONTAINERS));
            case ANIMAL -> r.atLeast(i.need(Perm.ANIMALS));
            case FARM -> r.atLeast(i.need(Perm.FARM));
            case DOOR -> r.atLeast(i.need(Perm.DOORS)) || (r == Role.VISITOR && i.flags.getOrDefault("visitor_doors", false));
            case PVP -> i.flags.getOrDefault("pvp", false);       // ada içi PvP yalnızca ayar açıksa
        };
    }
}
