package xyz.doblosmp.bedwars;

public enum BedwarsMode {
    SOLO(8, 1);
    public final int teams, perTeam;
    BedwarsMode(int teams, int perTeam) { this.teams = teams; this.perTeam = perTeam; }
    public int capacity() { return teams * perTeam; }
}
