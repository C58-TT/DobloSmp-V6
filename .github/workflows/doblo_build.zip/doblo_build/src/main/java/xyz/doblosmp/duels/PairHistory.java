package xyz.doblosmp.duels;

import java.util.*;

/** Aynı iki oyuncunun yakın zamanda yaptığı sıralı maçları sayar (Elo kasılmasını önlemek için). */
public final class PairHistory {
    private final Map<String, Deque<Long>> times = new HashMap<>();
    private static String key(UUID a, UUID b) { String x = a.toString(), y = b.toString(); return x.compareTo(y) < 0 ? x + "|" + y : y + "|" + x; }

    /** Pencere içindeki maç sayısı (eskiler temizlenir). */
    public synchronized int recent(UUID a, UUID b, long now, long windowMs) {
        Deque<Long> d = times.get(key(a, b)); if (d == null) return 0;
        while (!d.isEmpty() && now - d.peekFirst() > windowMs) d.pollFirst();
        if (d.isEmpty()) { times.remove(key(a, b)); return 0; }
        return d.size();
    }
    public synchronized void record(UUID a, UUID b, long now) { times.computeIfAbsent(key(a, b), k -> new ArrayDeque<>()).addLast(now); }
    /** Bellek sızıntısı olmasın: pencere dışındaki tüm kayıtları sil. */
    public synchronized void purge(long now, long windowMs) {
        times.values().removeIf(d -> { while (!d.isEmpty() && now - d.peekFirst() > windowMs) d.pollFirst(); return d.isEmpty(); });
    }
    public synchronized int size() { return times.size(); }
}
