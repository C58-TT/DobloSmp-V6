package xyz.doblosmp.game;

import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.entity.EntityShootBowEvent;
import java.io.File;
import java.io.IOException;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.gui.Menu;
import xyz.doblosmp.murder.MurderGame;

import java.util.*;

/** Murder Mystery Paper bağlayıcısı. Roller yalnızca sahibine bildirilir; oyun sonunda katil açıklanır. Paper'da test EDİLMEDİ. */
public final class MurderManager implements CommandExecutor, Listener {
    private final class Game {
        final ArenaStore.Arena arena; final Set<UUID> players = new LinkedHashSet<>(); MurderGame logic; final Map<UUID, Integer> gold = new HashMap<>(); final List<Item> loot = new ArrayList<>();
        BukkitTask task; int countdown = -1, elapsed, revealRemaining; boolean running, revealing, ended; Item droppedBow; Location lastKill; final double[] box; final Map<UUID, Long> lastShot = new HashMap<>();
        Game(ArenaStore.Arena a) { arena = a; box = GameUtil.bounds(a, 100); }
    }
    private static final class RoleChance { double sheriff, murderer; int innocentSinceSheriff, innocentSinceMurderer; long sheriffGames, murdererGames, innocentGames; RoleChance(double s, double m) { sheriff = s; murderer = m; } }
    private final JavaPlugin plugin; private final ArenaStore store; private final PlayerState state; private final Map<String, Game> games = new HashMap<>(); private final Map<UUID, Game> byPlayer = new HashMap<>(); private final Random rnd = new Random();
    private final Map<UUID, RoleChance> roleChances = new HashMap<>(); private final File roleChanceFile;


    public MurderManager(JavaPlugin plugin, ArenaStore store, PlayerState state) {
        this.plugin = plugin; this.store = store; this.state = state;
        this.roleChanceFile = new File(plugin.getDataFolder(), "murder-role-chances.yml");
        loadRoleChances();
    }
    private double baseSheriff() { return plugin.getConfig().getDouble("murder.sheriff-base-chance", 5.0); }
    private double baseMurderer() { return plugin.getConfig().getDouble("murder.murderer-base-chance", 2.0); }
    private double maxChance() { return Math.max(1.0, plugin.getConfig().getDouble("murder.max-role-chance", 100.0)); }
    private RoleChance chance(UUID id) { return roleChances.computeIfAbsent(id, k -> new RoleChance(baseSheriff(), baseMurderer())); }
    private void loadRoleChances() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(roleChanceFile);
        for (String key : y.getKeys(false)) try { UUID id = UUID.fromString(key); RoleChance c = new RoleChance(Math.min(maxChance(), Math.max(baseSheriff(), y.getDouble(key + ".sheriff", baseSheriff()))), Math.min(maxChance(), Math.max(baseMurderer(), y.getDouble(key + ".murderer", baseMurderer())))); c.innocentSinceSheriff = y.getInt(key + ".innocentSinceSheriff"); c.innocentSinceMurderer = y.getInt(key + ".innocentSinceMurderer"); c.sheriffGames = y.getLong(key + ".sheriffGames"); c.murdererGames = y.getLong(key + ".murdererGames"); c.innocentGames = y.getLong(key + ".innocentGames"); roleChances.put(id, c); } catch (IllegalArgumentException ignored) { }
    }
    private void saveRoleChances() {
        YamlConfiguration y = new YamlConfiguration();
        roleChances.forEach((id, v) -> { y.set(id + ".sheriff", v.sheriff); y.set(id + ".murderer", v.murderer); y.set(id + ".innocentSinceSheriff", v.innocentSinceSheriff); y.set(id + ".innocentSinceMurderer", v.innocentSinceMurderer); y.set(id + ".sheriffGames", v.sheriffGames); y.set(id + ".murdererGames", v.murdererGames); y.set(id + ".innocentGames", v.innocentGames); });
        try { plugin.getDataFolder().mkdirs(); y.save(roleChanceFile); } catch (IOException e) { plugin.getLogger().severe("Murder rol şansları kaydedilemedi: " + e.getMessage()); }
    }
    private void updateRoleChances(MurderGame logic, Collection<UUID> players) {
        for (UUID id : players) {
            RoleChance c = chance(id); MurderGame.Role role = logic.role(id);
            if (role == MurderGame.Role.DETECTIVE) { c.sheriff = baseSheriff(); c.sheriffGames++; c.innocentSinceSheriff = 0; }
            else if (role == MurderGame.Role.MURDERER) { c.murderer = baseMurderer(); c.murdererGames++; c.innocentSinceMurderer = 0; }
            else { c.innocentGames++; c.innocentSinceSheriff++; c.innocentSinceMurderer++; c.sheriff = Math.min(maxChance(), c.sheriff + plugin.getConfig().getDouble("murder.sheriff-increase-per-innocent", 3.0)); c.murderer = Math.min(maxChance(), c.murderer + plugin.getConfig().getDouble("murder.murderer-increase-per-innocent", 2.0)); }
        }
        saveRoleChances();
    }
    private int cfg(String k, int d) { return plugin.getConfig().getInt("murder." + k, d); }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Oyuncu komutu."); return true; }
        if (c.getName().equalsIgnoreCase("ayril")) { Game active = byPlayer.get(p.getUniqueId()); if (active == null) p.sendMessage("§cMurder Mystery oyununda değilsin."); else leave(p, active); return true; }
        if (a.length == 0) { p.sendMessage("§e/mm join [arena] | leave"); return true; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "join" -> join(p, a.length > 1 ? a[1] : null);
            case "leave", "ayril", "ayrıl" -> { Game g = byPlayer.get(p.getUniqueId()); if (g == null) p.sendMessage("§cOyunda değilsin."); else leave(p, g); }
            case "start" -> { if (!p.hasPermission("doblo.admin")) return true; Game g = byPlayer.get(p.getUniqueId()); if (g != null && !g.running) g.countdown = 3; }
            case "arena" -> { if (!p.hasPermission("doblo.admin")) { p.sendMessage("§cYetkin yok."); return true; } admin(p, a); }
            default -> p.sendMessage("§c/mm join");
        }
        return true;
    }

    private void admin(Player p, String[] a) {
        if (a.length < 2) { p.sendMessage("§e/mm arena create <ad> | setlobby <ad> | addspawn <ad> | addgold <ad> | addxp <ad> | setspectator <ad> | enable | disable | delete | list | check"); return; }
        String op = a[1].toLowerCase(Locale.ROOT); if (op.equals("list")) { store.all().stream().filter(x -> x.type.equals("MURDER")).forEach(x -> p.sendMessage("§7" + x.name + (x.enabled ? " §aaçık" : " §cdevre dışı"))); return; }
        if (a.length < 3) { p.sendMessage("§cArena adı gerekli."); return; } if (op.equals("create")) { var ar = store.create(a[2], "MURDER"); if (ar != null) { ar.minPlayers = cfg("min-players", 5); ar.maxPlayers = cfg("max-players", 12); store.save(); } p.sendMessage(ar != null ? "§aOluşturuldu." : "§cOluşturulamadı."); return; }
        var ar = store.get(a[2]); if (ar == null || !ar.type.equals("MURDER")) { p.sendMessage("§cArena yok."); return; } if (games.containsKey(ar.name)) { p.sendMessage("§cArena oyunda."); return; } Location here = p.getLocation().clone();
        switch (op) {
            case "setlobby" -> ar.lobby = here; case "addspawn" -> ar.add("spawn", here); case "addgold" -> ar.add("gold", here); case "addxp" -> ar.add("xp", here); case "setspectator" -> ar.points.put("spectator", new ArrayList<>(List.of(here)));
            case "enable" -> { if (ar.lobby == null || ar.pts("spawn").size() < Math.max(5, ar.maxPlayers) || ar.pts("gold").size() < 3 || ar.pts("xp").size() < 3 || ar.first("spectator") == null) { p.sendMessage("§cEksik: lobi, en az " + Math.max(5, ar.maxPlayers) + " doğma noktası, 3 altın ve 3 XP noktası, seyirci noktası."); return; } ar.enabled = true; }
            case "disable" -> ar.enabled = false; case "delete" -> store.delete(ar.name); case "check" -> p.sendMessage("§7doğma=" + ar.pts("spawn").size() + " altın=" + ar.pts("gold").size() + " XP=" + ar.pts("xp").size() + " lobi=" + (ar.lobby != null));
            default -> { p.sendMessage("§cBilinmeyen alt komut."); return; }
        }
        p.sendMessage("§aTamam."); store.save();
    }

    private void join(Player p, String name) {
        UUID id = p.getUniqueId(); if (Activities.busy(id)) { p.sendMessage("§cZaten bir etkinlikte/oyundasın."); return; }
        if (Ctx.parties.of(id) != null && !Ctx.parties.of(id).leader.equals(id)) { p.sendMessage("§cPartideyken yalnızca lider katılabilir."); return; }
        List<UUID> group = Ctx.parties.members(id); Game g = null;
        for (Game x : games.values()) if (!x.running && !x.ended && (name == null || x.arena.name.equals(name.toLowerCase(Locale.ROOT))) && x.players.size() + group.size() <= x.arena.maxPlayers) { g = x; break; }
        if (g == null) for (var ar : store.all()) if (ar.type.equals("MURDER") && ar.enabled && !games.containsKey(ar.name) && (name == null || ar.name.equals(name.toLowerCase(Locale.ROOT)))) { g = new Game(ar); games.put(ar.name, g); final Game fg = g; g.task = Bukkit.getScheduler().runTaskTimer(plugin, () -> tick(fg), 20L, 20L); break; }
        if (g == null) { p.sendMessage("§cUygun arena yok."); return; }
        for (UUID u : group) { Player m = Bukkit.getPlayer(u); if (m != null && !Activities.busy(u) && Activities.enter(u, Activities.Kind.MURDER)) { state.save(m); byPlayer.put(u, g); g.players.add(u); PlayerState.prepare(m, GameMode.ADVENTURE); m.teleport(g.arena.lobby); m.getInventory().setItem(8, Menu.item(Material.SLIME_BALL, "§cAyrıl")); GameUtil.msg(g.players, "§a" + m.getName() + " katıldı §7(" + g.players.size() + "/" + g.arena.maxPlayers + ")"); } }
        if (g.countdown < 0 && g.players.size() >= g.arena.minPlayers) g.countdown = cfg("countdown", 20);
    }
    private void leave(Player p, Game g) {
        UUID id = p.getUniqueId(); g.players.remove(id); byPlayer.remove(id); Activities.leave(id, Activities.Kind.MURDER); if (p.isOnline()) state.restoreIfPending(p);
        if ((g.running || g.revealing) && !g.ended) { var w = g.logic.leave(id); if (w != MurderGame.Winner.NONE) { finish(g, w); return; } }
        if (g.revealing && g.players.size() < 5) { GameUtil.msg(g.players, "§cYeterli oyuncu kalmadığı için maç iptal edildi."); close(g); return; }
        if (!g.running && g.players.size() < g.arena.minPlayers) g.countdown = -1; if (g.players.isEmpty() && !g.ended) close(g);
    }

    private void tick(Game g) {
        if (g.ended) return;
        if (!g.running && !g.revealing) { for (UUID u : g.players) { Player p = Bukkit.getPlayer(u); if (p != null) { RoleChance rc = chance(u); p.sendActionBar(Component.text("§9Şerif: §f%" + String.format(Locale.US, "%.1f", rc.sheriff) + " §8| §cKatil: §f%" + String.format(Locale.US, "%.1f", rc.murderer))); } } if (g.players.size() < Math.max(5, g.arena.minPlayers)) { g.countdown = -1; return; } if (g.countdown < 0) g.countdown = cfg("countdown", 20);
            if (g.countdown <= 5 || g.countdown % 10 == 0) GameUtil.msg(g.players, "§eOyun " + g.countdown + " sn içinde başlıyor."); if (g.countdown-- <= 0) begin(g); return; }
        if (g.revealing) {
            for (UUID u : g.players) { Player p = Bukkit.getPlayer(u); if (p != null) { p.sendActionBar(Component.text("§eRoller açıklandı • Oyun " + g.revealRemaining + " saniye içinde başlayacak")); if (g.revealRemaining <= 3) GameUtil.title(p, "§e" + g.revealRemaining, "§7Hazır ol!"); } }
            if (g.revealRemaining-- <= 0) { g.revealing = false; g.running = true; for (UUID u : g.players) if (g.logic.role(u) == MurderGame.Role.MURDERER) { Player m = Bukkit.getPlayer(u); if (m != null) m.getInventory().setItem(1, new ItemStack(Material.IRON_SWORD)); } GameUtil.msg(g.players, "§aOyun başladı! Rolleri gizli tut."); }
            return;
        }
        g.elapsed++; var w = g.logic.tick(); if (w != MurderGame.Winner.NONE) { finish(g, w); return; }
        int left = Math.max(0, cfg("duration-seconds", 300) - g.elapsed); for (UUID u : g.players) { Player p = Bukkit.getPlayer(u); if (p != null) p.sendActionBar(Component.text("§7Kalan: §f" + left / 60 + ":" + String.format("%02d", left % 60) + " §8| §6Altın: §f" + g.gold.getOrDefault(u, 0))); }
        if (g.elapsed % 6 == 0) for (Location l : g.arena.pts("gold")) { int near = 0; for (Entity e : l.getWorld().getNearbyEntities(l, 2, 2, 2)) if (e instanceof Item) near++; if (near < 3) { Item it = l.getWorld().dropItem(l.clone().add(0, 0.3, 0), new ItemStack(Material.GOLD_INGOT)); g.loot.add(it); } }
        int xpInterval = Math.max(1, cfg("xp-spawn-interval-seconds", 6));
        if (g.elapsed % xpInterval == 0) for (Location l : g.arena.pts("xp")) { int near = 0; for (Entity e : l.getWorld().getNearbyEntities(l, 2, 2, 2)) if (e instanceof Item it && it.getItemStack().getType() == Material.EXPERIENCE_BOTTLE) near++; if (near < Math.max(1, cfg("xp-spawn-limit", 3))) { Item it = l.getWorld().dropItem(l.clone().add(0, 0.3, 0), new ItemStack(Material.EXPERIENCE_BOTTLE)); g.loot.add(it); } }
        // ok yenileme: yaylı dedektif 5 sn'de bir ok alır
        if (g.elapsed % 5 == 0 && g.logic.bowHolder() != null) { Player h = Bukkit.getPlayer(g.logic.bowHolder()); if (h != null && g.logic.isAlive(h.getUniqueId()) && GameUtil.count(h, Material.ARROW) < 1) h.getInventory().setItem(9, new ItemStack(Material.ARROW)); }
    }

    private void begin(Game g) {
        List<UUID> ps = new ArrayList<>(); for (UUID u : g.players) if (Bukkit.getPlayer(u) != null) ps.add(u);
        if (ps.size() < 5 || g.arena.pts("spawn").size() < ps.size()) { GameUtil.msg(g.players, "§cMaç başlatılamadı: en az 5 oyuncu ve her oyuncu için spawn noktası gerekli."); g.countdown = -1; return; }
        g.logic = new MurderGame(ps, u -> chance(u).sheriff, u -> chance(u).murderer, rnd, cfg("duration-seconds", 300) * 1000L);
        updateRoleChances(g.logic, ps); g.revealing = true; g.revealRemaining = cfg("role-reveal-seconds", 10);
        List<Location> sp = new ArrayList<>(g.arena.pts("spawn")); Collections.shuffle(sp, rnd); int i = 0;
        for (UUID u : ps) { Player p = Bukkit.getPlayer(u); PlayerState.prepare(p, GameMode.ADVENTURE); p.teleport(sp.get(i++)); var role = g.logic.role(u);
            switch (role) { case MURDERER -> { GameUtil.title(p, "§c§lKATİL", "§7Gizli rolün"); p.sendMessage("§cRolün: KATİL. 10 saniye sonra başlayacak."); }
                case DETECTIVE -> { GameUtil.title(p, "§9§lŞERİF", "§7Katili bul ve yayınla vur!"); p.getInventory().setItem(1, new ItemStack(Material.BOW)); p.getInventory().setItem(9, new ItemStack(Material.ARROW)); p.sendMessage("§9Rolün: ŞERİF. Yanlışlıkla masum vurursan sen de elenirsin!"); }
                default -> { GameUtil.title(p, "§a§lMASUM", "§7Hayatta kal, altın topla"); p.sendMessage("§aRolün: MASUM. Altın toplayarak yay kazanabilirsin."); } }
            Ctx.stat(u, "murder", "games", 1); }
        GameUtil.msg(g.players, "§eRoller açıklandı. Oyun 10 saniye sonra başlayacak.");
    }

    /** Öldürme sonucu: görünüm, ipucu, yay düşürme, kazanan kontrolü. */
    private void kill(Game g, UUID killer, UUID victim, String how) {
        if (!g.running || g.ended || !g.logic.isAlive(victim)) return; boolean hadBow = victim.equals(g.logic.bowHolder()); boolean killerAlive = killer != null && g.logic.isAlive(killer);
        MurderGame.Winner w = g.logic.kill(killer, victim); Player pv = Bukkit.getPlayer(victim);
        if (pv != null) { g.lastKill = pv.getLocation(); if (hadBow) { Item it = pv.getWorld().dropItem(pv.getLocation(), new ItemStack(Material.ARROW)); g.droppedBow = it; GameUtil.msg(g.players, "§9Şerif elendi! Yalnızca oku düştü; bir masum oku alabilir."); }
            pv.getInventory().clear(); pv.setGameMode(GameMode.SPECTATOR); GameUtil.title(pv, "§cÖLDÜN", "§7" + how); }
        if (killer != null && killerAlive && !g.logic.isAlive(killer)) { Player pk = Bukkit.getPlayer(killer); if (pk != null) { pk.getInventory().clear(); pk.setGameMode(GameMode.SPECTATOR); pk.sendMessage("§cMasum birini vurdun, cezanı çektin!"); if (killer.equals(g.logic.bowHolder()) || hadBow) { } } }
        if (g.lastKill != null) for (UUID u : g.logic.alive()) { Player n = Bukkit.getPlayer(u); if (n != null && n.getWorld() == g.lastKill.getWorld() && n.getLocation().distanceSquared(g.lastKill) < 100) n.sendMessage("§7[İpucu] Yakınlarda biri öldürüldü."); }
        GameUtil.msg(g.players, "§7Hayatta kalan: §f" + g.logic.alive().size());
        if (killer != null) Ctx.stat(killer, "murder", "kills", 1);
        if (w != MurderGame.Winner.NONE) finish(g, w);
    }

    private void finish(Game g, MurderGame.Winner w) {
        if (g.ended) return; g.ended = true; String mode = Ctx.mode("murder"); UUID murderer = null; for (UUID u : g.players) if (g.logic.role(u) == MurderGame.Role.MURDERER) murderer = u;
        String mn = murderer == null ? "?" : Bukkit.getOfflinePlayer(murderer).getName(); GameUtil.msg(g.players, "§e§l=== Oyun bitti ===\n§7Katil: §c" + mn + "\n§7Kazanan: §f" + (w == MurderGame.Winner.MURDERER ? "KATİL" : "MASUMLAR"));
        for (UUID u : new ArrayList<>(g.players)) { var role = g.logic.role(u); if (role == null) continue; boolean won = (w == MurderGame.Winner.MURDERER) == (role == MurderGame.Role.MURDERER); long reward = won ? plugin.getConfig().getLong("murder.reward-win", 100) : plugin.getConfig().getLong("murder.reward-play", 20);
            Ctx.ledger.deposit(mode, u, reward, "murder"); Ctx.quest(u, "match_played", 1); if (won) { Ctx.quest(u, "murder_win", 1); Ctx.quest(u, "match_won", 1); Ctx.stat(u, "murder", "wins", 1); } Player p = Bukkit.getPlayer(u); if (p != null) { Ctx.xp.accept(p, won ? 80 : 20); GameUtil.title(p, won ? "§6ZAFER" : "§cMAĞLUP", "§a+" + reward + " para"); } }
        Bukkit.getScheduler().runTaskLater(plugin, () -> close(g), 20L * 8);
    }
    private void close(Game g) {
        g.ended = true; if (g.task != null) g.task.cancel(); for (Item it : g.loot) it.remove(); if (g.droppedBow != null) g.droppedBow.remove();
        if (g.arena.lobby != null && g.box != null) for (Entity e : g.arena.lobby.getWorld().getEntities()) if ((e instanceof Item || e instanceof Arrow) && GameUtil.inside(e.getLocation(), g.box)) e.remove();
        for (UUID u : new ArrayList<>(g.players)) { Player p = Bukkit.getPlayer(u); byPlayer.remove(u); Activities.leave(u, Activities.Kind.MURDER); if (p != null) state.restoreIfPending(p); } g.players.clear(); games.remove(g.arena.name);
    }

    // ---------- olaylar ----------
    private Game of(Player p) { return byPlayer.get(p.getUniqueId()); }
    @EventHandler(priority = EventPriority.HIGH) public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player v)) return; Game g = of(v); if (g == null) return; e.setCancelled(true);
        if (!g.running || g.ended || !g.logic.isAlive(v.getUniqueId()) || !(e instanceof EntityDamageByEntityEvent by)) { if (e.getCause() == EntityDamageEvent.DamageCause.VOID && g.running) { Location sp = g.arena.first("spectator"); v.teleport(sp != null ? sp : g.arena.lobby); } return; }
        if (by.getDamager() instanceof Arrow arrow && arrow.getShooter() instanceof Player shooter && of(shooter) == g && g.logic.isAlive(shooter.getUniqueId())) { arrow.remove(); kill(g, shooter.getUniqueId(), v.getUniqueId(), "ok"); }
        else if (by.getDamager() instanceof Player d && of(d) == g && g.logic.role(d.getUniqueId()) == MurderGame.Role.MURDERER && g.logic.isAlive(d.getUniqueId()) && d.getInventory().getItemInMainHand().getType() == Material.IRON_SWORD) kill(g, d.getUniqueId(), v.getUniqueId(), "kılıç");
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true) public void onBowShoot(EntityShootBowEvent e) {
        if (!(e.getEntity() instanceof Player p)) return; Game g = of(p); if (g == null || !g.running || g.logic == null || !p.getUniqueId().equals(g.logic.bowHolder())) return;
        long now = System.currentTimeMillis(), last = g.lastShot.getOrDefault(p.getUniqueId(), 0L);
        if (now - last < cfg("arrow-cooldown-seconds", 5) * 1000L) { e.setCancelled(true); p.sendMessage("§cYay için beklemelisin: §f" + Math.max(1, cfg("arrow-cooldown-seconds", 5) - (now-last)/1000) + " sn"); }
        else g.lastShot.put(p.getUniqueId(), now);
    }
    @EventHandler public void onMove(PlayerMoveEvent e) {
        Game g = of(e.getPlayer()); if (g == null || !g.revealing || e.getTo() == null) return;
        if (e.getFrom().getBlockX() != e.getTo().getBlockX() || e.getFrom().getBlockY() != e.getTo().getBlockY() || e.getFrom().getBlockZ() != e.getTo().getBlockZ()) e.setTo(e.getFrom());
    }
    @EventHandler public void onDeath(PlayerDeathEvent e) { if (of(e.getEntity()) != null) { e.getDrops().clear(); e.deathMessage(null); } }
    @EventHandler(priority = EventPriority.HIGH) public void onPickup(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p)) return; Game g = of(p); if (g == null) return; e.setCancelled(true); if (!g.running || g.ended || !g.logic.isAlive(p.getUniqueId())) return;
        Item it = e.getItem(); Material m = it.getItemStack().getType(); UUID id = p.getUniqueId();
        if (m == Material.EXPERIENCE_BOTTLE) { it.remove(); g.loot.remove(it); p.giveExp(Math.max(1, cfg("xp-pickup-exp", 1))); Ctx.stat(id, "murder", "xp_pickups", 1); return; }
        if (g.droppedBow != null && it.equals(g.droppedBow)) { if (g.logic.pickupBow(id)) { it.remove(); g.droppedBow = null; p.getInventory().setItem(1, new ItemStack(Material.BOW)); p.getInventory().setItem(9, new ItemStack(Material.ARROW)); GameUtil.msg(g.players, "§9Bir masum şerifin görevini devraldı!"); } return; }
        if (m == Material.GOLD_INGOT && g.logic.role(id) != MurderGame.Role.MURDERER || m == Material.GOLD_INGOT) { it.remove(); g.loot.remove(it); int n = g.gold.merge(id, it.getItemStack().getAmount(), Integer::sum);
            if (g.logic.role(id) == MurderGame.Role.MURDERER) return; boolean hasBow = id.equals(g.logic.bowHolder());
            if (!hasBow && n >= 10 && g.logic.bowHolder() == null) { g.gold.put(id, 0); p.getInventory().setItem(1, new ItemStack(Material.BOW)); GameUtil.give(p, new ItemStack(Material.ARROW)); p.sendMessage("§aAltınlarla bir yay kazandın!"); }
            else if (hasBow && n >= 5) { g.gold.put(id, n - 5); GameUtil.give(p, new ItemStack(Material.ARROW)); p.sendMessage("§a5 altın = 1 ok"); } }
    }
    @EventHandler(priority = EventPriority.HIGH) public void onBreak(BlockBreakEvent e) { if (of(e.getPlayer()) != null) e.setCancelled(true); }
    @EventHandler(priority = EventPriority.HIGH) public void onPlace(BlockPlaceEvent e) { if (of(e.getPlayer()) != null) e.setCancelled(true); }
    @EventHandler public void onFood(FoodLevelChangeEvent e) { if (e.getEntity() instanceof Player p && of(p) != null) e.setCancelled(true); }
    @EventHandler public void onDrop(PlayerDropItemEvent e) { if (of(e.getPlayer()) != null) e.setCancelled(true); }
    @EventHandler public void onInteract(PlayerInteractEvent e) { Game g = of(e.getPlayer()); if (g == null) return; if (e.getItem() != null && e.getItem().getType() == Material.SLIME_BALL) { e.setCancelled(true); leave(e.getPlayer(), g); } else if (e.getClickedBlock() != null) e.setCancelled(true); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { Game g = of(e.getPlayer()); if (g != null) leave(e.getPlayer(), g); }
    @EventHandler public void onChat(AsyncPlayerChatEvent e) {
        Game g = of(e.getPlayer()); if (g == null || !g.running || g.ended || g.logic.isAlive(e.getPlayer().getUniqueId())) return;
        e.setCancelled(true); for (UUID u : g.players) if (!g.logic.isAlive(u)) { Player p = Bukkit.getPlayer(u); if (p != null) p.sendMessage("§7[Ölü] " + e.getPlayer().getName() + ": " + e.getMessage()); }       // ölüler yalnızca ölülerle konuşur: rol sızıntısı yok
    }
    @EventHandler public void onCmd(PlayerCommandPreprocessEvent e) { Game g = of(e.getPlayer()); if (g == null || e.getPlayer().hasPermission("doblo.admin")) return; String c = e.getMessage().toLowerCase(Locale.ROOT).split(" ")[0]; if (!Set.of("/mm", "/msg", "/w", "/r", "/rapor").contains(c)) { e.setCancelled(true); e.getPlayer().sendMessage("§cOyundayken bu komut kullanılamaz. /mm leave"); } }

    public void shutdown() { for (Game g : new ArrayList<>(games.values())) close(g); }
}
