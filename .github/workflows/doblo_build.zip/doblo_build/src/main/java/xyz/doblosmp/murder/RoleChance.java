package xyz.doblosmp.murder;

import java.util.*;

/**
 * Murder Mystery rol şansı. Şerif ve Katil şansları BİRBİRİNDEN BAĞIMSIZ ağırlıklardır (toplamları %100 olmak zorunda değil).
 * Masum kalınan her maçta iki şans da artar; rol alınınca yalnızca o rolün şansı başlangıca döner. Tavan config'ten gelir.
 * Değerler yüzde x100 tamsayı olarak saklanır (örn. %15,50 = 1550) -> DB'de stats tablosuna yazılır.
 */
public final class RoleChance {
    public record Cfg(int baseSheriff, int baseMurderer, int stepSheriff, int stepMurderer, int maxSheriff, int maxMurderer) {
        public static Cfg defaults() { return new Cfg(1500, 500, 500, 300, 6000, 3000); }
    }
    public record Chances(int sheriff, int murderer) {}
    public record Assign(UUID murderer, UUID sheriff) {}

    private final Cfg cfg;
    private final Map<UUID, Chances> chances = new HashMap<>();
    public RoleChance(Cfg cfg) { this.cfg = cfg; }

    public Chances of(UUID p) { return chances.getOrDefault(p, new Chances(cfg.baseSheriff(), cfg.baseMurderer())); }
    public void load(UUID p, int sheriff, int murderer) {
        chances.put(p, new Chances(clamp(sheriff, cfg.baseSheriff(), cfg.maxSheriff()), clamp(murderer, cfg.baseMurderer(), cfg.maxMurderer())));
    }
    public void forget(UUID p) { chances.remove(p); }
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    /** Ağırlıklı rastgele seçim. Önce katil, sonra (katil hariç) şerif seçilir. */
    public Assign pick(Collection<UUID> players, Random rng) {
        if (players.size() < 2) throw new IllegalArgumentException("En az 2 oyuncu gerekir");
        List<UUID> l = new ArrayList<>(players);
        UUID m = weighted(l, u -> of(u).murderer(), rng);
        List<UUID> rest = new ArrayList<>(l); rest.remove(m);
        UUID s = rest.isEmpty() ? null : weighted(rest, u -> of(u).sheriff(), rng);
        return new Assign(m, s);
    }

    private static UUID weighted(List<UUID> l, java.util.function.ToIntFunction<UUID> w, Random rng) {
        long total = 0; for (UUID u : l) total += Math.max(1, w.applyAsInt(u));
        long r = (long) (rng.nextDouble() * total), acc = 0;
        for (UUID u : l) { acc += Math.max(1, w.applyAsInt(u)); if (r < acc) return u; }
        return l.get(l.size() - 1);
    }

    /** Maç sonrası güncelleme: rol geçmişine göre. Yeni değerleri döndürür (DB'ye yazılır). */
    public Chances record(UUID p, MurderGame.Role role) {
        Chances c = of(p);
        Chances n = switch (role) {
            case DETECTIVE -> new Chances(cfg.baseSheriff(), Math.min(cfg.maxMurderer(), c.murderer()));
            case MURDERER -> new Chances(Math.min(cfg.maxSheriff(), c.sheriff()), cfg.baseMurderer());
            case INNOCENT -> new Chances(Math.min(cfg.maxSheriff(), c.sheriff() + cfg.stepSheriff()),
                    Math.min(cfg.maxMurderer(), c.murderer() + cfg.stepMurderer()));
        };
        chances.put(p, n); return n;
    }

    /** ActionBar/BossBar metni (yüzde, 2 hane). */
    public static String format(Chances c) {
        return String.format(Locale.ROOT, "Şerif Olma Şansı: %%%.1f  |  Katil Olma Şansı: %%%.1f", c.sheriff() / 100.0, c.murderer() / 100.0);
    }
}
