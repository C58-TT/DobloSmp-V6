package xyz.doblosmp.security;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.security.SecureRandom;

/** RFC 6238 TOTP (SHA-1, 6 hane, 30 sn) — Google Authenticator/Authy uyumlu. */
public final class Totp {
    private Totp() {}
    private static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    public static String newSecret() {
        byte[] b = new byte[20]; new SecureRandom().nextBytes(b); return base32(b);
    }
    public static String base32(byte[] d) {
        StringBuilder sb = new StringBuilder(); int buf = 0, bits = 0;
        for (byte x : d) { buf = (buf << 8) | (x & 0xff); bits += 8; while (bits >= 5) { sb.append(ALPHA.charAt((buf >> (bits - 5)) & 31)); bits -= 5; } }
        if (bits > 0) sb.append(ALPHA.charAt((buf << (5 - bits)) & 31));
        return sb.toString();
    }
    static byte[] unbase32(String s) {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); int buf = 0, bits = 0;
        for (char c : s.toUpperCase().replace("=", "").toCharArray()) {
            int v = ALPHA.indexOf(c); if (v < 0) continue;
            buf = (buf << 5) | v; bits += 5;
            if (bits >= 8) { o.write((buf >> (bits - 8)) & 0xff); bits -= 8; }
        }
        return o.toByteArray();
    }
    public static String code(String secret, long timeMillis) {
        try {
            long step = timeMillis / 30000L;
            Mac mac = Mac.getInstance("HmacSHA1"); mac.init(new SecretKeySpec(unbase32(secret), "HmacSHA1"));
            byte[] h = mac.doFinal(ByteBuffer.allocate(8).putLong(step).array());
            int off = h[h.length - 1] & 0xf;
            int bin = ((h[off] & 0x7f) << 24) | ((h[off + 1] & 0xff) << 16) | ((h[off + 2] & 0xff) << 8) | (h[off + 3] & 0xff);
            return String.format("%06d", bin % 1_000_000);
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
    /** ±1 adım (30 sn) saat kaymasına izin verir. */
    public static boolean verify(String secret, String input, long now) {
        if (input == null || !input.matches("\\d{6}")) return false;
        for (int d = -1; d <= 1; d++) if (code(secret, now + d * 30000L).equals(input)) return true;
        return false;
    }
    public static String uri(String issuer, String user, String secret) {
        return "otpauth://totp/" + issuer + ":" + user + "?secret=" + secret + "&issuer=" + issuer;
    }
}
