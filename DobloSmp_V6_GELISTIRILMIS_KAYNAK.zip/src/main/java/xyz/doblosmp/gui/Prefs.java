package xyz.doblosmp.gui;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/** Oyuncu tercihleri (prefs.yml). Varsayılan: bildirimler açık, anti-cheat uyarıları açık. */
public final class Prefs {
    private final JavaPlugin plugin; private final File file; private final YamlConfiguration y;
    public Prefs(JavaPlugin p) { plugin = p; file = new File(p.getDataFolder(), "prefs.yml"); y = YamlConfiguration.loadConfiguration(file); }
    public boolean get(UUID id, String key) { return y.getBoolean(id + "." + key, true); }
    public void toggle(UUID id, String key) { y.set(id + "." + key, !get(id, key)); save(); }
    public synchronized void save() { try { plugin.getDataFolder().mkdirs(); y.save(file); } catch (IOException e) { plugin.getLogger().warning("prefs yazılamadı: " + e.getMessage()); } }
}
