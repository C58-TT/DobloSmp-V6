package xyz.doblosmp.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** Kasa: oyuncu başına 27 slotluk kalıcı depo. Her tıklamadan bir tick sonra diske yazılır; aynı kasa aynı anda yalnızca tek kişide açık olabilir. */
public final class Vaults implements Listener {
    private static final class Holder implements InventoryHolder { final UUID owner; Inventory inv; Holder(UUID o) { owner = o; } public Inventory getInventory() { return inv; } }
    private final JavaPlugin plugin; private final File dir; private final Set<UUID> open = new HashSet<>();

    public Vaults(JavaPlugin p) { plugin = p; dir = new File(p.getDataFolder(), "vaults"); dir.mkdirs(); }
    private File file(UUID id) { return new File(dir, id + ".yml"); }

    public void open(Player p) {
        if (!open.add(p.getUniqueId())) { p.sendMessage("§cKasan zaten açık."); return; }
        Holder h = new Holder(p.getUniqueId()); h.inv = Bukkit.createInventory(h, 27, Menu.color("§8Kasa"));
        File f = file(p.getUniqueId());
        if (f.exists()) try { h.inv.setContents(ItemStack.deserializeItemsFromBytes(Base64.getDecoder().decode(YamlConfiguration.loadConfiguration(f).getString("items", "")))); }
        catch (RuntimeException e) { plugin.getLogger().severe("Kasa okunamadı " + p.getName() + ": " + e.getMessage()); open.remove(p.getUniqueId()); p.sendMessage("§cKasa okunamadı, yöneticiye bildir (veri korunuyor)."); return; }
        p.openInventory(h.inv);
    }
    private void save(Holder h) {
        YamlConfiguration y = new YamlConfiguration(); y.set("items", Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes(h.inv.getContents())));
        File tmp = new File(dir, h.owner + ".tmp");
        try { y.save(tmp); java.nio.file.Files.move(tmp.toPath(), file(h.owner).toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
        catch (IOException e) { plugin.getLogger().severe("Kasa yazılamadı: " + e.getMessage()); }
    }
    @EventHandler public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder h) Bukkit.getScheduler().runTask(plugin, () -> save(h));
    }
    @EventHandler public void onDrag(InventoryDragEvent e) { if (e.getView().getTopInventory().getHolder() instanceof Holder h) Bukkit.getScheduler().runTask(plugin, () -> save(h)); }
    @EventHandler public void onClose(InventoryCloseEvent e) { if (e.getInventory().getHolder() instanceof Holder h) { save(h); open.remove(h.owner); } }
    public void saveAllOpen() { for (Player p : Bukkit.getOnlinePlayers()) if (p.getOpenInventory().getTopInventory().getHolder() instanceof Holder h) save(h); }
}
