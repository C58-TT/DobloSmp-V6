package xyz.doblosmp.core;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;
import xyz.doblosmp.game.Activities;
import xyz.doblosmp.game.BedwarsManager;
import xyz.doblosmp.game.DuelsManager;

import java.util.*;

/** Oyuncu TAB ve sidebar görünümü. Murder Mystery'de sidebar özellikle kapalıdır. */
public final class HudManager implements Listener {
    private final DobloSuite plugin;
    private final BedwarsManager bedwars;
    private final DuelsManager duels;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public HudManager(DobloSuite plugin, BedwarsManager bedwars, DuelsManager duels) {
        this.plugin = plugin; this.bedwars = bedwars; this.duels = duels;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> Bukkit.getOnlinePlayers().forEach(this::update), 20L, 20L);
    }

    private String rank(Player p) {
        String[][] ranks = {
                {"kurucu", "§cKurucu"}, {"developer", "§eDeveloper"}, {"moderator", "§6Moderatör"},
                {"rehber", "§2Rehber"}, {"drehber", "§aD.Rehber"}, {"medya", "§dMedya"},
                {"vipplus", "§9Vip+"}, {"vip", "§bVip"}
        };
        for (String[] r : ranks) if (p.hasPermission("doblo.rank." + r[0]) || p.hasPermission("group." + r[0])) return r[1];
        return "§dOyuncu";
    }

    private List<String> lines(Player p) {
        List<String> out = new ArrayList<>();
        out.add("Oyuncu: " + p.getName());
        out.add("Rank: " + ChatColor.stripColor(rank(p)));
        Activities.Kind activity = Activities.of(p.getUniqueId());
        if (activity == Activities.Kind.MURDER) return List.of();
        if (activity == Activities.Kind.BEDWARS) { out.addAll(bedwars.hudLines(p)); out.add("doblogame.xyz"); return out; }
        else if (activity == Activities.Kind.DUELS) out.addAll(duels.hudLines(p));
        else if (p.getWorld().getName().equalsIgnoreCase(plugin.getConfig().getString("skyblock.v2-world", "skyblock_is"))) {
            out.add("Bakiye: " + Ctx.ledger.balance(Ctx.mode("skyblock"), p.getUniqueId()) + "$");
            var island = Ctx.islands.islandOf(p.getUniqueId());
            out.add("Ada Üyesi: " + (island == null ? "-" : island.memberCount()));
        }
        out.add("Çevrimiçi: " + Bukkit.getOnlinePlayers().size());
        out.add("Ping: " + p.getPing() + "ms");
        out.add("doblogame.xyz");
        return out;
    }

    public void update(Player p) {
        p.setPlayerListHeaderFooter("§b§lDOBLOSMP\n§7Minecraft Network", "§fÇevrimiçi: §a" + Bukkit.getOnlinePlayers().size() + "\n§bDoblogame.xyz");
        String teamName = bedwars.tabName(p);
        p.setPlayerListName(teamName == null ? rank(p) + " §f" + p.getName() : teamName);
        Activities.Kind activity = Activities.of(p.getUniqueId());
        if (activity == Activities.Kind.MURDER) { p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard()); boards.remove(p.getUniqueId()); return; }
        Scoreboard sb = boards.computeIfAbsent(p.getUniqueId(), id -> newBoard());
        Objective objective = sb.getObjective("doblo");
        if (objective == null) { objective = sb.registerNewObjective("doblo", "dummy", "§b§lDOBLOSMP"); objective.setDisplaySlot(DisplaySlot.SIDEBAR); }
        for (String entry : new ArrayList<>(sb.getEntries())) sb.resetScores(entry);
        List<String> lines = lines(p);
        int score = Math.min(15, lines.size());
        for (int i = 0; i < lines.size() && i < 15; i++) {
            String line = lines.get(i); String unique = ChatColor.values()[i].toString();
            String entry = (line.length() > 38 ? line.substring(0, 38) : line) + unique;
            objective.getScore(entry).setScore(score--);
        }
        p.setScoreboard(sb);
    }

    private Scoreboard newBoard() {
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        Scoreboard sb = manager.getNewScoreboard();
        Objective o = sb.registerNewObjective("doblo", "dummy", "§b§lDOBLOSMP");
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        return sb;
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { Bukkit.getScheduler().runTask(plugin, () -> update(e.getPlayer())); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { boards.remove(e.getPlayer().getUniqueId()); e.getPlayer().setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard()); }
}
