package xyz.doblosmp.game;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import xyz.doblosmp.bedwars.*;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.gui.Menu;

import java.util.*;

/** BedWars Paper bağlayıcısı: arena kurulumu, lobi/geri sayım, üreticiler, NPC mağaza, olaylar, bitiş ve sıfırlama. Paper'da test EDİLMEDİ. */
public final class BedwarsManager implements CommandExecutor, Listener {
    private static final Color[] COLORS = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.AQUA, Color.WHITE, Color.FUCHSIA, Color.GRAY};
    private static final Material[] WOOL = {Material.RED_WOOL, Material.BLUE_WOOL, Material.GREEN_WOOL, Material.YELLOW_WOOL, Material.CYAN_WOOL, Material.WHITE_WOOL, Material.PINK_WOOL, Material.GRAY_WOOL};
    private static final Map<BedwarsMatch.Res, Material> RES = Map.of(BedwarsMatch.Res.IRON, Material.IRON_INGOT, BedwarsMatch.Res.GOLD, Material.GOLD_INGOT, BedwarsMatch.Res.DIAMOND, Material.DIAMOND, BedwarsMatch.Res.EMERALD, Material.EMERALD);

    private final class Game {
        final ArenaStore.Arena arena; final BedwarsMatch match; final BlockLog log = new BlockLog(); final Set<UUID> all = new LinkedHashSet<>();
        final Map<UUID, UUID> lastHit = new HashMap<>(); final Map<UUID, Long> lastHitAt = new HashMap<>(); final Map<UUID, Integer> armor = new HashMap<>(), sword = new HashMap<>(), pick = new HashMap<>();
        final List<Entity> npcs = new ArrayList<>(); BukkitTask task, genTask; int countdown = -1, tick, tier = 1; long gticks; final double[] box; boolean resetting;
        Game(ArenaStore.Arena a) { arena = a; match = new BedwarsMatch(BedwarsMode.valueOf(a.mode)); box = GameUtil.bounds(a, 80); }
    }
    private final JavaPlugin plugin; private final ArenaStore store; private final Map<String, Game> games = new HashMap<>(); private final Map<UUID, Game> byPlayer = new HashMap<>(); private final PlayerState state;

    public BedwarsManager(JavaPlugin plugin, ArenaStore store, PlayerState state) {
        this.plugin = plugin; this.store = store; this.state = state;
        Ctx.npcs.register("bw-shop", (p, a) -> { Game g = byPlayer.get(p.getUniqueId()); if (g != null && g.match.state() == BedwarsMatch.State.RUNNING && !g.match.isSpectator(p.getUniqueId())) shop(p, g); });
        Ctx.npcs.register("bw-upgrade", (p, a) -> { Game g = byPlayer.get(p.getUniqueId()); if (g != null && g.match.state() == BedwarsMatch.State.RUNNING && !g.match.isSpectator(p.getUniqueId())) upgrades(p, g); });
    }
    private int cfg(String k, int d) { return plugin.getConfig().getInt("bedwars." + k, d); }

    // ================= komutlar =================
    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Oyuncu komutu."); return true; }
        if (a.length == 0) { p.sendMessage("§e/bw join <solo|doubles|trios|squads|arena> | leave | team <1-8> | stats"); return true; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "join" -> join(p, a.length > 1 ? a[1] : "solo");
            case "leave" -> { Game g = byPlayer.get(p.getUniqueId()); if (g == null) p.sendMessage("§cOyunda değilsin."); else quit(p, g, true); }
            case "team" -> { Game g = byPlayer.get(p.getUniqueId()); int t; try { t = Integer.parseInt(a[1]) - 1; } catch (RuntimeException e) { p.sendMessage("§c/bw team <1-8>"); return true; }
                if (g == null || (g.match.state() != BedwarsMatch.State.WAITING && g.match.state() != BedwarsMatch.State.COUNTDOWN)) { p.sendMessage("§cŞu an takım seçemezsin."); return true; } changeTeam(p, g, t); }
            case "start" -> { if (!p.hasPermission("doblo.admin")) { p.sendMessage("§cYetkin yok."); return true; } Game g = byPlayer.get(p.getUniqueId()); if (g == null || !g.match.canStart(2)) { p.sendMessage("§cBaşlatılamaz."); return true; } g.match.startCountdown(2); g.countdown = 3; }
            case "stats" -> { if (Ctx.persist.sql()) { p.sendMessage("§eİstatistikler SQL'de tutuluyor (/profil menüsü)."); } else p.sendMessage("§7İstatistikler yalnızca MariaDB etkinse kalıcıdır."); }
            case "arena" -> { if (!p.hasPermission("doblo.admin")) { p.sendMessage("§cYetkin yok."); return true; } admin(p, a); }
            default -> p.sendMessage("§c/bw help");
        }
        return true;
    }

    private void admin(Player p, String[] a) {
        if (a.length < 2) { p.sendMessage("§e/bw arena create <ad> <solo|doubles|trios|squads> | setlobby | setspawn <ad> <takım> | setbed <ad> <takım> (baktığın yatak) | addgen <ad> <iron|gold|diamond|emerald> [takım] | setshop <ad> <takım> | setupgrade <ad> <takım> | setspectator <ad> | enable | disable | delete | list | check <ad>"); return; }
        String op = a[1].toLowerCase(Locale.ROOT); if (op.equals("list")) { store.all().stream().filter(x -> x.type.equals("BEDWARS")).forEach(x -> p.sendMessage("§7" + x.name + " " + x.mode + (x.enabled ? " §aaçık" : " §cdevre dışı"))); return; }
        if (a.length < 3) { p.sendMessage("§cArena adı gerekli."); return; }
        if (op.equals("create")) { String mode = a.length > 3 ? a[3].toUpperCase(Locale.ROOT) : "SOLO"; try { BedwarsMode.valueOf(mode); } catch (IllegalArgumentException e) { p.sendMessage("§cMod: solo|doubles|trios|squads"); return; }
            var ar = store.create(a[2], "BEDWARS"); if (ar == null) { p.sendMessage("§cOluşturulamadı (ad kullanımda/geçersiz)."); return; } ar.mode = mode; ar.maxPlayers = BedwarsMode.valueOf(mode).capacity(); store.save(); p.sendMessage("§aArena oluşturuldu. Kurulumu tamamla ve /bw arena check " + a[2]); return; }
        var ar = store.get(a[2]); if (ar == null || !ar.type.equals("BEDWARS")) { p.sendMessage("§cArena bulunamadı."); return; }
        if (games.containsKey(ar.name) && !op.equals("disable")) { p.sendMessage("§cArena şu an oyunda; önce devre dışı bırak."); return; }
        Integer team = null; if (a.length > 3 && !op.equals("addgen")) try { team = Integer.parseInt(a[3]) - 1; } catch (NumberFormatException e) { p.sendMessage("§cTakım numarası sayı olmalı."); return; }
        Location here = p.getLocation().clone();
        switch (op) {
            case "setlobby" -> { ar.lobby = here; p.sendMessage("§aLobi ayarlandı."); }
            case "setspectator" -> { ar.points.put("spectator", new ArrayList<>(List.of(here))); p.sendMessage("§aSeyirci noktası ayarlandı."); }
            case "setspawn" -> { if (team == null) return; ar.points.put("spawn:" + team, new ArrayList<>(List.of(here))); p.sendMessage("§aTakım " + (team + 1) + " doğma noktası ayarlandı."); }
            case "setbed" -> { if (team == null) return; Block b = p.getTargetBlockExact(6); if (b == null || !Tag.BEDS.isTagged(b.getType())) { p.sendMessage("§cBir yatağa bak."); return; } ar.points.put("bed:" + team, new ArrayList<>(List.of(b.getLocation()))); p.sendMessage("§aYatak kaydedildi."); }
            case "setshop" -> { if (team == null) return; ar.points.put("shop:" + team, new ArrayList<>(List.of(here))); p.sendMessage("§aMağaza NPC noktası ayarlandı."); }
            case "setupgrade" -> { if (team == null) return; ar.points.put("upgrade:" + team, new ArrayList<>(List.of(here))); p.sendMessage("§aYükseltme NPC noktası ayarlandı."); }
            case "addgen" -> { String t = a.length > 3 ? a[3].toUpperCase(Locale.ROOT) : ""; if (!Set.of("IRON", "GOLD", "DIAMOND", "EMERALD").contains(t)) { p.sendMessage("§cTür: iron|gold|diamond|emerald"); return; }
                String key = (t.equals("IRON") || t.equals("GOLD")) ? "gen:" + t + ":" + (a.length > 4 ? Integer.parseInt(a[4]) - 1 : 0) : "gen:" + t; ar.add(key, here); p.sendMessage("§aÜretici eklendi: " + key); }
            case "enable" -> { String err = validate(ar); if (err != null) { p.sendMessage("§c" + err); return; } ar.enabled = true; p.sendMessage("§aArena açıldı."); }
            case "disable" -> { ar.enabled = false; Game g = games.get(ar.name); if (g != null) endNow(g); p.sendMessage("§eArena devre dışı."); }
            case "delete" -> { store.delete(ar.name); p.sendMessage("§eArena silindi."); }
            case "check" -> { String err = validate(ar); p.sendMessage(err == null ? "§aArena tam ve hazır." : "§c" + err); }
            default -> p.sendMessage("§cBilinmeyen alt komut.");
        }
        store.save();
    }

    /** Arena eksiksiz mi? Eksik kurulumla oyun açılmaz. */
    private String validate(ArenaStore.Arena a) {
        if (a.lobby == null) return "Lobi ayarlanmamış."; if (a.first("spectator") == null) return "Seyirci noktası yok.";
        BedwarsMode m = BedwarsMode.valueOf(a.mode);
        for (int t = 0; t < m.teams; t++) { if (a.first("spawn:" + t) == null) return "Takım " + (t + 1) + " doğma noktası yok."; if (a.first("bed:" + t) == null) return "Takım " + (t + 1) + " yatağı yok."; if (a.first("shop:" + t) == null) return "Takım " + (t + 1) + " mağaza noktası yok."; if (a.first("upgrade:" + t) == null) return "Takım " + (t + 1) + " yükseltme noktası yok."; }
        if (a.pts("gen:DIAMOND").isEmpty() || a.pts("gen:EMERALD").isEmpty()) return "Elmas ve zümrüt üreticisi gerekli."; return null;
    }

    // ================= katılma / lobi =================
    private void join(Player p, String target) {
        UUID id = p.getUniqueId(); if (Activities.busy(id) || byPlayer.containsKey(id)) { p.sendMessage("§cZaten bir etkinlikte/oyundasın."); return; }
        List<UUID> group = Ctx.parties.members(id); var party = Ctx.parties.of(id);
        if (party != null && !party.leader.equals(id)) { p.sendMessage("§cPartideyken yalnızca lider oyuna sokabilir."); return; }
        BedwarsMode mode = null; try { mode = BedwarsMode.valueOf(target.toUpperCase(Locale.ROOT)); } catch (IllegalArgumentException ignored) {}
        Game g = null;
        for (Game x : games.values()) if (!x.resetting && (mode == null ? x.arena.name.equals(target.toLowerCase(Locale.ROOT)) : x.arena.mode.equals(mode.name())) && (x.match.state() == BedwarsMatch.State.WAITING || x.match.state() == BedwarsMatch.State.COUNTDOWN)
                && x.match.playerCount() + group.size() <= x.arena.maxPlayers) { g = x; break; }
        if (g == null) { for (var ar : store.all()) if (ar.type.equals("BEDWARS") && ar.enabled && !games.containsKey(ar.name) && (mode == null ? ar.name.equals(target.toLowerCase(Locale.ROOT)) : ar.mode.equals(mode.name())) && ar.maxPlayers >= group.size()) { g = new Game(ar); games.put(ar.name, g); startLoop(g); break; } }
        if (g == null) { p.sendMessage("§cŞu an uygun/boş arena yok."); return; }
        for (UUID u : group) { Player m = Bukkit.getPlayer(u); if (m != null && !Activities.busy(u)) enter(m, g); }
    }
    private void enter(Player p, Game g) {
        UUID id = p.getUniqueId(); if (!g.match.join(id, null)) return; if (!Activities.enter(id, Activities.Kind.BEDWARS)) { g.match.leave(id); return; }
        state.save(p); byPlayer.put(id, g); g.all.add(id); PlayerState.prepare(p, GameMode.ADVENTURE); p.teleport(g.arena.lobby);
        p.getInventory().setItem(0, Menu.item(Material.NETHER_STAR, "§eTakım Seç")); p.getInventory().setItem(8, Menu.item(Material.SLIME_BALL, "§cAyrıl"));
        GameUtil.msg(g.all, "§a" + p.getName() + " katıldı §7(" + g.match.playerCount() + "/" + g.arena.maxPlayers + ")");
        if (g.match.state() == BedwarsMatch.State.WAITING && g.match.startCountdown(g.arena.minPlayers)) g.countdown = cfg("countdown", 20);
        if (g.match.playerCount() >= g.arena.maxPlayers && g.countdown > 10) g.countdown = 10;
    }
    private void changeTeam(Player p, Game g, int t) {
        if (t < 0 || t >= g.match.teams().size()) { p.sendMessage("§cGeçersiz takım."); return; } var team = g.match.teams().get(t); if (g.match.teamOf(p.getUniqueId()) == team) return;
        if (team.members.size() >= g.match.mode.perTeam) { p.sendMessage("§cTakım dolu."); return; }
        if (!g.match.switchTeam(p.getUniqueId(), t)) { p.sendMessage("§cTakım değiştirilemedi."); return; }
        p.sendMessage("§aTakım: " + team.name);
    }
    private void teamMenu(Player p, Game g) {
        Menu m = new Menu("§eTakım Seç", 2); int i = 0;
        for (var t : g.match.teams()) { int idx = i; m.set(i, Menu.item(WOOL[i % 8], "§f" + t.name, "§7" + t.members.size() + "/" + g.match.mode.perTeam), x -> { if (byPlayer.get(x.getUniqueId()) == g) changeTeam(x, g, idx); x.closeInventory(); }); i++; }
        m.open(p);
    }

    // ================= oyun döngüsü =================
    private void startLoop(Game g) { g.task = Bukkit.getScheduler().runTaskTimer(plugin, () -> tick(g), 20L, 20L); }
    private void tick(Game g) {
        if (g.resetting) return; var st = g.match.state();
        if (st == BedwarsMatch.State.WAITING || st == BedwarsMatch.State.COUNTDOWN) {
            if (g.match.playerCount() == 0) { cancel(g); return; }
            g.match.abortCountdown(g.arena.minPlayers); if (g.match.state() == BedwarsMatch.State.WAITING) { g.countdown = -1; return; }
            if (g.countdown < 0) g.countdown = cfg("countdown", 20);
            if (g.countdown <= 5 || g.countdown % 10 == 0) for (UUID u : g.all) { Player p = Bukkit.getPlayer(u); if (p != null) { p.sendMessage("§eOyun " + g.countdown + " saniye içinde başlıyor!"); if (g.countdown <= 3) GameUtil.title(p, "§c" + g.countdown, ""); } }
            if (g.countdown-- <= 0) begin(g); return;
        }
        if (st == BedwarsMatch.State.RUNNING) {
            g.tick++; int sec = g.tick;
            g.tick = sec; for (var t : g.match.teams()) for (UUID u : t.alive) { Player p = Bukkit.getPlayer(u); if (p != null && t.haste > 0) p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 60, t.haste - 1, true, false)); }
            if (sec >= cfg("max-minutes", 40) * 60) endNow(g);
        }
    }
    private void cancel(Game g) { if (g.task != null) g.task.cancel(); if (g.genTask != null) g.genTask.cancel(); games.remove(g.arena.name); }

    private void begin(Game g) {
        if (!g.match.begin()) return;
        for (var t : g.match.teams()) for (UUID u : t.members) { Player p = Bukkit.getPlayer(u); if (p == null) { g.match.leave(u); continue; } Ctx.stat(u, "bedwars", "games", 1); respawn(p, g, true); GameUtil.title(p, "§6BedWars", "§7Takım: " + t.name); }
        for (var t : g.match.teams()) { if (t.members.isEmpty()) { Location b = g.arena.first("bed:" + t.index); if (b != null) b.getBlock().setType(Material.AIR); } else { spawnNpc(g, "shop:" + t.index, "bw-shop:" + g.arena.name, "§6§lMAĞAZA"); spawnNpc(g, "upgrade:" + t.index, "bw-upgrade:" + g.arena.name, "§b§lYÜKSELTME"); } }
        g.genTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> generators(g), 1L, 1L);
        GameUtil.msg(g.all, "§aOyun başladı! Yatağını koru, rakiplerinkini kır.");
    }
    private void spawnNpc(Game g, String key, String action, String title) { Location l = g.arena.first(key); if (l != null) g.npcs.add(Ctx.npcs.spawn(l, action, title)); }

    private void respawn(Player p, Game g, boolean first) {
        var t = g.match.teamOf(p.getUniqueId()); Location sp = g.arena.first("spawn:" + t.index); PlayerState.prepare(p, GameMode.SURVIVAL); p.teleport(sp);
        UUID id = p.getUniqueId(); Material sw = switch (g.sword.getOrDefault(id, 0)) { case 1 -> Material.STONE_SWORD; case 2 -> Material.IRON_SWORD; case 3 -> Material.DIAMOND_SWORD; default -> Material.WOODEN_SWORD; };
        ItemStack sword = new ItemStack(sw); if (t.sharpness > 0) sword.addEnchantment(Enchantment.SHARPNESS, 1); p.getInventory().addItem(sword);
        int pk = g.pick.getOrDefault(id, 0); if (pk > 0) p.getInventory().addItem(new ItemStack(Material.IRON_PICKAXE));
        ItemStack[] armor = {armorPiece(Material.LEATHER_BOOTS, t, g.armor.getOrDefault(id, 0)), armorPiece(Material.LEATHER_LEGGINGS, t, g.armor.getOrDefault(id, 0)), armorPiece(Material.LEATHER_CHESTPLATE, t, 0), armorPiece(Material.LEATHER_HELMET, t, 0)};
        int tier = g.armor.getOrDefault(id, 0);
        if (tier > 0) { Material b = tier == 1 ? Material.CHAINMAIL_BOOTS : tier == 2 ? Material.IRON_BOOTS : Material.DIAMOND_BOOTS, lg = tier == 1 ? Material.CHAINMAIL_LEGGINGS : tier == 2 ? Material.IRON_LEGGINGS : Material.DIAMOND_LEGGINGS; armor[0] = new ItemStack(b); armor[1] = new ItemStack(lg); }
        if (t.protection > 0) for (ItemStack a : armor) a.addEnchantment(Enchantment.PROTECTION, t.protection);
        p.getInventory().setArmorContents(armor);
    }
    private ItemStack armorPiece(Material m, BedwarsMatch.Team t, int tier) {
        ItemStack it = new ItemStack(m); if (it.getItemMeta() instanceof LeatherArmorMeta lm) { lm.setColor(COLORS[t.index % 8]); it.setItemMeta(lm); } return it;
    }

    /** Her tick çağrılır: aralıklar tick cinsindendir, takım forge seviyesi demir/altın hızını artırır. */
    private void generators(Game g) {
        g.gticks++; long t = g.gticks;
        if (t == 7200 && g.tier < 2) { g.tier = 2; GameUtil.msg(g.all, "§bElmas üreticileri II seviyeye yükseldi!"); }
        if (t == 14400 && g.tier < 3) { g.tier = 3; GameUtil.msg(g.all, "§aZümrüt üreticileri III seviyeye yükseldi!"); }
        for (var team : g.match.teams()) { if (team.members.isEmpty()) continue; Location base = g.arena.first("gen:IRON:" + team.index); if (base == null) base = g.arena.first("spawn:" + team.index);
            if (t % BedwarsMatch.ironIntervalTicks(team.forge) == 0) drop(base, Material.IRON_INGOT, 48);
            Location gb = g.arena.first("gen:GOLD:" + team.index); if (gb == null) gb = base; if (t % BedwarsMatch.goldIntervalTicks(team.forge) == 0) drop(gb, Material.GOLD_INGOT, 24); }
        if (t % BedwarsMatch.diamondIntervalTicks(g.tier) == 0) for (Location l : g.arena.pts("gen:DIAMOND")) drop(l, Material.DIAMOND, 8);
        if (t % BedwarsMatch.emeraldIntervalTicks(g.tier) == 0) for (Location l : g.arena.pts("gen:EMERALD")) drop(l, Material.EMERALD, 8);
    }
    /** Yığılmayı sınırlar: bölgedeki aynı tür eşya cap'i aşarsa üretmez (lag koruması). */
    private void drop(Location l, Material m, int cap) {
        if (l == null) return; int n = 0; for (Entity e : l.getWorld().getNearbyEntities(l, 2, 2, 2)) if (e instanceof Item it && it.getItemStack().getType() == m) n += it.getItemStack().getAmount();
        if (n >= cap) return; Item it = l.getWorld().dropItem(l.clone().add(0, 0.3, 0), new ItemStack(m)); it.setVelocity(new Vector(0, 0.05, 0));
    }

    // ================= mağaza =================
    private static Material iconOf(String id) {
        return switch (id) { case "WOOL16" -> Material.WHITE_WOOL; case "WOOD_PLANKS16" -> Material.OAK_PLANKS; case "END_STONE12" -> Material.END_STONE; case "STONE_SWORD" -> Material.STONE_SWORD; case "IRON_SWORD" -> Material.IRON_SWORD; case "DIAMOND_SWORD" -> Material.DIAMOND_SWORD;
            case "CHAIN_ARMOR" -> Material.CHAINMAIL_BOOTS; case "IRON_ARMOR" -> Material.IRON_BOOTS; case "DIAMOND_ARMOR" -> Material.DIAMOND_BOOTS; case "BOW" -> Material.BOW; case "ARROW6" -> Material.ARROW; case "GOLDEN_APPLE" -> Material.GOLDEN_APPLE;
            case "TNT" -> Material.TNT; case "ENDER_PEARL" -> Material.ENDER_PEARL; case "PICKAXE" -> Material.IRON_PICKAXE; default -> Material.BARRIER; };
    }
    private void shop(Player p, Game g) {
        Menu m = new Menu("§6BedWars Mağaza", 3); int slot = 0;
        for (var it : BedwarsMatch.SHOP.values()) { m.set(slot++, Menu.item(iconOf(it.id()), "§f" + it.id().replace('_', ' '), "§7Fiyat: §e" + it.price() + " " + it.cost().name()), x -> { buy(x, g, it); }); }
        m.open(p);
    }
    private void buy(Player p, Game g, BedwarsMatch.Item it) {
        UUID id = p.getUniqueId(); var t = g.match.teamOf(id); if (t == null || g.match.state() != BedwarsMatch.State.RUNNING) return; Material cur = RES.get(it.cost());
        String k = it.id();
        if (k.equals("CHAIN_ARMOR") && g.armor.getOrDefault(id, 0) >= 1 || k.equals("IRON_ARMOR") && g.armor.getOrDefault(id, 0) >= 2 || k.equals("DIAMOND_ARMOR") && g.armor.getOrDefault(id, 0) >= 3) { p.sendMessage("§cZaten bu zırha veya daha iyisine sahipsin."); return; }
        if (k.equals("PICKAXE") && g.pick.getOrDefault(id, 0) >= 1) { p.sendMessage("§cZaten kazman var."); return; }
        if (!GameUtil.take(p, cur, it.price())) { p.sendMessage("§cYeterli " + it.cost().name() + " yok."); return; }
        switch (k) {
            case "WOOL16" -> GameUtil.give(p, new ItemStack(WOOL[t.index % 8], 16)); case "WOOD_PLANKS16" -> GameUtil.give(p, new ItemStack(Material.OAK_PLANKS, 16)); case "END_STONE12" -> GameUtil.give(p, new ItemStack(Material.END_STONE, 12));
            case "STONE_SWORD", "IRON_SWORD", "DIAMOND_SWORD" -> { int lvl = k.startsWith("STONE") ? 1 : k.startsWith("IRON") ? 2 : 3; if (g.sword.getOrDefault(id, 0) >= lvl) { GameUtil.give(p, new ItemStack(cur, it.price())); p.sendMessage("§cDaha iyi kılıcın var; iade edildi."); return; }
                g.sword.put(id, lvl); p.getInventory().remove(Material.WOODEN_SWORD); ItemStack sw = new ItemStack(k.equals("STONE_SWORD") ? Material.STONE_SWORD : k.equals("IRON_SWORD") ? Material.IRON_SWORD : Material.DIAMOND_SWORD); if (t.sharpness > 0) sw.addEnchantment(Enchantment.SHARPNESS, 1); GameUtil.give(p, sw); }
            case "CHAIN_ARMOR", "IRON_ARMOR", "DIAMOND_ARMOR" -> { g.armor.put(id, k.startsWith("CHAIN") ? 1 : k.startsWith("IRON") ? 2 : 3); respawnArmor(p, g); }
            case "BOW" -> GameUtil.give(p, new ItemStack(Material.BOW)); case "ARROW6" -> GameUtil.give(p, new ItemStack(Material.ARROW, 6)); case "GOLDEN_APPLE" -> GameUtil.give(p, new ItemStack(Material.GOLDEN_APPLE));
            case "TNT" -> GameUtil.give(p, new ItemStack(Material.TNT)); case "ENDER_PEARL" -> GameUtil.give(p, new ItemStack(Material.ENDER_PEARL)); case "PICKAXE" -> { g.pick.put(id, 1); GameUtil.give(p, new ItemStack(Material.IRON_PICKAXE)); }
            default -> { GameUtil.give(p, new ItemStack(cur, it.price())); return; }
        }
        p.sendMessage("§aSatın alındı: " + k);
    }
    private void respawnArmor(Player p, Game g) {
        var t = g.match.teamOf(p.getUniqueId()); int tier = g.armor.getOrDefault(p.getUniqueId(), 0); ItemStack[] a = p.getInventory().getArmorContents();
        Material b = tier == 1 ? Material.CHAINMAIL_BOOTS : tier == 2 ? Material.IRON_BOOTS : Material.DIAMOND_BOOTS, lg = tier == 1 ? Material.CHAINMAIL_LEGGINGS : tier == 2 ? Material.IRON_LEGGINGS : Material.DIAMOND_LEGGINGS;
        a[0] = new ItemStack(b); a[1] = new ItemStack(lg); if (t.protection > 0) for (ItemStack x : a) if (x != null) x.addEnchantment(Enchantment.PROTECTION, t.protection); p.getInventory().setArmorContents(a);
    }
    private void upgrades(Player p, Game g) {
        var t = g.match.teamOf(p.getUniqueId()); Menu m = new Menu("§bTakım Yükseltmeleri", 3); int slot = 10;
        for (BedwarsMatch.Upgrade u : BedwarsMatch.Upgrade.values()) { int cost = g.match.upgradeCost(t, u);
            m.set(slot++, Menu.item(switch (u) { case SHARPNESS -> Material.IRON_SWORD; case PROTECTION -> Material.IRON_CHESTPLATE; case HASTE -> Material.GOLDEN_PICKAXE; case FORGE -> Material.FURNACE; }, "§b" + u.name(), cost < 0 ? "§aAzami seviye" : "§7Maliyet: §b" + cost + " elmas"),
                x -> { boolean ok = g.match.upgradeTeam(x.getUniqueId(), u, c -> GameUtil.take(x, Material.DIAMOND, c)); if (!ok) { x.sendMessage("§cYükseltilemedi (elmas yetersiz/azami)."); return; }
                    GameUtil.msg(t.members, "§b" + x.getName() + " " + u.name() + " yükseltmesini aldı!"); for (UUID mem : t.alive) { Player mp = Bukkit.getPlayer(mem); if (mp != null) { if (u == BedwarsMatch.Upgrade.PROTECTION) respawnArmor(mp, g); if (u == BedwarsMatch.Upgrade.SHARPNESS) for (ItemStack is : mp.getInventory().getContents()) if (is != null && is.getType().name().endsWith("_SWORD")) is.addEnchantment(Enchantment.SHARPNESS, 1); } } x.closeInventory(); }); }
        m.open(p);
    }

    // ================= olaylar =================
    private Game of(Player p) { return byPlayer.get(p.getUniqueId()); }
    private boolean running(Game g) { return g != null && g.match.state() == BedwarsMatch.State.RUNNING; }
    private Game gameAt(Location l) { for (Game g : games.values()) if (g.box != null && g.arena.lobby != null && g.arena.lobby.getWorld() == l.getWorld() && GameUtil.inside(l, g.box)) return g; return null; }

    @EventHandler(priority = EventPriority.HIGH) public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer(); Game g = of(p); Block b = e.getBlock();
        if (g == null) { Game at = gameAt(b.getLocation()); if (at != null && !p.hasPermission("doblo.admin")) e.setCancelled(true); return; }
        if (!running(g) || g.match.isSpectator(p.getUniqueId())) { e.setCancelled(true); return; }
        if (Tag.BEDS.isTagged(b.getType())) {
            e.setCancelled(true); Integer victim = null; for (var t : g.match.teams()) { Location bl = g.arena.first("bed:" + t.index); if (bl != null && GameUtil.near(bl, b.getLocation(), 1.6)) victim = t.index; }
            if (victim == null) return; var mine = g.match.teamOf(p.getUniqueId()); if (mine.index == victim) { p.sendMessage("§cKendi yatağını kıramazsın!"); return; }
            var vt = g.match.teams().get(victim); if (!g.match.breakBed(p.getUniqueId(), victim)) return;
            Location bl = g.arena.first("bed:" + victim); g.log.record(bl.getBlock()); for (Block nb : new Block[]{b, bl.getBlock()}) { g.log.record(nb); nb.setType(Material.AIR, false); }
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) { Block nb = bl.getBlock().getRelative(dx, 0, dz); if (Tag.BEDS.isTagged(nb.getType())) { g.log.record(nb); nb.setType(Material.AIR, false); } }
            GameUtil.msg(g.all, "§c§lYATAK KIRILDI! §f" + vt.name + " takımının yatağı " + p.getName() + " tarafından kırıldı!");
            for (UUID u : vt.members) { Player vp = Bukkit.getPlayer(u); if (vp != null) GameUtil.title(vp, "§cYATAĞIN KIRILDI", "§7Artık yeniden doğamazsın"); }
            Ctx.stat(p.getUniqueId(), "bedwars", "beds", 1); Ctx.quest(p.getUniqueId(), "bedwars_bed", 1); check(g); return;
        }
        if (!g.log.isPlaced(b)) { e.setCancelled(true); p.sendMessage("§cYalnızca oyuncuların koyduğu blokları kırabilirsin."); return; }
        g.log.unplace(b); Ctx.quest(p.getUniqueId(), "blocks_mined", 1);
    }
    @EventHandler(priority = EventPriority.HIGH) public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer(); Game g = of(p); Block b = e.getBlock();
        if (g == null) { Game at = gameAt(b.getLocation()); if (at != null && !p.hasPermission("doblo.admin")) e.setCancelled(true); return; }
        if (!running(g) || g.match.isSpectator(p.getUniqueId())) { e.setCancelled(true); return; }
        for (var t : g.match.teams()) { Location sp = g.arena.first("spawn:" + t.index); if (sp != null && GameUtil.near(sp, b.getLocation(), 2.5)) { e.setCancelled(true); p.sendMessage("§cDoğma noktasının yanına blok koyamazsın."); return; } }
        if (b.getType() == Material.TNT) { e.setCancelled(true); if (GameUtil.take(p, Material.TNT, 1)) { TNTPrimed t = (TNTPrimed) b.getWorld().spawnEntity(b.getLocation().add(0.5, 0, 0.5), EntityType.TNT); t.setFuseTicks(50); } return; }
        var rs = e.getBlockReplacedState(); g.log.recordData(rs.getWorld().getName(), rs.getX(), rs.getY(), rs.getZ(), rs.getBlockData()); g.log.recordPlaced(b); Ctx.quest(p.getUniqueId(), "blocks_placed", 1);
    }
    @EventHandler(priority = EventPriority.HIGH) public void onExplode(EntityExplodeEvent e) {
        Game g = gameAt(e.getLocation()); if (g == null) return;
        e.blockList().removeIf(b -> !g.log.isPlaced(b)); for (Block b : e.blockList()) g.log.unplace(b);
    }
    @EventHandler(priority = EventPriority.HIGH) public void onBlockExplode(BlockExplodeEvent e) { if (gameAt(e.getBlock().getLocation()) != null) e.blockList().clear(); }
    @EventHandler public void onFire(BlockIgniteEvent e) { if (gameAt(e.getBlock().getLocation()) != null && e.getCause() != BlockIgniteEvent.IgniteCause.FLINT_AND_STEEL) e.setCancelled(true); }
    @EventHandler public void onBucket(PlayerBucketEmptyEvent e) { if (of(e.getPlayer()) != null) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGH) public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return; Game g = of(p); if (g == null) return;
        if (!running(g) || g.match.isSpectator(p.getUniqueId())) { e.setCancelled(true); return; }
        if (e instanceof EntityDamageByEntityEvent by) { Player dmg = by.getDamager() instanceof Player x ? x : (by.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player sh ? sh : null);
            if (dmg != null) { if (g.match.isSpectator(dmg.getUniqueId()) || g.match.teamOf(dmg.getUniqueId()) == g.match.teamOf(p.getUniqueId())) { e.setCancelled(true); return; } g.lastHit.put(p.getUniqueId(), dmg.getUniqueId()); g.lastHitAt.put(p.getUniqueId(), System.currentTimeMillis()); } }
        if (e.getCause() == EntityDamageEvent.DamageCause.VOID || p.getHealth() - e.getFinalDamage() <= 0) { e.setCancelled(true); die(p, g); }
    }
    @EventHandler public void onDeathEvent(PlayerDeathEvent e) { Game g = of(e.getEntity()); if (g != null) { e.getDrops().clear(); e.setDroppedExp(0); e.deathMessage(null); } }
    @EventHandler public void onFood(FoodLevelChangeEvent e) { if (e.getEntity() instanceof Player p && of(p) != null) e.setCancelled(true); }
    @EventHandler public void onDrop(PlayerDropItemEvent e) { Game g = of(e.getPlayer()); if (g != null && !running(g)) e.setCancelled(true); }
    @EventHandler public void onPickup(EntityPickupItemEvent e) { if (e.getEntity() instanceof Player p) { Game g = of(p); if (g != null && (!running(g) || g.match.isSpectator(p.getUniqueId()))) e.setCancelled(true); } }
    @EventHandler public void onInvClick(InventoryClickEvent e) { if (e.getWhoClicked() instanceof Player p) { Game g = of(p); if (g != null && !running(g) && !(e.getView().getTopInventory().getHolder() instanceof Menu)) e.setCancelled(true); } }
    @EventHandler public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer(); Game g = of(p); if (g == null || running(g) || e.getItem() == null) return;
        if (e.getItem().getType() == Material.NETHER_STAR) { e.setCancelled(true); teamMenu(p, g); } else if (e.getItem().getType() == Material.SLIME_BALL) { e.setCancelled(true); quit(p, g, true); }
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) { Game g = of(e.getPlayer()); if (g != null) quit(e.getPlayer(), g, false); }
    @EventHandler public void onCmd(PlayerCommandPreprocessEvent e) {
        Game g = of(e.getPlayer()); if (g == null || e.getPlayer().hasPermission("doblo.admin")) return; String c = e.getMessage().toLowerCase(Locale.ROOT).split(" ")[0];
        if (!Set.of("/bw", "/p", "/parti", "/msg", "/w", "/r", "/rapor").contains(c)) { e.setCancelled(true); e.getPlayer().sendMessage("§cOyundayken bu komut kullanılamaz. /bw leave"); }
    }

    private void die(Player p, Game g) {
        UUID id = p.getUniqueId(); UUID killer = g.lastHit.get(id); if (killer != null && System.currentTimeMillis() - g.lastHitAt.getOrDefault(id, 0L) > 10_000) killer = null;
        Player kp = killer == null ? null : Bukkit.getPlayer(killer); if (kp != null && g.match.teamOf(killer) == null) killer = null;
        if (kp != null) { for (var r : RES.values()) { int n = GameUtil.count(p, r); if (n > 0) GameUtil.give(kp, new ItemStack(r, n)); } }
        g.lastHit.remove(id); var res = g.match.onDeath(id, killer); if (res == BedwarsMatch.DeathResult.IGNORED) return;
        p.getInventory().clear(); p.setHealth(20); p.setFallDistance(0);
        if (kp != null) { Ctx.stat(killer, "bedwars", res == BedwarsMatch.DeathResult.ELIMINATED ? "final_kills" : "kills", 1); Ctx.quest(killer, "player_kills", 1); }
        Ctx.stat(id, "bedwars", "deaths", 1);
        GameUtil.msg(g.all, "§7" + p.getName() + " §c" + (kp != null ? "§7" + kp.getName() + " tarafından öldürüldü" : "öldü") + (res == BedwarsMatch.DeathResult.ELIMINATED ? " §6§lFINAL!" : ""));
        p.setGameMode(GameMode.SPECTATOR); Location spec = g.arena.first("spectator"); if (spec != null) p.teleport(spec);
        if (res == BedwarsMatch.DeathResult.RESPAWN) { GameUtil.title(p, "§cÖLDÜN", "§75 saniye içinde yeniden doğacaksın");
            Bukkit.getScheduler().runTaskLater(plugin, () -> { if (g.match.state() == BedwarsMatch.State.RUNNING && p.isOnline() && of(p) == g && !g.match.isSpectator(id)) respawn(p, g, false); }, 100L); }
        else GameUtil.title(p, "§cELENDİN", "§7Seyirci olarak izliyorsun");
        check(g);
    }
    private void check(Game g) { if (g.match.state() == BedwarsMatch.State.ENDING && !g.resetting) finish(g); }
    private void endNow(Game g) { if (g.resetting) return; g.match.endNow(); finish(g); }

    private void quit(Player p, Game g, boolean teleportOut) {
        UUID id = p.getUniqueId(); g.match.leave(id); g.all.remove(id); byPlayer.remove(id); Activities.leave(id, Activities.Kind.BEDWARS);
        GameUtil.msg(g.all, "§7" + p.getName() + " oyundan ayrıldı."); if (p.isOnline()) state.restoreIfPending(p);
        if (g.match.state() == BedwarsMatch.State.RUNNING || g.match.state() == BedwarsMatch.State.ENDING) check(g);
        if (g.all.isEmpty() && !g.resetting && g.match.state() != BedwarsMatch.State.RUNNING) cancel(g);
        else if (g.all.isEmpty() && !g.resetting) endNow(g);
    }

    /** Oyun sonu: ödül, istatistik, ekran, temizlik, arena sıfırlama. */
    private void finish(Game g) {
        g.resetting = true; if (g.genTask != null) g.genTask.cancel(); var winner = g.match.winner(); String mode = Ctx.mode("bedwars");
        for (UUID u : new ArrayList<>(g.all)) { Player p = Bukkit.getPlayer(u); var t = g.match.teamOf(u); boolean won = winner != null && t == winner; long reward = won ? plugin.getConfig().getLong("bedwars.reward-win", 150) : plugin.getConfig().getLong("bedwars.reward-play", 25);
            Ctx.ledger.deposit(mode, u, reward, "bedwars"); Ctx.quest(u, "match_played", 1); if (won) { Ctx.quest(u, "bedwars_win", 1); Ctx.quest(u, "match_won", 1); Ctx.stat(u, "bedwars", "wins", 1); Ctx.quests.grantAchievement(u, "ilk_bedwars_galibiyeti"); }
            if (p != null) { Ctx.xp.accept(p, won ? 100 : 25); int[] st = g.match.stats(u); GameUtil.title(p, won ? "§6§lZAFER!" : "§c§lOYUN BİTTİ", winner == null ? "§7Beraberlik" : "§7Kazanan: " + winner.name);
                p.sendMessage("§e§l--- BedWars Özeti ---"); p.sendMessage("§7Öldürme: §f" + st[0] + " §7Final: §f" + st[1] + " §7Yatak: §f" + st[2] + " §7Ölüm: §f" + st[3] + " §8| §a+" + reward + " para"); } }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (var npc : g.npcs) npc.remove(); g.npcs.clear();
            if (g.box != null && g.arena.lobby != null) for (Entity en : g.arena.lobby.getWorld().getEntities()) if ((en instanceof Item || en instanceof TNTPrimed || en instanceof Arrow) && GameUtil.inside(en.getLocation(), g.box)) en.remove();
            for (UUID u : new ArrayList<>(g.all)) { Player p = Bukkit.getPlayer(u); byPlayer.remove(u); Activities.leave(u, Activities.Kind.BEDWARS); if (p != null) { for (var ef : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(ef.getType()); state.restoreIfPending(p); } }
            g.all.clear(); if (g.task != null) g.task.cancel(); if (g.genTask != null) g.genTask.cancel();
            g.log.restore(plugin, 800, () -> games.remove(g.arena.name));
        }, 20L * cfg("end-delay", 10));
    }

    public void shutdown() {
        for (Game g : new ArrayList<>(games.values())) { for (var npc : g.npcs) npc.remove();
            for (UUID u : new ArrayList<>(g.all)) { Player p = Bukkit.getPlayer(u); if (p != null) state.restoreIfPending(p); }
            g.log.restore(plugin, Integer.MAX_VALUE, null); }
        games.clear(); byPlayer.clear();
    }
}
