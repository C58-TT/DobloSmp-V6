#!/usr/bin/env bash
set -euo pipefail
server_dir=${1:-/opt/minecraft}
bundle_dir=$(cd "$(dirname "$0")/.." && pwd)
source_world="$bundle_dir/worlds/lobby-world"
target="$server_dir/lobby"

if [[ ! -f "$source_world/level.dat" ]]; then
  echo "Lobi haritasi bulunamadi: $source_world" >&2
  exit 1
fi
if [[ -e "$target" ]]; then
  echo "Mevcut lobi dunyasi ezilmeyecek: $target" >&2
  echo "Mevcut dunya verileri korundu." >&2
  exit 2
fi
mkdir -p "$server_dir"
cp -a "$source_world" "$target"
if id minecraft >/dev/null 2>&1; then
  chown -R minecraft:minecraft "$target"
fi
echo "Lobi haritasi $target konumuna kopyalandi. Sunucuyu yeniden baslatip /lobby kullanin. Spawn ayari icin /lobbyspawn kullanin."
