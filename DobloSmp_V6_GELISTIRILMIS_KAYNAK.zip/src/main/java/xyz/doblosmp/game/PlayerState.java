package xyz.doblosmp.game;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Oyun öncesi oyuncu durumunu (envanter, konum, mod, can) DİSKE yazar; sunucu oyun ortasında çökerse bile
 * oyuncu tekrar girdiğinde {@link #restoreIfPending} envanteri geri verir (veri kaybı koruması).
 */
public final class PlayerState {
    private final JavaPlugin plugin; private final File dir;
    public PlayerState(JavaPlugin plugin) { this.plugin = plugin; this.dir = new File(plugin.getDataFolder(), "player-state"); dir.mkdirs(); }
    private File file(UUID id) { return new File(dir, id + ".yml"); }
    public boolean pending(UUID id) { return file(id).exists(); }

    /** Zaten kayıt varsa üzerine YAZMAZ (oyun içinden oyuna geçişte ilk kayıt korunur). */
    public void save(Player p) {
        if (file(p.getUniqueId()).exists()) return;
        YamlConfiguration y = new YamlConfiguration();
        y.set("inv", Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes(p.getInventory().getContents())));
        Location l = p.getLocation();
        y.set("loc", l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ() + ";" + l.getYaw() + ";" + l.getPitch());
        y.set("gm", p.getGameMode().name()); y.set("health", p.getHealth()); y.set("food", p.getFoodLevel()); y.set("xp", p.getLevel());
        try { y.save(file(p.getUniqueId())); } catch (IOException e) { plugin.getLogger().severe("Oyuncu durumu yazılamadı (" + p.getName() + "): " + e.getMessage()); }
    }

    /** Durumu geri yükler ve kaydı siler. Konum geri verilemezse (dünya yok) yalnızca envanter/mod yüklenir. */
    public boolean restoreIfPending(Player p) {
        File f = file(p.getUniqueId()); if (!f.exists()) return false;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        try {
            p.getInventory().clear();
            ItemStack[] items = ItemStack.deserializeItemsFromBytes(Base64.getDecoder().decode(y.getString("inv", "")));
            p.getInventory().setContents(items);
            p.setGameMode(GameMode.valueOf(y.getString("gm", "SURVIVAL"))); p.setFoodLevel(y.getInt("food", 20)); p.setLevel(y.getInt("xp", 0));
            double max = 20; p.setHealth(Math.max(1, Math.min(max, y.getDouble("health", 20))));
            String[] c = y.getString("loc", "").split(";");
            var w = org.bukkit.Bukkit.getWorld(c[0]); if (w != null && c.length == 6) p.teleport(new Location(w, Double.parseDouble(c[1]), Double.parseDouble(c[2]), Double.parseDouble(c[3]), Float.parseFloat(c[4]), Float.parseFloat(c[5])));
        } catch (RuntimeException e) { plugin.getLogger().severe("Oyuncu durumu geri yüklenemedi (" + p.getName() + "): " + e.getMessage() + " — dosya korunuyor: " + f.getName()); return false; }
        f.delete(); return true;
    }

    /** Oyuncuyu oyuna hazırlar: envanteri temizler, tam can/açlık, yaşam modu. */
    public static void prepare(Player p, GameMode gm) {
        p.getInventory().clear(); p.getInventory().setArmorContents(new ItemStack[4]); p.setGameMode(gm); p.setHealth(20); p.setFoodLevel(20); p.setFireTicks(0); p.setFallDistance(0);
        for (var e : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(e.getType());
    }
}
