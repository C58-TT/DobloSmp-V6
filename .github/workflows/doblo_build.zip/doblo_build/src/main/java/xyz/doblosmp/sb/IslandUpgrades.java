package xyz.doblosmp.sb;

/** Sabit ada sınırları. Seviye/puan/yükseltme sistemi YOKTUR; değerler ada başına değişmez. */
public final class IslandUpgrades {
    private IslandUpgrades() {}
    public static final int RADIUS = 100;       // blok
    public static final int MEMBER_LIMIT = 8;   // sahip dahil
    public static int radius(Island i) { return RADIUS; }
    public static int memberLimit(Island i) { return MEMBER_LIMIT; }
}
