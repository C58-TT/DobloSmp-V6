package xyz.doblosmp.social;

import java.util.*;

/** Arkadaşlık: süreli istek, karşılıklı ekleme, silme, üst sınır. Paper'dan bağımsız. */
public final class FriendService {
    private final Map<UUID, Set<UUID>> friends = new HashMap<>();
    private final Map<UUID, Map<UUID, Long>> requests = new HashMap<>();    // hedef -> (isteyen -> bitiş)
    private final int max; private final long ttl;
    public FriendService(int max, long ttlMs) { this.max = max; this.ttl = ttlMs; }

    public synchronized boolean areFriends(UUID a, UUID b) { return friends.getOrDefault(a, Set.of()).contains(b); }
    public synchronized Set<UUID> of(UUID a) { return new HashSet<>(friends.getOrDefault(a, Set.of())); }
    public synchronized boolean request(UUID from, UUID to, long now) {
        if (from.equals(to) || areFriends(from, to) || of(from).size() >= max) return false;
        Map<UUID, Long> mine = requests.getOrDefault(from, Map.of());
        if (mine.containsKey(to) && mine.get(to) > now) return accept(from, to, now);      // karşılıklı istek = otomatik kabul
        requests.computeIfAbsent(to, k -> new HashMap<>()).put(from, now + ttl); return true;
    }
    public synchronized boolean accept(UUID me, UUID from, long now) {
        Map<UUID, Long> m = requests.get(me); Long until = m == null ? null : m.remove(from);
        if (until == null || until < now || friends.getOrDefault(me, Set.of()).size() >= max || friends.getOrDefault(from, Set.of()).size() >= max) return false;
        friends.computeIfAbsent(me, k -> new HashSet<>()).add(from); friends.computeIfAbsent(from, k -> new HashSet<>()).add(me); return true;
    }
    public synchronized boolean deny(UUID me, UUID from) { Map<UUID, Long> m = requests.get(me); return m != null && m.remove(from) != null; }
    public synchronized boolean remove(UUID a, UUID b) {
        boolean x = friends.getOrDefault(a, new HashSet<>()).remove(b), y = friends.getOrDefault(b, new HashSet<>()).remove(a); return x || y;
    }
    public synchronized List<UUID> pending(UUID me, long now) { List<UUID> l = new ArrayList<>(); requests.getOrDefault(me, Map.of()).forEach((k, v) -> { if (v > now) l.add(k); }); return l; }
    public synchronized Map<UUID, Set<UUID>> snapshot() { Map<UUID, Set<UUID>> c = new HashMap<>(); friends.forEach((k, v) -> c.put(k, new HashSet<>(v))); return c; }
    public synchronized void restore(Map<UUID, Set<UUID>> d) { friends.clear(); d.forEach((k, v) -> friends.put(k, new HashSet<>(v))); }
}
