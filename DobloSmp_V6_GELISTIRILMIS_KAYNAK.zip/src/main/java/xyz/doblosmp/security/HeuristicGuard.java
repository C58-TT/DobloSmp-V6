package xyz.doblosmp.security;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Conservative staff-alert prototype only. Not an anti-cheat and never punishes players. */
public final class HeuristicGuard implements Listener {
    private final JavaPlugin plugin;
    private final Map<UUID, Integer> movementBursts = new HashMap<>();
    private final Map<UUID, Long> lastAlert = new HashMap<>();
    public HeuristicGuard(JavaPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, movementBursts::clear, 20L, 20L);
    }
    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() == null || event.getFrom().getWorld() != event.getTo().getWorld()) return;
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR
                || player.isFlying() || player.isInsideVehicle() || player.isGliding()
                || player.isSwimming() || player.isRiptiding()) return;
        double distance = event.getTo().toVector().subtract(event.getFrom().toVector()).length();
        if (distance < 1.15) return;
        UUID id = player.getUniqueId();
        int count = movementBursts.merge(id, 1, Integer::sum);
        int threshold = Math.max(1, plugin.getConfig().getInt("security.thresholds.movement-suspicion", 12));
        if (count >= threshold) alert(player);
    }
    @EventHandler public void onQuit(PlayerQuitEvent event) {
        movementBursts.remove(event.getPlayer().getUniqueId());
        lastAlert.remove(event.getPlayer().getUniqueId());
    }
    private void alert(Player suspect) {
        if (!plugin.getConfig().getBoolean("security.alerts", false)) return;
        long now = System.currentTimeMillis();
        long previous = lastAlert.getOrDefault(suspect.getUniqueId(), 0L);
        if (now - previous < 30_000L) return;
        lastAlert.put(suspect.getUniqueId(), now);
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("doblo.admin")) staff.sendMessage("§c[DobloGuard] §f" + suspect.getName() + " §7- incelenmesi gereken hareket örüntüsü (otomatik ceza uygulanmadı).");
        }
    }
}
