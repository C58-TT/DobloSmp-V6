package xyz.doblosmp.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.economy.AuctionHouse;
import xyz.doblosmp.sb.Island;

import java.util.*;

import static xyz.doblosmp.gui.Menu.item;

/** Ana menü ve alt menüler. Komut tabanlıdır: her düğme ilgili komutu oyuncu adına çalıştırır, yani yetki ve doğrulama komut tarafında yapılır. */
public final class Menus {
    private Menus() {}
    public static Vaults vaults; public static Prefs prefs;

    private static String name(UUID id) { var p = Bukkit.getOfflinePlayer(id); return p.getName() == null ? id.toString().substring(0, 8) : p.getName(); }
    private static void cmd(Player p, String c) { p.closeInventory(); p.performCommand(c); }

    public static void main(Player p) {
        Menu m = new Menu("§bDobloSmp §8| Ana Menü", 3);
        m.set(10, item(Material.COMPASS, "§aOyun Modları", "§7SkyBlock, BedWars, Duels, Murder Mystery"), x -> games(x));
        m.set(11, item(Material.PLAYER_HEAD, "§eProfil"), x -> profile(x));
        m.set(12, item(Material.EMERALD, "§aMarket", "§7Oyuncu marketi ve açık artırma"), x -> market(x, 0));
        m.set(13, item(Material.ENDER_CHEST, "§5Kasa", "§7Kalıcı depo"), x -> { x.closeInventory(); vaults.open(x); });
        m.set(14, item(Material.CAKE, "§dArkadaşlar"), x -> friends(x));
        m.set(15, item(Material.FIREWORK_ROCKET, "§6Parti"), x -> party(x));
        m.set(16, item(Material.SHIELD, "§cKlan"), x -> clan(x));
        m.set(19, item(Material.WRITABLE_BOOK, "§bGörevler"), x -> quests(x));
        m.set(20, item(Material.CHEST_MINECART, "§6Günlük Ödül"), x -> cmd(x, "gorevler gunluk"));
        m.set(21, item(Material.COMPARATOR, "§7Ayarlar"), x -> settings(x));
        if (p.hasPermission("doblo.admin")) m.set(25, item(Material.COMMAND_BLOCK, "§cYönetici", "§7Anti-cheat uyarıları: /dac <oyuncu>", "§7Panel: tarayıcıdan"), null);
        m.fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }

    public static void games(Player p) {
        Menu m = new Menu("§aOyun Modları", 3);
        m.set(10, item(Material.GRASS_BLOCK, "§aSkyBlock", "§7Adana git / oluştur"), x -> cmd(x, "is"));
        m.set(12, item(Material.RED_BED, "§cBedWars", "§7Mod seç"), x -> bedwars(x));
        m.set(14, item(Material.DIAMOND_SWORD, "§bDuels", "§7Kit seç ve kuyruğa gir"), x -> duels(x));
        m.set(16, item(Material.BOW, "§4Murder Mystery", "§7Maça katıl"), x -> cmd(x, "mm join"));
        m.back(Menus::main).fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }
    static void bedwars(Player p) {
        Menu m = new Menu("§cBedWars", 3);
        m.set(10, item(Material.RED_WOOL, "§cSolo"), x -> cmd(x, "bw join solo")); m.set(12, item(Material.BLUE_WOOL, "§9Doubles"), x -> cmd(x, "bw join doubles"));
        m.set(14, item(Material.GREEN_WOOL, "§a3v3v3v3"), x -> cmd(x, "bw join trios")); m.set(16, item(Material.YELLOW_WOOL, "§e4v4v4v4"), x -> cmd(x, "bw join squads"));
        m.back(Menus::games).fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }
    static void duels(Player p) {
        Menu m = new Menu("§bDuels §8| Kit", 3); int slot = 10;
        for (String kit : Ctx.plugin.getConfig().getConfigurationSection("duels.kits").getKeys(false)) {
            m.set(slot++, item(Material.IRON_SWORD, "§b" + kit, "§aSol: §fSıralı kuyruk", "§eSağ: §fSırasız kuyruk"), x -> cmd(x, "duel queue " + kit + " ranked"));
            if (slot > 16) break;
        }
        m.back(Menus::games).fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }

    public static void profile(Player p) {
        Menu m = new Menu("§eProfil §8| " + p.getName(), 3); UUID id = p.getUniqueId();
        Island is = Ctx.islands.islandOf(id); var cl = Ctx.clans.of(id); var qd = Ctx.quests.of(id);
        m.set(4, item(Material.PLAYER_HEAD, "§e" + p.getName(), "§7Bakiye: §a" + Ctx.ledger.balance(Ctx.mode("skyblock"), id)), null);
        m.set(10, item(Material.GRASS_BLOCK, "§aSkyBlock", is == null ? "§7Adan yok" : "§7Ada hazır", is == null ? "" : "§7Üye: §f" + is.memberCount()), null);
        m.set(12, item(Material.SHIELD, "§cKlan", cl == null ? "§7Klanın yok" : "§7[" + cl.tag + "] " + cl.name + " Sv." + cl.level()), null);
        m.set(14, item(Material.EXPERIENCE_BOTTLE, "§bBattle Pass", "§7Kademe: §f" + Ctx.quests.passTier(id), "§7Giriş serisi: §f" + qd.streak), null);
        m.set(16, item(Material.NETHER_STAR, "§6Başarımlar", "§7" + qd.achievements.size() + " başarım"), null);
        m.back(Menus::main).fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }

    public static void market(Player p, int page) {
        List<AuctionHouse.Listing> ls = Ctx.market.active();
        Menu.paged(p, "§aMarket", ls, page, l -> {
            Material mat; try { mat = Material.valueOf(l.item()); } catch (IllegalArgumentException e) { mat = Material.BARRIER; }
            return item(mat, "§f" + l.amount() + "x " + l.item(), "§7Satıcı: §f" + name(l.seller()), l.auction() ? "§6Açık artırma §7en yüksek: §f" + l.topBid() + " (min " + l.price() + ")" : "§aFiyat: §f" + l.price(),
                    l.auction() ? "§eTıkla: /market teklif " + l.id() + " <miktar>" : "§eTıkla: satın al");
        }, (pl, l) -> { if (l.auction()) { pl.closeInventory(); pl.sendMessage("§e/market teklif " + l.id() + " <miktar>"); } else cmd(pl, "market al " + l.id()); },
                Menus::main, pg -> market(p, pg));
    }

    public static void friends(Player p) {
        List<UUID> fl = new ArrayList<>(Ctx.friends.of(p.getUniqueId())); fl.sort(Comparator.comparing((UUID u) -> Bukkit.getPlayer(u) == null).thenComparing(Menus::name));
        Menu.paged(p, "§dArkadaşlar", fl, 0, u -> { boolean on = Bukkit.getPlayer(u) != null; return item(on ? Material.LIME_DYE : Material.GRAY_DYE, (on ? "§a" : "§7") + name(u), on ? "§7Çevrimiçi" : "§8Çevrimdışı", "§eTıkla: parti daveti"); },
                (pl, u) -> { if (Bukkit.getPlayer(u) != null) cmd(pl, "parti davet " + name(u)); }, Menus::main, pg -> friends(p));
    }
    public static void party(Player p) {
        var members = Ctx.parties.members(p.getUniqueId()); var party = Ctx.parties.of(p.getUniqueId()); Menu m = new Menu("§6Parti", 3);
        int s = 9; for (UUID u : members) m.set(s++, item(Material.PLAYER_HEAD, (party != null && party.leader.equals(u) ? "§6★ " : "§f") + name(u)), null);
        m.set(22, party == null ? item(Material.LIME_DYE, "§aParti kur", "§7/parti davet <oyuncu>") : item(Material.BARRIER, "§cPartiden ayrıl"), x -> cmd(x, "parti ayril"));
        if (party != null && party.leader.equals(p.getUniqueId())) m.set(24, item(Material.TNT, "§cPartiyi dağıt"), x -> cmd(x, "parti dagit"));
        m.back(Menus::main).fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }
    public static void clan(Player p) {
        var c = Ctx.clans.of(p.getUniqueId()); Menu m = new Menu("§cKlan", 3);
        if (c == null) m.set(13, item(Material.WRITABLE_BOOK, "§aKlan kur", "§7/klan olustur <TAG> <ad>"), null);
        else { m.set(10, item(Material.SHIELD, "§c[" + c.tag + "] " + c.name, "§7Seviye: §f" + c.level(), "§7Puan: §f" + c.points, "§7Savaş: §f" + c.wins + "G-" + c.losses + "M", "§7Üye: §f" + c.members.size() + "/" + Ctx.clans.capacity(c)), null);
            int s = 11; for (UUID u : c.members) { if (s > 17) break; m.set(s++, item(Material.PLAYER_HEAD, (c.leader.equals(u) ? "§6★ " : "§f") + name(u)), null); }
            m.set(22, item(Material.BARRIER, "§cKlandan ayrıl"), x -> cmd(x, "klan ayril")); }
        m.set(16, item(Material.GOLD_INGOT, "§6Klan sıralaması"), x -> { x.closeInventory(); cmd(x, "klan top"); });
        m.back(Menus::main).fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }
    public static void quests(Player p) {
        var ls = new ArrayList<>(Ctx.quests.quests()); UUID id = p.getUniqueId();
        Menu.paged(p, "§bGörevler", ls, 0, q -> { int pr = Ctx.quests.progress(id, q.id(), Ctx.today()); boolean claimed = Ctx.quests.of(id).claimed.contains(q.id());
            return item(claimed ? Material.CHEST : pr >= q.target() ? Material.CHEST_MINECART : Material.PAPER, (claimed ? "§8" : "§f") + q.id(), "§7[" + q.period() + "] §a" + pr + "/" + q.target(), "§7Ödül: " + q.xp() + " XP, " + q.coins() + " para", pr >= q.target() && !claimed ? "§eTıkla: ödülü al" : ""); },
                (pl, q) -> { pl.closeInventory(); pl.performCommand("gorevler al " + q.id()); }, Menus::main, pg -> quests(p));
    }
    public static void settings(Player p) {
        Menu m = new Menu("§7Ayarlar", 3);
        String[][] opts = {{"friend_notify", "Arkadaş bildirimleri", "10"}, {"party_requests", "Parti istekleri", "12"}, {"island_visitors_msg", "Ziyaretçi bildirimi", "14"}};
        for (String[] o : opts) { boolean on = prefs.get(p.getUniqueId(), o[0]);
            m.set(Integer.parseInt(o[2]), item(on ? Material.LIME_DYE : Material.GRAY_DYE, (on ? "§a" : "§c") + o[1] + ": " + (on ? "AÇIK" : "KAPALI"), "§eTıkla: değiştir"), x -> { prefs.toggle(x.getUniqueId(), o[0]); settings(x); }); }
        if (p.hasPermission("doblo.admin")) { boolean on = prefs.get(p.getUniqueId(), "ac_alerts"); m.set(16, item(on ? Material.LIME_DYE : Material.GRAY_DYE, "§cAnti-cheat uyarıları: " + (on ? "AÇIK" : "KAPALI")), x -> { prefs.toggle(x.getUniqueId(), "ac_alerts"); settings(x); }); }
        m.back(Menus::main).fillEmpty(Material.GRAY_STAINED_GLASS_PANE).open(p);
    }
}
