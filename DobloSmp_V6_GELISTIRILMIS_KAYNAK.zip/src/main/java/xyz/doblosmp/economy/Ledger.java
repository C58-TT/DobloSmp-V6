package xyz.doblosmp.economy;

import java.util.*;

/**
 * Oyun moduna özel bakiye defteri. Tüm işlemler senkronize ve atomiktir.
 * Her bakiye değişikliği kayıt altına alınır; {@link #audit(String)} para çoğaltma açıklarını tespit eder:
 * bir modun tüm bakiyelerinin toplamı = sistemin bastığı - yaktığı miktar olmak zorundadır.
 */
public final class Ledger {
    public record Entry(long id, long time, String mode, UUID from, UUID to, long amount, String reason) {}

    public static final UUID SYSTEM = new UUID(0L, 0L);
    private final Map<String, Map<UUID, Long>> balances = new HashMap<>();
    private final Map<String, Long> net = new HashMap<>();   // bastırılan - yakılan
    private final ArrayDeque<Entry> log = new ArrayDeque<>();
    private final int maxLog;
    private long seq;
    private volatile java.util.function.Consumer<Entry> listener;
    /** Her kayıt için çağrılır (kalıcı günlük için). Dinleyici hızlı olmalı (kuyruğa atmalı). */
    public void setListener(java.util.function.Consumer<Entry> l) { listener = l; }

    public Ledger(int maxLog) { this.maxLog = Math.max(100, maxLog); }

    public synchronized long balance(String mode, UUID id) {
        return balances.getOrDefault(mode, Map.of()).getOrDefault(id, 0L);
    }

    /** Sistemden para basar (ödül vb.). */
    public synchronized boolean deposit(String mode, UUID to, long amount, String reason) {
        if (amount <= 0) return false;
        long cur = balance(mode, to), nn, newNet;
        try { nn = Math.addExact(cur, amount); newNet = Math.addExact(net.getOrDefault(mode, 0L), amount); }
        catch (ArithmeticException e) { return false; }
        put(mode, to, nn); net.put(mode, newNet);
        record(mode, SYSTEM, to, amount, reason);
        return true;
    }

    /** Parayı sistemden yakar (satın alma vb.). Yetersiz bakiyede false döner. */
    public synchronized boolean withdraw(String mode, UUID from, long amount, String reason) {
        if (amount <= 0) return false;
        long cur = balance(mode, from);
        if (cur < amount) return false;
        put(mode, from, cur - amount);
        net.put(mode, net.getOrDefault(mode, 0L) - amount);
        record(mode, from, SYSTEM, amount, reason);
        return true;
    }

    public synchronized boolean transfer(String mode, UUID from, UUID to, long amount, String reason) {
        if (amount <= 0 || from.equals(to)) return false;
        long a = balance(mode, from);
        if (a < amount) return false;
        long b = balance(mode, to), nb;
        try { nb = Math.addExact(b, amount); } catch (ArithmeticException e) { return false; }
        put(mode, from, a - amount);
        put(mode, to, nb);
        record(mode, from, to, amount, reason);
        return true;
    }

    /** true = defter tutarlı. */
    public synchronized boolean audit(String mode) {
        long sum = 0;
        for (long v : balances.getOrDefault(mode, Map.of()).values()) {
            if (v < 0) return false;
            sum += v;
        }
        return sum == net.getOrDefault(mode, 0L);
    }

    public synchronized List<Entry> history(UUID player, int limit) {
        List<Entry> out = new ArrayList<>();
        Iterator<Entry> it = log.descendingIterator();
        while (it.hasNext() && out.size() < limit) {
            Entry e = it.next();
            if (e.from().equals(player) || e.to().equals(player)) out.add(e);
        }
        return out;
    }

    public synchronized Map<String, Map<UUID, Long>> snapshot() {
        Map<String, Map<UUID, Long>> c = new HashMap<>();
        balances.forEach((m, mm) -> c.put(m, new HashMap<>(mm)));
        return c;
    }

    /** Kayıtlı bakiyeleri geri yükler; net değer bakiyelerden yeniden hesaplanır. */
    public synchronized void restore(Map<String, Map<UUID, Long>> data) {
        balances.clear(); net.clear();
        data.forEach((m, mm) -> {
            long sum = 0;
            Map<UUID, Long> copy = new HashMap<>();
            for (var e : mm.entrySet()) if (e.getValue() > 0) { copy.put(e.getKey(), e.getValue()); sum += e.getValue(); }
            balances.put(m, copy); net.put(m, sum);
        });
    }

    private void put(String mode, UUID id, long v) { balances.computeIfAbsent(mode, k -> new HashMap<>()).put(id, v); }

    private void record(String mode, UUID f, UUID t, long amt, String reason) {
        Entry en = new Entry(++seq, System.currentTimeMillis(), mode, f, t, amt, reason); log.addLast(en);
        var l = listener; if (l != null) l.accept(en);
        while (log.size() > maxLog) log.removeFirst();
    }
}
