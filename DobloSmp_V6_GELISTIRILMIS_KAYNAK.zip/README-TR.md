# DobloSuite 6.0.0 — DobloSmp V6 çalışma paketi

Java 21 / Paper 1.21.11 Maven projesi. Bu kaynak paketi üzerinde V6 düzenlemeleri yapılmıştır; **tam Paper derlemesi ve gerçek sunucu testi henüz tamamlanmış değildir.** Güncel durum için `docs/IMPLEMENTATION-STATUS.md` dosyasını oku.

- Derleme ve test: `mvn clean package`.
- GitHub Actions: `.github/workflows/build.yml` Java 21 ile derler ve başarılı JAR dosyasını artifact olarak yükler.
- Kurulum: `docs/INSTALL.md`. Android yönetimi: `docs/ANDROID-YONETIM.md`.
- Oyun komutları: `/ada`, `/is`, `/bw`, `/duel`, `/mm`, `/ayril`, `/spawn`, `/lobby`, `/menu`.
- Yönetici komutları: `/dnpc`, `/arena`, `/bw arena`, `/duel arena`, `/mm arena`.

## V6 oyun düzeni

- SkyBlock: Ada seviyesi/değer sistemi yoktur. Başlangıç sandığında 1 lava kovası, 1 su kovası ve 2 meşe fidanı bulunur.
- BedWars: Yalnızca 8 oyunculu Solo; 8 ayrı takım.
- Duels: Crystal, Mace ve Diamond kitleri; Bakır, Demir, Altın, Elmas, Zümrüt, Netherite Elo ligleri. Mevcut maç motoru şu an 1v1 destekler; 2v2 henüz uygulanmadı.
- Murder Mystery: En az 5 oyuncu; bağımsız Şerif/Katil rol şansları; Murder Mystery'de sidebar scoreboard yoktur.
- Scoreboard: Hiçbir oyun modunda oyun modu satırı gösterilmez.

## Harita ve kurulum

- Sağlanan dünyalar içinde yalnızca Lobby haritası vardır: `worlds/lobby-world/`.
- Sunucu ana dizinine `worlds/lobby-world` klasörünü `lobby` adıyla kopyala. `config.yml` varsayılan olarak `lobby.world: lobby` kullanır.
- BedWars, Duels ve Murder Mystery arena haritaları bu ZIP'te bulunmuyor. Haritaları ayrıca ekleyip arena konumlarını yönetici komutlarıyla ayarlamak gerekir.
- GitHub deposunun köküne ZIP'in içeriğini çıkar; ZIP'i tek başına depoya koymak build workflow'unu çalıştırmaz.
- GitHub Actions'ta **DobloSmp V6 Build** iş akışını çalıştır. Başarılı olursa `DobloSmp-V6-JAR` artifact'i oluşur.

Gizli bilgiler DB parolası ve Discord webhook dahil ortam değişkenleriyle verilir; `config.yml` içine gerçek gizli bilgi yazma.
