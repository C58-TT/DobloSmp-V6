package xyz.doblosmp.sb;

public final class IslandUpgrades {
    private IslandUpgrades() {}
    public enum Type { SIZE, MEMBERS, GENERATOR }
    private static final int[] SIZE = {50, 75, 100, 150, 200};
    private static final int[] MEMBERS = {3, 5, 8, 12, 16};
    private static final long[] SIZE_COST = {0, 5_000, 15_000, 40_000, 100_000};
    private static final long[] MEMBER_COST = {0, 3_000, 10_000, 30_000, 80_000};
    private static final long[] GEN_COST = {0, 4_000, 12_000, 35_000, 90_000};

    public static int maxTier(Type t) { return SIZE.length - 1; }
    public static int tier(Island i, Type t) { return switch (t) { case SIZE -> i.sizeTier; case MEMBERS -> i.memberTier; case GENERATOR -> i.generatorTier; }; }
    /** Yarıçap (blok). */
    public static int radius(Island i) { return SIZE[Math.min(i.sizeTier, SIZE.length - 1)]; }
    public static int memberLimit(Island i) { return MEMBERS[Math.min(i.memberTier, MEMBERS.length - 1)]; }
    /** Sonraki kademenin maliyeti; -1 = azami seviye. */
    public static long nextCost(Island i, Type t) {
        int l = tier(i, t); if (l >= maxTier(t)) return -1;
        return switch (t) { case SIZE -> SIZE_COST[l + 1]; case MEMBERS -> MEMBER_COST[l + 1]; case GENERATOR -> GEN_COST[l + 1]; };
    }
    public static void apply(Island i, Type t) { switch (t) { case SIZE -> i.sizeTier++; case MEMBERS -> i.memberTier++; case GENERATOR -> i.generatorTier++; } }
}
