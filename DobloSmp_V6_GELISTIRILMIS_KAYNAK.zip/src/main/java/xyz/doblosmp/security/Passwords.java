package xyz.doblosmp.security;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.*;
import java.util.Base64;

public final class Passwords {
    private Passwords() {}
    private static final SecureRandom RNG = new SecureRandom();
    private static final int ITER = 210_000;

    public static String newSalt() { byte[] b = new byte[16]; RNG.nextBytes(b); return Base64.getEncoder().encodeToString(b); }
    public static String hash(String password, String salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), Base64.getDecoder().decode(salt), ITER, 256);
            return Base64.getEncoder().encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded());
        } catch (GeneralSecurityException e) { throw new IllegalStateException(e); }
    }
    public static boolean verify(String password, String salt, String expected) {
        return MessageDigest.isEqual(hash(password, salt).getBytes(), expected.getBytes());
    }
    public static String token() { byte[] b = new byte[32]; RNG.nextBytes(b); return Base64.getUrlEncoder().withoutPadding().encodeToString(b); }
    /** En az 10 karakter, harf ve rakam. */
    public static boolean strong(String p) { return p != null && p.length() >= 10 && p.chars().anyMatch(Character::isLetter) && p.chars().anyMatch(Character::isDigit); }
}
