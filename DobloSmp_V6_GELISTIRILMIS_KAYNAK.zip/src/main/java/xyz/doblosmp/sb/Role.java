package xyz.doblosmp.sb;

/** Ada rolü: sıra önemlidir (büyük = daha yetkili). */
public enum Role { VISITOR, MEMBER, MODERATOR, OWNER; public boolean atLeast(Role r) { return ordinal() >= r.ordinal(); } }
