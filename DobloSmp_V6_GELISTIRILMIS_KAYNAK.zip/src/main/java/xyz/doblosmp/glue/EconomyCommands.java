package xyz.doblosmp.glue;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.economy.*;

import java.util.*;

/** /bakiye, /pay, /takas, /market. Tüm kontroller sunucu tarafında; para işlemleri Ledger üzerinden. */
public final class EconomyCommands implements CommandExecutor {
    private final JavaPlugin plugin; private final Ledger ledger; private final AuctionHouse market; private final String mode;
    private final Map<UUID, TradeSession> trades = new HashMap<>();   // iki tarafın UUID'si de aynı oturuma bağlı
    private final Map<UUID, UUID> tradeRequests = new HashMap<>();    // hedef -> isteyen

    public EconomyCommands(JavaPlugin plugin, Ledger ledger, AuctionHouse market, String mode) {
        this.plugin = plugin; this.ledger = ledger; this.market = market; this.mode = mode;
    }

    /** Eşya köprüsü: yalnızca Material adı + adet; isimli/büyülü eşyalar ticarete kapalıdır (kopyalama/kayıp riski). */
    private final TradeSession.ItemGateway gateway = new TradeSession.ItemGateway() {
        public boolean has(UUID p, String item, int n) { Player pl = Bukkit.getPlayer(p); return pl != null && pl.getInventory().containsAtLeast(new ItemStack(Material.valueOf(item)), n); }
        public boolean take(UUID p, String item, int n) {
            Player pl = Bukkit.getPlayer(p); if (pl == null || !has(p, item, n)) return false;
            return pl.getInventory().removeItem(new ItemStack(Material.valueOf(item), n)).isEmpty();
        }
        public void give(UUID p, String item, int n) {
            Player pl = Bukkit.getPlayer(p); ItemStack st = new ItemStack(Material.valueOf(item), n);
            if (pl == null) return;
            pl.getInventory().addItem(st).values().forEach(rest -> pl.getWorld().dropItemNaturally(pl.getLocation(), rest));
        }
    };

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Oyuncu komutu."); return true; }
        switch (c.getName().toLowerCase(Locale.ROOT)) {
            case "bakiye" -> p.sendMessage("§aBakiye (" + mode + "): §f" + ledger.balance(mode, p.getUniqueId()));
            case "pay" -> pay(p, a);
            case "takas" -> trade(p, a);
            case "market" -> market(p, a);
            default -> { return false; }
        }
        return true;
    }

    private Long amount(Player p, String s) {
        try { long v = Long.parseLong(s); if (v > 0) return v; } catch (NumberFormatException ignored) {}
        p.sendMessage("§cGeçerli bir pozitif sayı gir."); return null;
    }

    private void pay(Player p, String[] a) {
        if (a.length < 2) { p.sendMessage("§c/pay <oyuncu> <miktar>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]); Long v = amount(p, a[1]);
        if (t == null || v == null) { if (t == null) p.sendMessage("§cOyuncu çevrimiçi değil."); return; }
        if (!ledger.transfer(mode, p.getUniqueId(), t.getUniqueId(), v, "pay")) { p.sendMessage("§cYetersiz bakiye veya geçersiz işlem."); return; }
        p.sendMessage("§a" + v + " gönderildi → " + t.getName()); t.sendMessage("§a" + p.getName() + " sana " + v + " gönderdi.");
    }

    private void trade(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length == 0) { p.sendMessage("§e/takas <oyuncu> | para <n> | esya | onayla | iptal | kabul"); return; }
        TradeSession ts = trades.get(id);
        if (ts != null && ts.state() != TradeSession.State.OPEN) { trades.remove(ts.a); trades.remove(ts.b); ts = null; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "kabul" -> {
                UUID from = tradeRequests.remove(id); Player f = from == null ? null : Bukkit.getPlayer(from);
                if (f == null || trades.containsKey(id) || trades.containsKey(from)) { p.sendMessage("§cGeçerli istek yok."); return; }
                TradeSession n = new TradeSession(from, id, mode, plugin.getConfig().getLong("economy.trade-timeout-seconds", 120) * 1000L);
                trades.put(from, n); trades.put(id, n);
                p.sendMessage("§aTakas başladı. /takas para <n>, /takas esya (elindeki eşya), /takas onayla");
                f.sendMessage("§aTakas başladı.");
            }
            case "para" -> { if (ts == null || a.length < 2) { p.sendMessage("§cAktif takas yok."); return; } Long v = amount(p, a[1]); if (v == null) return;
                if (ledger.balance(mode, id) < v) { p.sendMessage("§cYetersiz bakiye."); return; }
                ts.setCoins(id, v); notifyBoth(ts, "§e" + p.getName() + " " + v + " para teklif etti. (onaylar sıfırlandı)"); }
            case "esya" -> { if (ts == null) { p.sendMessage("§cAktif takas yok."); return; }
                ItemStack it = p.getInventory().getItemInMainHand();
                if (it.getType() == Material.AIR || it.hasItemMeta()) { p.sendMessage("§cÖzel/isimli eşyalar takas edilemez; sade bir eşya tut."); return; }
                ts.setItem(id, it.getType().name(), it.getAmount()); notifyBoth(ts, "§e" + p.getName() + " " + it.getAmount() + "x " + it.getType().name() + " teklif etti."); }
            case "onayla" -> { if (ts == null) { p.sendMessage("§cAktif takas yok."); return; }
                ts.confirm(id);
                if (ts.bothConfirmed()) {
                    boolean ok = ts.execute(ledger, gateway);
                    notifyBoth(ts, ok ? "§aTakas tamamlandı." : "§cTakas başarısız (bakiye/eşya yetersiz); hiçbir şey değişmedi.");
                    trades.remove(ts.a); trades.remove(ts.b);
                } else p.sendMessage("§eOnayın alındı, karşı taraf bekleniyor."); }
            case "iptal" -> { if (ts != null) { ts.cancel(); notifyBoth(ts, "§cTakas iptal edildi."); trades.remove(ts.a); trades.remove(ts.b); } }
            default -> {
                Player t = Bukkit.getPlayerExact(a[0]);
                if (t == null || t.equals(p)) { p.sendMessage("§cGeçerli bir çevrimiçi oyuncu seç."); return; }
                tradeRequests.put(t.getUniqueId(), id);
                t.sendMessage("§e" + p.getName() + " takas istiyor: /takas kabul"); p.sendMessage("§aİstek gönderildi.");
                Bukkit.getScheduler().runTaskLater(plugin, () -> tradeRequests.remove(t.getUniqueId(), id), 20L * 60);
            }
        }
    }
    private void notifyBoth(TradeSession ts, String msg) {
        for (UUID u : List.of(ts.a, ts.b)) { Player pl = Bukkit.getPlayer(u); if (pl != null) pl.sendMessage(msg); }
    }

    private void market(Player p, String[] a) {
        if (a.length == 0) { p.sendMessage("§e/market liste | sat <fiyat> | al <id> | iptal <id> | acikartirma <baslangic> <dk> | teklif <id> <miktar>"); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "liste" -> { var list = market.active(); if (list.isEmpty()) p.sendMessage("§7Aktif ilan yok.");
                for (var li : list.stream().limit(15).toList()) p.sendMessage("§f#" + li.id() + " §7" + li.amount() + "x " + li.item() + " §a" + (li.auction() ? "AÇIK ARTIRMA en yüksek:" + li.topBid() : li.price())); }
            case "sat", "acikartirma" -> {
                if (a.length < 2) return; Long price = amount(p, a[1]); if (price == null) return;
                ItemStack it = p.getInventory().getItemInMainHand();
                if (it.getType() == Material.AIR || it.hasItemMeta()) { p.sendMessage("§cSade bir eşya tutmalısın."); return; }
                boolean auction = a[0].equalsIgnoreCase("acikartirma"); long mins = 60;
                if (auction && a.length > 2) { try { mins = Math.max(1, Math.min(1440, Long.parseLong(a[2]))); } catch (NumberFormatException ignored) {} }
                ItemStack take = new ItemStack(it.getType(), it.getAmount());
                if (!p.getInventory().removeItem(take).isEmpty()) { p.sendMessage("§cEşya alınamadı."); return; }
                long id = market.list(p.getUniqueId(), it.getType().name(), take.getAmount(), price, auction, mins * 60_000L);
                p.sendMessage("§aİlan #" + id + " oluşturuldu.");
            }
            case "al" -> { if (a.length < 2) return; Long id = amount(p, a[1]); if (id == null) return;
                var li = market.active().stream().filter(x -> x.id() == id).findFirst().orElse(null);
                if (li == null || !market.buyNow(id, p.getUniqueId())) { p.sendMessage("§cSatın alınamadı."); return; }
                gateway.give(p.getUniqueId(), li.item(), li.amount()); p.sendMessage("§aSatın alındı."); }
            case "teklif" -> { if (a.length < 3) return; Long id = amount(p, a[1]), v = amount(p, a[2]); if (id == null || v == null) return;
                p.sendMessage(market.bid(id, p.getUniqueId(), v) ? "§aTeklif verildi." : "§cTeklif geçersiz."); }
            case "iptal" -> { if (a.length < 2) return; Long id = amount(p, a[1]); if (id == null) return;
                var li = market.active().stream().filter(x -> x.id() == id).findFirst().orElse(null);
                if (li != null && market.cancel(id, p.getUniqueId())) { gateway.give(p.getUniqueId(), li.item(), li.amount()); p.sendMessage("§aİlan iptal, eşya iade."); } else p.sendMessage("§cİptal edilemedi."); }
            default -> p.sendMessage("§cBilinmeyen alt komut.");
        }
    }

    /** Açık artırma bitişlerini işler: kazanana eşya, satılmayana iade. */
    public void settleAuctions() {
        var before = market.active().stream().filter(AuctionHouse.Listing::auction).toList();
        var sold = market.settle();
        for (var sale : sold) { gateway.give(sale.buyer(), sale.item(), sale.amount()); }
        for (var li : before) {
            boolean stillThere = market.active().stream().anyMatch(x -> x.id() == li.id());
            boolean wasSold = sold.stream().anyMatch(x -> x.listingId() == li.id());
            if (!stillThere && !wasSold && li.topBidder() == null) gateway.give(li.seller(), li.item(), li.amount());
        }
    }
}
