#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if ! command -v java >/dev/null 2>&1; then echo 'HATA: Java bulunamadı. Java 21 kurun.' >&2; exit 1; fi
JAVA_MAJOR="$(java -version 2>&1 | awk -F '[".]' '/version/ {print $2; exit}')"
if [[ "$JAVA_MAJOR" != "21" ]]; then echo "UYARI: Java 21 önerilir; bulunan: $(java -version 2>&1 | head -1)" >&2; fi
./mvnw -U clean package
JAR="$ROOT/target/DobloSuite-6.0.0.jar"
if [[ ! -s "$JAR" ]]; then echo 'HATA: Beklenen JAR oluşmadı.' >&2; exit 2; fi
mkdir -p "$ROOT/dist"
cp "$JAR" "$ROOT/dist/DobloSuite-6.0.0.jar"
sha256sum "$ROOT/dist/DobloSuite-6.0.0.jar" > "$ROOT/dist/DobloSuite-6.0.0.jar.sha256"
echo "BAŞARILI: $ROOT/dist/DobloSuite-6.0.0.jar"
echo 'Not: JAR oluşturulması gerçek Paper sunucusunda çalışma garantisi değildir; sunucu testi ayrıca yapılmalıdır.'
