package xyz.doblosmp.anticheat;

import java.util.*;

/** Oyuncu başına, kontrol türü bazlı şüphe puanı. Zamanla azalır (yanlış pozitifleri törpüler). */
public final class Suspicion {
    public record Violation(long time, UUID player, String check, double points, double total, String detail) {}

    private final Map<UUID, Map<String, double[]>> scores = new HashMap<>(); // [puan, sonGüncelleme(ms)]
    private final double decayPerSecond;
    private final ArrayDeque<Violation> log = new ArrayDeque<>();
    private final int maxLog;

    public Suspicion(double decayPerSecond, int maxLog) { this.decayPerSecond = decayPerSecond; this.maxLog = maxLog; }

    public synchronized double add(UUID p, String check, double pts, String detail, long now) {
        double[] s = scores.computeIfAbsent(p, k -> new HashMap<>()).computeIfAbsent(check, k -> new double[]{0, now});
        s[0] = Math.max(0, s[0] - (now - s[1]) / 1000.0 * decayPerSecond) + pts; s[1] = now;
        log.addLast(new Violation(now, p, check, pts, s[0], detail));
        while (log.size() > maxLog) log.removeFirst();
        return s[0];
    }
    public synchronized double get(UUID p, String check, long now) {
        double[] s = scores.getOrDefault(p, Map.of()).get(check);
        return s == null ? 0 : Math.max(0, s[0] - (now - s[1]) / 1000.0 * decayPerSecond);
    }
    public synchronized double total(UUID p, long now) {
        double t = 0; for (String c : scores.getOrDefault(p, Map.of()).keySet()) t += get(p, c, now); return t;
    }
    public synchronized void reset(UUID p) { scores.remove(p); }
    public synchronized List<Violation> history(UUID p, int limit) {
        List<Violation> out = new ArrayList<>(); Iterator<Violation> it = log.descendingIterator();
        while (it.hasNext() && out.size() < limit) { Violation v = it.next(); if (p == null || v.player().equals(p)) out.add(v); }
        return out;
    }
}
