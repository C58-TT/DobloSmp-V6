# Java–Bedrock kurulumu (rehber — otomatik kurulum YAPILMADI)
1. Paper sürümüne uygun Geyser-Spigot ve Floodgate-Spigot'u yalnızca resmi kaynaklardan indir: https://geysermc.org/ ve https://github.com/GeyserMC/Floodgate
2. plugins/ içine koy, sunucuyu bir kez başlat ve kapat.
3. Geyser config.yml: bedrock.address=0.0.0.0, bedrock.port=19132 (UDP). Sağlayıcı panelinde UDP port tahsisi gerekir.
4. Floodgate key.pem dosyasını paylaşma. (Panel dosya gezgini bu dosyayı zaten göstermez.)
5. Floodgate Bedrock oyuncu adlarının başına "." ekler; panel ve komutlar bu öneki kabul eder.
6. Java ve Bedrock cihazlarından ayrı ayrı bağlanmayı test et. Bedrock'a özel form menüleri bu pakette YOKTUR.
