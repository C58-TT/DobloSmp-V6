package xyz.doblosmp.game;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public final class GameUtil {
    private GameUtil() {}
    public static void msg(Collection<UUID> ids, String m) { for (UUID u : ids) { Player p = Bukkit.getPlayer(u); if (p != null) p.sendMessage(m); } }
    @SuppressWarnings("deprecation") public static void title(Player p, String t, String s) { p.sendTitle(t, s, 5, 40, 10); }
    public static void give(Player p, ItemStack... it) { for (ItemStack rest : p.getInventory().addItem(it).values()) p.getWorld().dropItemNaturally(p.getLocation(), rest); }
    public static int count(Player p, Material m) { int n = 0; for (ItemStack s : p.getInventory().getContents()) if (s != null && s.getType() == m) n += s.getAmount(); return n; }
    /** Önce yeterliliği doğrular, sonra düşer; yetmezse hiçbir şey değişmez. */
    public static boolean take(Player p, Material m, int amount) {
        if (count(p, m) < amount) return false;
        return p.getInventory().removeItem(new ItemStack(m, amount)).isEmpty();
    }
    public static boolean near(Location a, Location b, double d) { return a.getWorld() == b.getWorld() && a.distanceSquared(b) <= d * d; }
    /** Arena noktalarının sınırlayıcı kutusu ± pad (oyun sonu temizliği için). */
    public static double[] bounds(ArenaStore.Arena a, double pad) {
        double[] b = {1e9, 1e9, 1e9, -1e9, -1e9, -1e9}; boolean any = false;
        List<Location> all = new ArrayList<>(); if (a.lobby != null) all.add(a.lobby); a.points.values().forEach(all::addAll);
        for (Location l : all) { any = true; b[0] = Math.min(b[0], l.getX()); b[1] = Math.min(b[1], l.getY()); b[2] = Math.min(b[2], l.getZ()); b[3] = Math.max(b[3], l.getX()); b[4] = Math.max(b[4], l.getY()); b[5] = Math.max(b[5], l.getZ()); }
        if (!any) return null; for (int i = 0; i < 3; i++) { b[i] -= pad; b[i + 3] += pad; } return b;
    }
    public static boolean inside(Location l, double[] b) { return b != null && l.getX() >= b[0] && l.getX() <= b[3] && l.getY() >= b[1] - 300 && l.getY() <= b[4] + 300 && l.getZ() >= b[2] && l.getZ() <= b[5]; }
}
