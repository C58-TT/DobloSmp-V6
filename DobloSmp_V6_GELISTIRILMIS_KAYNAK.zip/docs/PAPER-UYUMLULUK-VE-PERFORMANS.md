# Paper uyumluluk raporu
Durum: **DOĞRULANMADI.** Kod, gerçek `paper-api` yerine yerel stub'lara karşı derlendi. Gerçek derlemede çıkabilecek riskli çağrılar:
`ItemStack.serializeItemsAsBytes/deserializeItemsFromBytes`, `Player.sendTitle` (deprecated), `AsyncPlayerChatEvent` (deprecated), `PotionEffectType.HASTE`, `Enchantment.SHARPNESS/PROTECTION`, `Bukkit.getTPS()/getAverageTickTime()`, `Player.getPing()`, `BlockFormEvent`, `Bukkit.getOfflinePlayerIfCached`, `getPluginMeta()`, Floodgate/Cumulus yansıma çağrıları.
Yapılacak: `mvn clean package`, derleme hatalarını düzelt, test sunucusunda `/doblo`, arena kurulumu ve her mod için 2+ oyuncuyla deneme.
# Performans raporu
**Ölçüm yapılmadı.** Önlemler (kodda): chunk başına canlı sınırı, üretici eşya yığılma sınırı, sınırlı tick işi (blok sıfırlama/ada temizliği/tarama chunk-parça-parça), ana thread dışı SQL yazımı, 5 dk'da bir TPS/MSPT/RAM günlüğü + uyarı. Öneriler: `configs/paper-recommendations.md`.
