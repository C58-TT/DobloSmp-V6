package xyz.doblosmp.backup;

import java.nio.file.Path;

/** Sunucu KAPALIYKEN bekleyen geri yüklemeyi uygular: java -cp DobloSuite.jar xyz.doblosmp.backup.RestoreCli <sunucuKökü> (systemd ExecStartPre). */
public final class RestoreCli {
    public static void main(String[] a) throws Exception {
        Path root = Path.of(a.length > 0 ? a[0] : ".").toAbsolutePath().normalize();
        Path plugin = root.resolve("plugins/DobloSuite");
        BackupService bs = new BackupService(plugin.resolve("backups"), 14);
        int n = bs.applyStaged(plugin.resolve("restore-staging"), root, plugin);
        System.out.println(n == 0 ? "Bekleyen geri yükleme yok." : n + " dosya geri yüklendi. (Önceki dosyalar pre-restore yedeğinde.)");
    }
}
