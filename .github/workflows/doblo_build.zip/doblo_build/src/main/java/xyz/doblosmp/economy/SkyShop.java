package xyz.doblosmp.economy;

import java.util.*;

/**
 * SkyBlock marketi (/ada shop) — saf mantık. Fiyatlar config'ten (skyblock.shop.*) geçersiz kılınabilir.
 * Güvenlik: sunucu tarafı fiyat, yetersiz bakiye, dolu envanter, çift tıklama kilidi, geri alma (rollback).
 */
public final class SkyShop {
    public enum Category { TARIM("Tarım"), MADEN("Maden"), YAPI("Yapı Blokları"), MOB("Mob Drop"), SPAWNER("Spawner"), OZEL("Özel Eşyalar");
        public final String label; Category(String l) { label = l; } }

    /** buy < 0: satın alınamaz; sell < 0: satılamaz. Spawner için entity doludur. */
    public record Product(String id, Category cat, String material, String display, int amount, long buy, long sell, String entity) {
        public boolean canBuy() { return buy >= 0; }
        public boolean canSell() { return sell >= 0; }
    }

    public enum Result { OK, UNKNOWN, NOT_BUYABLE, NOT_SELLABLE, NO_FUNDS, INVENTORY_FULL, NOT_ENOUGH_ITEMS, BUSY, FAILED }

    /** Oyuncu envanteri soyutlaması (Paper tarafında Bukkit envanteri ile uygulanır). */
    public interface InventoryPort {
        int count(Product p);
        boolean canFit(Product p, int amount);
        boolean add(Product p, int amount);
        boolean remove(Product p, int amount);
    }

    private final Map<String, Product> products = new LinkedHashMap<>();
    private final Set<UUID> busy = new HashSet<>();

    public SkyShop() { defaults(); }

    private void add(String id, Category c, String mat, String disp, int amt, long buy, long sell) { products.put(id, new Product(id, c, mat, disp, amt, buy, sell, null)); }
    private void spawner(String id, String entity, String disp, long price) { products.put(id, new Product(id, Category.SPAWNER, "SPAWNER", disp, 1, price, -1, entity)); }

    private void defaults() {
        add("WHEAT", Category.TARIM, "WHEAT", "Buğday", 64, 320, 120);
        add("CARROT", Category.TARIM, "CARROT", "Havuç", 64, 320, 120);
        add("POTATO", Category.TARIM, "POTATO", "Patates", 64, 320, 120);
        add("SUGAR_CANE", Category.TARIM, "SUGAR_CANE", "Şeker Kamışı", 64, 400, 160);
        add("CACTUS", Category.TARIM, "CACTUS", "Kaktüs", 64, 350, 140);
        add("MELON_SLICE", Category.TARIM, "MELON_SLICE", "Karpuz Dilimi", 64, 300, 110);
        add("PUMPKIN", Category.TARIM, "PUMPKIN", "Balkabağı", 64, 300, 110);
        add("NETHER_WART", Category.TARIM, "NETHER_WART", "Nether Siğili", 64, 800, 320);
        add("COBBLESTONE", Category.MADEN, "COBBLESTONE", "Kırıktaş", 64, 64, 16);
        add("COAL", Category.MADEN, "COAL", "Kömür", 16, 160, 64);
        add("IRON_INGOT", Category.MADEN, "IRON_INGOT", "Demir Külçe", 16, 640, 240);
        add("GOLD_INGOT", Category.MADEN, "GOLD_INGOT", "Altın Külçe", 16, 800, 320);
        add("DIAMOND", Category.MADEN, "DIAMOND", "Elmas", 1, 500, 200);
        add("EMERALD", Category.MADEN, "EMERALD", "Zümrüt", 1, 750, 300);
        add("OBSIDIAN", Category.MADEN, "OBSIDIAN", "Obsidyen", 16, 1200, 300);
        add("DIRT", Category.YAPI, "DIRT", "Toprak", 64, 250, 30);
        add("GRASS_BLOCK", Category.YAPI, "GRASS_BLOCK", "Çim Bloğu", 16, 400, 50);
        add("OAK_LOG", Category.YAPI, "OAK_LOG", "Meşe Kütüğü", 64, 320, 100);
        add("SAND", Category.YAPI, "SAND", "Kum", 64, 300, 60);
        add("GRAVEL", Category.YAPI, "GRAVEL", "Çakıl", 64, 300, 60);
        add("GLASS", Category.YAPI, "GLASS", "Cam", 64, 400, 80);
        add("QUARTZ_BLOCK", Category.YAPI, "QUARTZ_BLOCK", "Kuvars Bloğu", 64, 960, 240);
        add("ROTTEN_FLESH", Category.MOB, "ROTTEN_FLESH", "Çürük Et", 64, -1, 90);
        add("BONE", Category.MOB, "BONE", "Kemik", 64, 300, 130);
        add("STRING", Category.MOB, "STRING", "İp", 64, 280, 110);
        add("GUNPOWDER", Category.MOB, "GUNPOWDER", "Barut", 64, 600, 220);
        add("ENDER_PEARL", Category.MOB, "ENDER_PEARL", "Ender İncisi", 16, 800, 320);
        add("BLAZE_ROD", Category.MOB, "BLAZE_ROD", "Blaze Çubuğu", 16, 1200, 480);
        add("WATER_BUCKET", Category.OZEL, "WATER_BUCKET", "Su Kovası", 1, 150, -1);
        add("LAVA_BUCKET", Category.OZEL, "LAVA_BUCKET", "Lav Kovası", 1, 350, -1);
        add("HOPPER", Category.OZEL, "HOPPER", "Huni", 1, 750, -1);
        spawner("ZOMBIE_SPAWNER", "ZOMBIE", "Zombi Spawner", 75_000);
        spawner("SKELETON_SPAWNER", "SKELETON", "İskelet Spawner", 75_000);
        spawner("SPIDER_SPAWNER", "SPIDER", "Örümcek Spawner", 120_000);
        spawner("CREEPER_SPAWNER", "CREEPER", "Creeper Spawner", 120_000);
        spawner("BLAZE_SPAWNER", "BLAZE", "Blaze Spawner", 250_000);
        spawner("IRON_GOLEM_SPAWNER", "IRON_GOLEM", "Demir Golem Spawner", 600_000);
    }

    /** Config'ten fiyat geçersiz kılma: id -> {alış, satış}. Negatif = devre dışı. Bilinmeyen id yok sayılır. */
    public int applyOverrides(Map<String, long[]> o) {
        int n = 0;
        for (var e : o.entrySet()) {
            Product p = products.get(e.getKey()); long[] v = e.getValue();
            if (p == null || v == null || v.length < 2) continue;
            long buy = v[0], sell = p.entity() != null ? -1 : v[1];
            products.put(p.id(), new Product(p.id(), p.cat(), p.material(), p.display(), p.amount(), buy, sell, p.entity())); n++;
        }
        return n;
    }

    public Product get(String id) { return products.get(id); }
    public List<Product> in(Category c) { return products.values().stream().filter(p -> p.cat() == c).toList(); }
    public Collection<Product> all() { return Collections.unmodifiableCollection(products.values()); }

    /** Satın alma: kilit -> kontroller -> para çek -> eşya ver (başarısızsa para iade). */
    public Result buy(Ledger ledger, String mode, UUID who, String id, InventoryPort inv) {
        Product p = products.get(id); if (p == null) return Result.UNKNOWN; if (!p.canBuy()) return Result.NOT_BUYABLE;
        if (!lock(who)) return Result.BUSY;
        try {
            if (!inv.canFit(p, p.amount())) return Result.INVENTORY_FULL;
            if (ledger.balance(mode, who) < p.buy()) return Result.NO_FUNDS;
            if (!ledger.withdraw(mode, who, p.buy(), "skyshop-buy:" + p.id())) return Result.NO_FUNDS;
            boolean given; try { given = inv.add(p, p.amount()); } catch (RuntimeException e) { given = false; }
            if (!given) { ledger.deposit(mode, who, p.buy(), "skyshop-refund:" + p.id()); return Result.FAILED; }
            return Result.OK;
        } finally { unlock(who); }
    }

    /** Satış: eşyayı al -> para ver (para verilemezse eşya iade). */
    public Result sell(Ledger ledger, String mode, UUID who, String id, InventoryPort inv) {
        Product p = products.get(id); if (p == null) return Result.UNKNOWN; if (!p.canSell()) return Result.NOT_SELLABLE;
        if (!lock(who)) return Result.BUSY;
        try {
            if (inv.count(p) < p.amount()) return Result.NOT_ENOUGH_ITEMS;
            if (!inv.remove(p, p.amount())) return Result.NOT_ENOUGH_ITEMS;
            if (!ledger.deposit(mode, who, p.sell(), "skyshop-sell:" + p.id())) { inv.add(p, p.amount()); return Result.FAILED; }
            return Result.OK;
        } finally { unlock(who); }
    }

    private synchronized boolean lock(UUID u) { return busy.add(u); }
    private synchronized void unlock(UUID u) { busy.remove(u); }

    public static String message(Result r) {
        return switch (r) {
            case OK -> "§aİşlem tamamlandı.";
            case UNKNOWN -> "§cBöyle bir ürün yok.";
            case NOT_BUYABLE -> "§cBu ürün satın alınamaz.";
            case NOT_SELLABLE -> "§cBu ürün satılamaz.";
            case NO_FUNDS -> "§cBakiyen yetersiz.";
            case INVENTORY_FULL -> "§cEnvanterin dolu; işlem iptal edildi.";
            case NOT_ENOUGH_ITEMS -> "§cYeterli eşyan yok.";
            case BUSY -> "§cÖnceki işlemin sürüyor, biraz bekle.";
            case FAILED -> "§cİşlem başarısız oldu; paran iade edildi.";
        };
    }
}
