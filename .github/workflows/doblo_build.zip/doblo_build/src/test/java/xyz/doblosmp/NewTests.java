package xyz.doblosmp;

import com.sun.net.httpserver.HttpServer;
import xyz.doblosmp.anticheat.Compat;
import xyz.doblosmp.backup.BackupService;
import xyz.doblosmp.bedwars.*;
import xyz.doblosmp.clan.ClanService;
import xyz.doblosmp.db.*;
import xyz.doblosmp.discord.DiscordNotifier;
import xyz.doblosmp.economy.*;
import xyz.doblosmp.quest.QuestEngine;
import xyz.doblosmp.sb.*;
import xyz.doblosmp.social.PartyService;


import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import java.security.cert.X509Certificate;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Logger;

/** İkinci test paketi (SkyBlock, Party, DB, Discord, Web ek özellikler, Backup staging). Çalıştır: java -cp ...:h2.jar xyz.doblosmp.NewTests */
public class NewTests {
    static int pass, fail;
    static void check(String n, boolean c) { if (c) pass++; else { fail++; System.out.println("BASARISIZ: " + n); } }
    static UUID u() { return UUID.randomUUID(); }

    public static void main(String[] a) throws Exception {
        skyblock(); party(); friends(); bedwarsUpgrade(); bwTeams(); compat(); db(); discord(); backupStaging(); 
        System.out.println("Yeni testler - Gecen: " + pass + "  Kalan: " + fail);
        if (fail == 0) System.exit(0);
        if (fail > 0) System.exit(1);
    }

    static void skyblock() {
        Set<String> seen = new HashSet<>();
        boolean uniq = true, inverse = true;
        for (int n = 0; n < 2000; n++) { int[] c = IslandGrid.cell(n); uniq &= seen.add(c[0] + "," + c[1]);
            int[] w = IslandGrid.center(n, 256); int[] back = IslandGrid.cellAt(w[0] + 100, w[1] - 100, 256); inverse &= back[0] == c[0] && back[1] == c[1]; }
        check("spiral 2000 yuva benzersiz", uniq); check("dünya koordinatından hücre geri bulunur", inverse);
        check("ilk yuvalar", Arrays.equals(IslandGrid.cell(0), new int[]{0, 0}) && Arrays.equals(IslandGrid.cell(1), new int[]{1, 0}));

        IslandRegistry r = new IslandRegistry(Set.of("classic", "desert"), 1000, 5000); IslandRegistry.Result[] o = new IslandRegistry.Result[1];
        UUID owner = u(), friend = u(), stranger = u(), mod = u();
        Island i = r.create(owner, "classic", o); check("ada oluştur", i != null && o[0] == IslandRegistry.Result.OK);
        check("ikinci ada engeli", r.create(owner, "classic", o) == null && o[0] == IslandRegistry.Result.HAS_ISLAND);
        check("bilinmeyen şablon", r.create(u(), "x", o) == null && o[0] == IslandRegistry.Result.UNKNOWN_TEMPLATE);
        long now = 10_000;
        check("davet", r.invite(owner, friend, now) == IslandRegistry.Result.OK);
        check("süresi dolan davet", r.accept(friend, now + 5000) == IslandRegistry.Result.NO_INVITE);
        r.invite(owner, friend, now); check("kabul", r.accept(friend, now + 10) == IslandRegistry.Result.OK && r.islandOf(friend) == i);
        check("üye davet edemez", r.invite(friend, stranger, now) == IslandRegistry.Result.NO_PERMISSION);
        check("rol ver + moderatör davet eder", r.setRole(owner, friend, Role.MODERATOR) == IslandRegistry.Result.OK && r.invite(friend, mod, now) == IslandRegistry.Result.OK);
        r.accept(mod, now);
        UUID filler0 = null; while (i.memberCount() < IslandUpgrades.MEMBER_LIMIT) { UUID f = u(); if (filler0 == null) filler0 = f; r.invite(owner, f, now); r.accept(f, now); }
        check("sabit üye limiti (8) dolunca davet reddi", i.memberCount() == 8 && r.invite(owner, u(), now) == IslandRegistry.Result.FULL);
        r.leave(filler0); r.invite(owner, stranger, now); r.accept(stranger, now);
        check("eşit/üst rol atılamaz", r.kick(mod, friend) == IslandRegistry.Result.NOT_MEMBER || r.kick(mod, friend) == IslandRegistry.Result.NO_PERMISSION);
        check("moderatör üyeyi atar", r.kick(friend, stranger) == IslandRegistry.Result.OK && r.islandOf(stranger) == null);
        check("sahip ayrılamaz", r.leave(owner) == IslandRegistry.Result.NOT_MEMBER); check("üye ayrılır", r.leave(mod) == IslandRegistry.Result.OK);
        // koruma
        check("sahip kırar", Protection.allowed(i, owner, Protection.Action.BREAK, false));
        check("ziyaretçi kıramaz", !Protection.allowed(i, stranger, Protection.Action.BREAK, false));
        check("ziyaretçi sandık açamaz", !Protection.allowed(i, stranger, Protection.Action.CONTAINER, false));
        check("ziyaretçi hayvana dokunamaz", !Protection.allowed(i, stranger, Protection.Action.ANIMAL, false));
        check("ziyaretçi kapı: varsayılan kapalı", !Protection.allowed(i, stranger, Protection.Action.DOOR, false));
        r.setFlag(owner, "visitor_doors", true); check("ayar açılınca kapı", Protection.allowed(i, stranger, Protection.Action.DOOR, false));
        check("PvP varsayılan kapalı", !Protection.allowed(i, stranger, Protection.Action.PVP, false));
        check("bypass yetkisi", Protection.allowed(i, stranger, Protection.Action.BREAK, true));
        check("ada dışı serbest", Protection.allowed(null, stranger, Protection.Action.BREAK, false));
        // ban/ziyaret
        check("ban", r.ban(owner, stranger) == IslandRegistry.Result.OK && !Protection.allowed(i, stranger, Protection.Action.DOOR, false));
        check("banlı ziyaret edemez", r.canVisit(stranger, i) == IslandRegistry.Result.BANNED);
        check("üye banlanamaz", r.ban(owner, friend) == IslandRegistry.Result.INVALID); check("unban", r.unban(owner, stranger) == IslandRegistry.Result.OK);
        r.setFlag(owner, "visitors", false); check("ziyaret kapalıyken reddedilir", r.canVisit(stranger, i) == IslandRegistry.Result.NO_PERMISSION);
        check("üye yine girer", r.canVisit(friend, i) == IslandRegistry.Result.OK);
        r.setFlag(owner, "visitors", true);
        check("geçersiz ayar", r.setFlag(owner, "hack", true) == IslandRegistry.Result.INVALID);
        check("özel izin: üyeye sandık kapat", r.setRequired(owner, Perm.CONTAINERS, Role.MODERATOR) == IslandRegistry.Result.OK && r.islandOf(owner) != null);
        UUID plain = u(); r.invite(owner, plain, now); r.accept(plain, now);
        check("üye artık sandık açamaz", !Protection.allowed(i, plain, Protection.Action.CONTAINER, false));
        check("ziyaretçiye yalnızca kapı verilebilir", r.setRequired(owner, Perm.BREAK, Role.VISITOR) == IslandRegistry.Result.INVALID);
        // değerlendirme
        check("puan", r.rate(stranger, i, 5) == IslandRegistry.Result.OK && r.rate(owner, i, 5) == IslandRegistry.Result.SELF && r.rate(stranger, i, 9) == IslandRegistry.Result.INVALID);
        check("ortalama", i.avgRating() == 5.0);
        // ada seviyesi/puanı/yükseltme sistemi YOKTUR: yarıçap ve üye limiti sabit
        check("sabit yarıçap", IslandUpgrades.radius(i) == IslandUpgrades.RADIUS && IslandUpgrades.memberLimit(i) == 8);
        boolean noLevelFields = true; for (var f : Island.class.getFields()) { String n = f.getName().toLowerCase(); if (n.contains("level") || n.contains("lvl") || n.contains("worth")) noLevelFields = false; }
        check("Island'da seviye/puan alanı yok", noLevelFields);
        boolean noUpgradeApi = true; for (var m : IslandRegistry.class.getMethods()) if (m.getName().equals("upgrade") || m.getName().equals("top")) noUpgradeApi = false;
        check("IslandRegistry'de upgrade/top yok", noUpgradeApi);
        // devir, sıfırlama, silme, sıralama
        check("sıfırlama", r.reset(owner, 100_000) == IslandRegistry.Result.OK && i.members.size() > 0);
        check("sıfırlama bekleme süresi", r.reset(owner, 101_000) == IslandRegistry.Result.COOLDOWN);
        check("devir", r.transfer(owner, friend) == IslandRegistry.Result.OK && i.owner.equals(friend) && i.roleOf(owner) == Role.MODERATOR);
        check("eski sahip silemez", r.delete(owner) == IslandRegistry.Result.NOT_OWNER);
        Island j = r.create(u(), "desert", o); check("ikinci ada oluşur", j != null);
        int slotBefore = i.slot; check("silme", r.delete(friend) == IslandRegistry.Result.OK && r.islandOf(friend) == null && r.islandOf(owner) == null);
        Island k2 = r.create(u(), "classic", o); check("silinen yuva yeniden kullanılır", k2.slot == slotBefore);
    }

    static void party() {
        PartyService p = new PartyService(3, 1000); UUID a = u(), b = u(), c = u(), d = u(); long t = 100;
        check("davet", p.invite(a, b, t)); check("kabul", p.accept(b, t + 1) && p.of(b) == p.of(a));
        check("süresi dolan davet", p.invite(a, c, t) && !p.accept(c, t + 5000));
        check("üye davet edemez", !p.invite(b, c, t)); p.invite(a, c, t); p.accept(c, t); check("kapasite", !p.invite(a, d, t));
        check("lider olmayan atamaz", !p.kick(b, c)); check("lider atar", p.kick(a, c));
        check("devir", p.transfer(a, b) && p.of(a).leader.equals(b));
        check("lider ayrılınca parti dağılır (1 kişi kalır)", p.leave(b) && p.of(a) == null);
        p.invite(a, b, t); p.accept(b, t); check("dağıtma", p.disband(a) && p.of(b) == null);
    }

    static void friends() {
        xyz.doblosmp.social.FriendService f = new xyz.doblosmp.social.FriendService(2, 1000); UUID a = u(), b = u(), c = u(), d = u(); long t = 100;
        check("istek", f.request(a, b, t) && !f.areFriends(a, b)); check("kabul", f.accept(b, a, t + 1) && f.areFriends(a, b) && f.areFriends(b, a));
        check("süresi dolan istek", f.request(c, a, t) && !f.accept(a, c, t + 5000));
        check("karşılıklı istek otomatik kabul", f.request(c, d, t) && f.request(d, c, t + 1) && f.areFriends(c, d));
        xyz.doblosmp.social.FriendService g = new xyz.doblosmp.social.FriendService(1, 1000); UUID x = u(), y = u(), z = u(); g.request(x, y, t); g.accept(y, x, t);
        check("üst sınır: dolu listeye istek reddedilir", !g.request(x, z, t)); check("kendine istek yok", !f.request(a, a, t));
        check("sil", f.remove(a, b) && !f.areFriends(b, a)); check("bekleyenler", f.request(d, a, t) && f.pending(a, t).contains(d));
    }

    static void bedwarsUpgrade() {
        UUID x = u(), y = u(); BedwarsMatch m = CoreTests.started(x, y);
        int[] diamonds = {5};
        check("envanterden ödeme", m.upgradeTeam(x, BedwarsMatch.Upgrade.SHARPNESS, c -> { if (diamonds[0] < c) return false; diamonds[0] -= c; return true; }) && diamonds[0] == 1 && m.teamOf(x).sharpness == 1);
        check("ödeyemezse uygulanmaz", !m.upgradeTeam(x, BedwarsMatch.Upgrade.PROTECTION, c -> diamonds[0] >= c) && m.teamOf(x).protection == 0);
    }

    static void bwTeams() {
        BedwarsMatch m = new BedwarsMatch(BedwarsMode.SOLO); UUID a = u(), b = u(), c = u(); m.join(a, null); m.join(b, null); m.join(c, null);
        check("dolu takıma geçilemez", !m.switchTeam(c, m.teamOf(a).index)); int free = 7; check("boş takıma geçilir", m.switchTeam(c, free) && m.teamOf(c).index == free);
        check("aynı takıma geçiş false", !m.switchTeam(c, free)); for (int i = 0; i < 5; i++) m.join(u(), null); m.startCountdown(2); m.begin(new Random(2)); check("maç başlayınca değiştirilemez", !m.switchTeam(c, 3));
        check("forge üretimi hızlandırır", BedwarsMatch.ironIntervalTicks(2) < BedwarsMatch.ironIntervalTicks(0) && BedwarsMatch.emeraldIntervalTicks(3) < BedwarsMatch.emeraldIntervalTicks(1));
    }

    static void compat() {
        check("Grim varsa tamamlayıcı mod", Compat.detect(Set.of("GrimAC", "Vault"), "auto") == Compat.Mode.COMPLEMENT);
        check("Grim yoksa bağımsız", Compat.detect(Set.of("Vault"), "auto") == Compat.Mode.STANDALONE);
        check("zorla bağımsız", Compat.detect(Set.of("GrimAC"), "standalone") == Compat.Mode.STANDALONE);
        check("tamamlayıcı modda speed kapalı, xray açık", !Compat.checkActive(Compat.Mode.COMPLEMENT, "speed") && Compat.checkActive(Compat.Mode.COMPLEMENT, "xray"));
    }

    static void db() throws Exception {
        String real = System.getProperty("doblo.test.jdbc");        // -Ddoblo.test.jdbc=jdbc:mariadb://127.0.0.1:3306/doblotest  (gerçek MariaDB'ye karşı çalıştır)
        Database d = real != null ? new Database(real, System.getProperty("doblo.test.user", "doblo"), System.getProperty("doblo.test.pass", ""), 4, Logger.getLogger("t"), "org.mariadb.jdbc.Driver", NewTests.class.getClassLoader())
            : new Database("jdbc:h2:mem:t" + System.nanoTime() + ";MODE=MariaDB;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1", "sa", "", 4, Logger.getLogger("t"), "org.h2.Driver", NewTests.class.getClassLoader());
        d.migrate("/db/V1__init.sql"); d.migrate("/db/V1__init.sql");                         // ikinci çağrı no-op olmalı
        check("migration bir kez uygulanır", d.read(c -> { try (var s = c.createStatement(); var rs = s.executeQuery("SELECT COUNT(*) FROM schema_version")) { rs.next(); return rs.getInt(1); } }) == 1);
        SqlStore st = new SqlStore(d);
        Ledger l = new Ledger(100); UUID p = u(), q = u(); l.deposit("sb", p, 500, "t"); l.transfer("sb", p, q, 120, "pay");
        st.saveBalances(l.snapshot()); Ledger l2 = new Ledger(10); l2.restore(st.loadBalances());
        check("bakiye kaydı gidiş-dönüş", l2.balance("sb", p) == 380 && l2.balance("sb", q) == 120 && l2.audit("sb"));
        st.appendLedger(l.history(p, 10)); check("ledger günlüğü", st.ledgerCount() == 2);
        // rollback: ikinci insert PK ihlali -> ilk insert da geri alınmalı
        try { d.tx(c -> { try (var ps = c.prepareStatement("INSERT INTO mutes(player,until_ts) VALUES(?,?)")) { ps.setString(1, "x"); ps.setLong(2, 1); ps.executeUpdate(); ps.setString(1, "x"); ps.executeUpdate(); } return null; }); } catch (Exception expected) {}
        check("hata olunca işlem geri alınır", st.loadMutes().isEmpty());
        // SQL enjeksiyonu: parametreli sorgu
        st.addPunishment(1, "ban", "x'; DROP TABLE punishments;--", "r", 0, "s"); check("enjeksiyon etkisiz, tablo yaşıyor", st.punishments("", 10).size() == 1);
        st.setMute("Ali", 99); check("mute", st.loadMutes().get("ali") == 99L); st.setMute("Ali", -1); check("unmute", st.loadMutes().isEmpty());
        ClanService cs = new ClanService(10); UUID l1 = u(); cs.create(l1, "DBL", "Doblo"); cs.recordWar("DBL", "DBL", 1);
        st.saveClans(cs.all()); ClanService cs2 = new ClanService(10); st.loadClans(cs2); check("klan kaydı", cs2.byTag("DBL") != null && cs2.of(l1) != null);
        Ledger lm = new Ledger(10); AuctionHouse ah = new AuctionHouse(lm, "sb", 0.05); ah.list(p, "DIAMOND", 2, 50, false, 60_000);
        st.saveAuctions(ah.active()); AuctionHouse ah2 = new AuctionHouse(lm, "sb", 0.05); st.loadAuctions(ah2); check("açık artırma kaydı", ah2.active().size() == 1 && ah2.active().get(0).item().equals("DIAMOND"));
        IslandRegistry reg = new IslandRegistry(Set.of("classic"), 1000, 1000); IslandRegistry.Result[] o = new IslandRegistry.Result[1];
        Island is = reg.create(p, "classic", o); reg.invite(p, q, 0); reg.accept(q, 0); is.bans.add(u()); is.ratings.put(q, 4); is.flags.put("pvp", true); is.required.put(Perm.BREAK, Role.MODERATOR);
        st.saveIslands(reg.all()); IslandRegistry reg2 = new IslandRegistry(Set.of("classic"), 1000, 1000); st.loadIslands(reg2);
        Island b = reg2.islandOf(q); check("ada kaydı", b != null && b.owner.equals(p) && b.flags.get("pvp") && b.required.get(Perm.BREAK) == Role.MODERATOR && b.bans.size() == 1 && b.ratings.get(q) == 4);
        QuestEngine qe = new QuestEngine("S1", 100); qe.register(new QuestEngine.Quest("k", "m", 5, QuestEngine.Period.DAILY, 10, 5, null)); qe.add(p, "m", 3, LocalDate.of(2026, 11, 17)); qe.dailyLogin(p, LocalDate.of(2026, 11, 17)); qe.grantAchievement(p, "ilk");
        st.saveQuests(qe); QuestEngine q2 = new QuestEngine("S1", 100); q2.register(new QuestEngine.Quest("k", "m", 5, QuestEngine.Period.DAILY, 10, 5, null)); st.loadQuests(q2);
        check("görev kaydı", q2.progress(p, "k", LocalDate.of(2026, 11, 17)) == 3 && q2.of(p).streak == 1 && q2.of(p).achievements.contains("ilk"));
        st.addStat(p, "bw", "wins", 1); st.addStat(p, "bw", "wins", 2); check("istatistik", st.stat(p, "bw", "wins") == 3);
        st.setElo(p, "nodebuff", 1016); st.setElo(p, "nodebuff", 1030); check("elo", st.elo(p, "nodebuff") == 1030 && st.elo(q, "nodebuff") == 1000);
        st.touchPlayer(p, "Ali", true, 5); st.touchPlayer(p, "Ali", true, 5); st.addDuelHistory("nodebuff", p, q, 16, true); st.addBackupHistory("b.zip", true, "ok"); check("yedek geçmişi", st.backupHistory(5).size() == 1);
        st.saveFriends(Map.of(p, Set.of(q), q, Set.of(p))); check("arkadaşlar", st.loadFriends().get(p).contains(q));
        // eşzamanlı: 8 iş parçacığı, havuz 4
        ExecutorService ex = Executors.newFixedThreadPool(8); List<Future<?>> fs = new ArrayList<>();
        for (int n = 0; n < 40; n++) fs.add(ex.submit(() -> { try { st.addStat(q, "mm", "kills", 1); } catch (Exception e) { throw new RuntimeException(e); } }));
        for (Future<?> f : fs) f.get(); ex.shutdown();
        check("eşzamanlı yazma kaybı yok", st.stat(q, "mm", "kills") == 40);
        for (int round = 0; round < 5; round++) { UUID fresh = u(); ExecutorService e2 = Executors.newFixedThreadPool(8); List<Future<?>> f2 = new ArrayList<>();
            for (int n = 0; n < 16; n++) f2.add(e2.submit(() -> { try { st.addStat(fresh, "bw", "wins", 1); st.touchPlayer(fresh, "X", false, 2); st.setElo(fresh, "k", 1100); } catch (Exception e) { throw new RuntimeException(e); } }));
            for (Future<?> f : f2) f.get(); e2.shutdown(); if (st.stat(fresh, "bw", "wins") != 16 || st.elo(fresh, "k") != 1100) { check("yeni satıra eşzamanlı ilk yazım", false); break; } }
        check("yeni satıra eşzamanlı ilk yazım (5 tur x 16 iş parçacığı)", true);
        d.async(c -> { try (var ps = c.prepareStatement("INSERT INTO mutes(player,until_ts) VALUES('async',5)")) { ps.executeUpdate(); } return null; }).get();
        check("asenkron yazma", st.loadMutes().containsKey("async"));
        d.close();
    }

    static void discord() throws Exception {
        BlockingQueue<String> got = new LinkedBlockingQueue<>(); int[] hits = {0};
        HttpServer hs = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        hs.createContext("/hook", ex -> { String body = new String(ex.getRequestBody().readAllBytes()); if (hits[0]++ == 0) { ex.getResponseHeaders().add("Retry-After", "0.1"); ex.sendResponseHeaders(429, -1); }
            else { got.add(body + "|" + ex.getRequestHeaders().getFirst("Authorization")); ex.sendResponseHeaders(204, -1); } ex.close(); });
        hs.start(); String base = "http://127.0.0.1:" + hs.getAddress().getPort();
        try (DiscordNotifier n = new DiscordNotifier(base + "/hook", null, null, null, 10, Logger.getLogger("t"))) {
            n.send(DiscordNotifier.Kind.MOD, "Ban", "@everyone <@123456> \"tırnak\"\nsatır");
            String body = got.poll(5, TimeUnit.SECONDS); for (int w = 0; w < 40 && n.sent < 1; w++) Thread.sleep(50);
            check("429 sonrası yeniden denendi ve gönderildi", body != null && n.sent == 1);
            check("allowed_mentions boş", body != null && body.contains("\"allowed_mentions\":{\"parse\":[]}"));
            check("@everyone etkisizleştirildi", body != null && !body.contains("@everyone") && !body.contains("<@123456>"));
            check("JSON kaçışı", body != null && body.contains("\\\"tırnak\\\"") && body.contains("\\n"));
        }
        BlockingQueue<String> got2 = new LinkedBlockingQueue<>();
        hs.removeContext("/hook"); hs.createContext("/channels/42/messages", ex -> { got2.add(ex.getRequestHeaders().getFirst("Authorization")); ex.sendResponseHeaders(200, -1); ex.close(); });
        try (DiscordNotifier n = new DiscordNotifier(null, "TESTTOKEN", "42", base, 10, Logger.getLogger("t"))) { n.send(DiscordNotifier.Kind.INFO, "a", "b"); check("bot modu Authorization başlığı", "Bot TESTTOKEN".equals(got2.poll(5, TimeUnit.SECONDS))); }
        DiscordNotifier off = new DiscordNotifier("", "", "", null, 10, Logger.getLogger("t")); off.send(DiscordNotifier.Kind.INFO, "a", "b"); check("yapılandırma yoksa devre dışı", !off.enabled());
        hs.stop(0);
    }

    static void backupStaging() throws Exception {
        Path root = Files.createTempDirectory("srv"); Path plug = root.resolve("plugins/DobloSuite"); Files.createDirectories(plug.resolve("backups")); Files.createDirectories(root.resolve("world"));
        Files.writeString(root.resolve("world/level.dat"), "ESKI"); Files.writeString(plug.resolve("economy.yml"), "eski-eko");
        Path src = Files.createTempDirectory("src"); Files.createDirectories(src.resolve("world")); Files.writeString(src.resolve("world/level.dat"), "YENI");
        Path pd = Files.createTempDirectory("pd"); Files.writeString(pd.resolve("economy.yml"), "yeni-eko");
        BackupService bs = new BackupService(plug.resolve("backups"), 10); Path z = bs.create("t", new LinkedHashMap<>(Map.of("server/world", src.resolve("world"), "plugin-data", pd)));
        Path staging = plug.resolve("restore-staging"); bs.stageRestore(z, staging);
        check("staging canlı dosyaya dokunmaz", Files.readString(root.resolve("world/level.dat")).equals("ESKI") && Files.exists(staging.resolve("PENDING")));
        int n = bs.applyStaged(staging, root, plug);
        check("uygulandı", n == 2 && Files.readString(root.resolve("world/level.dat")).equals("YENI") && Files.readString(plug.resolve("economy.yml")).equals("yeni-eko"));
        check("PENDING silindi", !Files.exists(staging.resolve("PENDING")) && bs.applyStaged(staging, root, plug) == 0);
        check("öncesi yedeklendi", bs.list().stream().anyMatch(p -> p.getFileName().toString().startsWith("pre-restore") && bs.verify(p)));
        // bozuk yedek staging'e alınmaz
        byte[] b = Files.readAllBytes(z); b[b.length / 2] ^= 0x33; Path bad = plug.resolve("backups/bozuk.zip"); Files.write(bad, b);
        boolean threw = false; try { bs.stageRestore(bad, staging); } catch (IOException e) { threw = true; }
        check("bozuk yedek reddedilir, canlı veri değişmez", threw && Files.readString(root.resolve("world/level.dat")).equals("YENI"));
    }



}
