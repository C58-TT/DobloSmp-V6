package xyz.doblosmp.game;

import java.util.*;

/** Bir oyuncunun aynı anda yalnızca tek bir etkinlikte (kuyruk/BedWars/Duels/Murder) bulunmasını sağlar. */
public final class Activities {
    public enum Kind { BEDWARS, DUELS, MURDER, DUEL_QUEUE }
    private static final Map<UUID, Kind> current = new HashMap<>();
    private Activities() {}
    public static synchronized boolean enter(UUID p, Kind k) { return current.putIfAbsent(p, k) == null; }
    public static synchronized void leave(UUID p, Kind k) { current.remove(p, k); }
    public static synchronized void force(UUID p, Kind k) { current.put(p, k); }
    public static synchronized Kind of(UUID p) { return current.get(p); }
    public static synchronized boolean busy(UUID p) { return current.containsKey(p); }
}
