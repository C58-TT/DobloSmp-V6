# Android üzerinden kurulum notu

Android dosya yöneticisiyle kaynak ZIP'i açabilir ve dosyaları düzenleyebilirsin; ancak bu ZIP bir JAR değildir. Android'de derleme ortamı kurmadan Saganetwork `plugins` klasörüne yükleme. En güvenlisi Java 21 + Maven ile bilgisayarda veya ayrı bir build ortamında `mvn clean package` çalıştırıp oluşan JAR'ı yüklemektir. Önce tam yedek al ve ayrı test sunucusunda dene.
