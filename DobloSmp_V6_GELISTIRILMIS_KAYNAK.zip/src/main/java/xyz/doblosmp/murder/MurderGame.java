package xyz.doblosmp.murder;

import java.util.*;
import java.util.function.ToDoubleFunction;

/** Murder Mystery saf oyun mantığı: rol dağıtımı, ölüm, yay düşürme, kazanma koşulları. */
public final class MurderGame {
    public enum Role { MURDERER, DETECTIVE, INNOCENT }
    public enum Winner { NONE, MURDERER, INNOCENTS }

    private final Map<UUID, Role> roles = new LinkedHashMap<>();
    private final Set<UUID> alive = new HashSet<>();
    private final long endsAt;
    private boolean bowDropped;
    private UUID bowHolder;
    private Winner result = Winner.NONE;

    public MurderGame(Collection<UUID> players, Random rng, long durationMs) {
        this(players, p -> 1.0, p -> 1.0, rng, durationMs);
    }

    /** Şerif ve katil ayrı ağırlıklarla seçilir; yüzdelerin toplamının 100 olması gerekmez. */
    public MurderGame(Collection<UUID> players, ToDoubleFunction<UUID> sheriffWeight,
                      ToDoubleFunction<UUID> murdererWeight, Random rng, long durationMs) {
        if (players.size() < 5) throw new IllegalArgumentException("Murder Mystery en az 5 oyuncu gerektirir");
        List<UUID> remaining = new ArrayList<>(players);
        UUID murderer = weightedPick(remaining, murdererWeight, rng);
        roles.put(murderer, Role.MURDERER);
        remaining.remove(murderer);
        UUID sheriff = weightedPick(remaining, sheriffWeight, rng);
        roles.put(sheriff, Role.DETECTIVE);
        bowHolder = sheriff;
        for (UUID player : remaining) if (!player.equals(sheriff)) roles.put(player, Role.INNOCENT);
        alive.addAll(roles.keySet());
        endsAt = System.currentTimeMillis() + durationMs;
    }

    private static UUID weightedPick(List<UUID> players, ToDoubleFunction<UUID> weight, Random rng) {
        double total = 0;
        for (UUID p : players) total += Math.max(0.0001, weight.applyAsDouble(p));
        double roll = rng.nextDouble() * total;
        for (UUID p : players) { roll -= Math.max(0.0001, weight.applyAsDouble(p)); if (roll < 0) return p; }
        return players.get(players.size() - 1);
    }

    public Role role(UUID p) { return roles.get(p); }
    public boolean isAlive(UUID p) { return alive.contains(p); }
    public Set<UUID> alive() { return Collections.unmodifiableSet(alive); }
    public Winner winner() { return result; }
    public boolean bowDropped() { return bowDropped; }
    public UUID bowHolder() { return bowHolder; }

    /** killer, victim'i öldürdü (kılıç veya ok). Masum masumu vurursa killer da ölür. */
    public Winner kill(UUID killer, UUID victim) {
        if (result != Winner.NONE || !alive.contains(victim) || (killer != null && !alive.contains(killer))) return result;
        alive.remove(victim);
        if (victim.equals(bowHolder)) { bowHolder = null; bowDropped = true; }
        if (killer != null && roles.get(killer) != Role.MURDERER && roles.get(victim) == Role.INNOCENT) {
            alive.remove(killer);                       // masumu vuran masum cezalandırılır
            if (killer.equals(bowHolder)) { bowHolder = null; bowDropped = true; }
        }
        return evaluate();
    }

    /** Yay yerden alındı (yalnızca yaşayan masum/dedektif). */
    public boolean pickupBow(UUID p) {
        if (!bowDropped || !alive.contains(p) || roles.get(p) == Role.MURDERER) return false;
        bowHolder = p; bowDropped = false; return true;
    }

    public Winner leave(UUID p) { alive.remove(p); return evaluate(); }

    public Winner tick() {
        if (result == Winner.NONE && System.currentTimeMillis() > endsAt) result = Winner.INNOCENTS;
        return result;
    }

    private Winner evaluate() {
        UUID m = roles.entrySet().stream().filter(e -> e.getValue() == Role.MURDERER).map(Map.Entry::getKey).findFirst().orElse(null);
        boolean murdererAlive = m != null && alive.contains(m);
        long others = alive.stream().filter(u -> !u.equals(m)).count();
        if (!murdererAlive) result = Winner.INNOCENTS;
        else if (others == 0) result = Winner.MURDERER;
        return result;
    }
}
