package xyz.doblosmp.game;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** arenas.yml: tüm oyun arenalarının kalıcı yapılandırması. Konumlar "dünya;x;y;z;yaw;pitch" biçiminde. */
public final class ArenaStore {
    public static final class Arena {
        public final String name, type; public String mode = "SOLO", lobbyWorld; public boolean enabled; public int minPlayers = 2, maxPlayers = 8;
        public Location lobby; public final Map<String, List<Location>> points = new LinkedHashMap<>();    // "spawn:KIRMIZI", "bed:KIRMIZI", "gen:IRON:KIRMIZI", "gen:DIAMOND", "shop:KIRMIZI", "upgrade:KIRMIZI", "spawn" (duels 1/2), "gold", "spectator"
        Arena(String n, String t) { name = n; type = t; }
        public List<Location> pts(String k) { return points.getOrDefault(k, List.of()); }
        public Location first(String k) { var l = points.get(k); return l == null || l.isEmpty() ? null : l.get(0); }
        public void add(String k, Location l) { points.computeIfAbsent(k, x -> new ArrayList<>()).add(l); }
    }
    private final JavaPlugin plugin; private final File file; private final Map<String, Arena> arenas = new LinkedHashMap<>();
    public ArenaStore(JavaPlugin p) { plugin = p; file = new File(p.getDataFolder(), "arenas.yml"); load(); }
    public Arena get(String n) { return arenas.get(n.toLowerCase(Locale.ROOT)); }
    public Collection<Arena> all() { return arenas.values(); }
    public Arena create(String name, String type) { String k = name.toLowerCase(Locale.ROOT); if (arenas.containsKey(k) || !name.matches("[A-Za-z0-9_-]{2,24}")) return null; Arena a = new Arena(k, type); arenas.put(k, a); save(); return a; }
    public boolean delete(String n) { boolean r = arenas.remove(n.toLowerCase(Locale.ROOT)) != null; if (r) save(); return r; }

    static String enc(Location l) { return l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ() + ";" + l.getYaw() + ";" + l.getPitch(); }
    static Location dec(String s) { String[] c = s.split(";"); var w = Bukkit.getWorld(c[0]); if (w == null || c.length < 6) return null; return new Location(w, Double.parseDouble(c[1]), Double.parseDouble(c[2]), Double.parseDouble(c[3]), Float.parseFloat(c[4]), Float.parseFloat(c[5])); }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Arena a : arenas.values()) {
            String b = a.name + "."; y.set(b + "type", a.type); y.set(b + "mode", a.mode); y.set(b + "enabled", a.enabled); y.set(b + "min", a.minPlayers); y.set(b + "max", a.maxPlayers);
            if (a.lobby != null) y.set(b + "lobby", enc(a.lobby));
            a.points.forEach((k, v) -> y.set(b + "points." + k, v.stream().map(ArenaStore::enc).toList()));
        }
        try { plugin.getDataFolder().mkdirs(); y.save(file); } catch (IOException e) { plugin.getLogger().severe("arenas.yml yazılamadı: " + e.getMessage()); }
    }
    public void load() {
        arenas.clear(); YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String n : y.getKeys(false)) {
            try {
                ConfigurationSection s = y.getConfigurationSection(n); Arena a = new Arena(n, s.getString("type", "BEDWARS")); a.mode = s.getString("mode", "SOLO"); a.enabled = s.getBoolean("enabled"); a.minPlayers = s.getInt("min", 2); a.maxPlayers = s.getInt("max", 8);
                if (s.getString("lobby") != null) a.lobby = dec(s.getString("lobby"));
                ConfigurationSection pts = s.getConfigurationSection("points");
                if (pts != null) for (String k : pts.getKeys(false)) { List<Location> l = new ArrayList<>(); for (String e : pts.getStringList(k)) { Location x = dec(e); if (x != null) l.add(x); } a.points.put(k, l); }
                arenas.put(n, a);
            } catch (RuntimeException e) { plugin.getLogger().warning("Bozuk arena atlandı: " + n); }
        }
    }
}
