package xyz.doblosmp.duels;

import java.util.*;

/**
 * Duels Elo hesabı ve lig sistemi (saf mantık, Paper'dan bağımsız).
 * Ligler: Bakır, Demir, Altın, Elmas, Zümrüt, Netherite. Sınırlar config'ten yüklenebilir.
 */
public final class Elo {
    private Elo() {}
    public static final int START = 1000;
    public static final int MIN_ELO = 0;

    /** Lig: ad, renk kodu, alt Elo sınırı (dahil). */
    public record League(String name, String color, int min) {}

    private static final List<League> DEFAULT_LEAGUES = List.of(
            new League("Bakır", "§6", 0), new League("Demir", "§f", 900), new League("Altın", "§e", 1100),
            new League("Elmas", "§b", 1300), new League("Zümrüt", "§a", 1500), new League("Netherite", "§8", 1750));
    private static volatile List<League> leagues = DEFAULT_LEAGUES;

    /** Config'ten yüklenen lig tablosu. Geçersizse (boş, sırasız, ilki 0 değil) varsayılan korunur. */
    public static boolean setLeagues(List<League> l) {
        if (l == null || l.size() < 2 || l.get(0).min() != 0) return false;
        for (int i = 1; i < l.size(); i++) if (l.get(i).min() <= l.get(i - 1).min()) return false;
        leagues = List.copyOf(l); return true;
    }
    public static void resetLeagues() { leagues = DEFAULT_LEAGUES; }
    public static List<League> leagues() { return leagues; }

    public static int leagueIndex(int elo) {
        List<League> l = leagues; int idx = 0;
        for (int i = 0; i < l.size(); i++) if (elo >= l.get(i).min()) idx = i;
        return idx;
    }
    public static League leagueOf(int elo) { return leagues.get(leagueIndex(elo)); }
    public static String league(int elo) { return leagueOf(elo).name(); }
    public static String coloredLeague(int elo) { League l = leagueOf(elo); return l.color() + l.name(); }

    /** Klasik Elo beklentisi farkı (geriye uyumlu). */
    public static int expectedDelta(int ra, int rb, boolean aWon, int k) {
        double ea = 1.0 / (1.0 + Math.pow(10, (rb - ra) / 400.0));
        return (int) Math.round(k * ((aWon ? 1.0 : 0.0) - ea));
    }

    /** Üst liglerde kazanç azalır (%7/lig, en az %55), kayıp artar (%8/lig). Çıkmak zorlaşır. */
    public static double gainMultiplier(int leagueIdx) { return Math.max(0.55, 1.0 - 0.07 * leagueIdx); }
    public static double lossMultiplier(int leagueIdx) { return 1.0 + 0.08 * leagueIdx; }

    /** Aynı çiftin son maç sayısına göre kasılma çarpanı: 0-1 maç=1.0, sonra %-25/maç, en az 0. */
    public static double farmFactor(int recentSamePair, int freeMatches) {
        int over = Math.max(0, recentSamePair - freeMatches);
        return Math.max(0.0, 1.0 - 0.25 * over);
    }

    /** Maç sonucu. winnerDelta >= 0, loserDelta >= 0 (kayıp miktarı). */
    public record Result(int winnerDelta, int loserDelta, int winnerNew, int loserNew) {}

    /**
     * @param rw kazananın Elo'su, rl kaybedenin Elo'su
     * @param recentSamePair bu iki oyuncunun yakın zamanda yaptığı maç sayısı (kasılma kontrolü)
     */
    public static Result compute(int rw, int rl, int k, int recentSamePair, int freeMatches) {
        double ea = 1.0 / (1.0 + Math.pow(10, (rl - rw) / 400.0));   // kazananın beklentisi
        double farm = farmFactor(recentSamePair, freeMatches);
        int gain = (int) Math.round(k * (1.0 - ea) * gainMultiplier(leagueIndex(rw)) * farm);
        int loss = (int) Math.round(k * (1.0 - ea) * lossMultiplier(leagueIndex(rl)) * farm);
        if (farm > 0) { gain = Math.max(gain, 1); loss = Math.max(loss, 1); }
        loss = Math.min(loss, Math.max(0, rl - MIN_ELO));
        return new Result(gain, loss, rw + gain, Math.max(MIN_ELO, rl - loss));
    }
}
