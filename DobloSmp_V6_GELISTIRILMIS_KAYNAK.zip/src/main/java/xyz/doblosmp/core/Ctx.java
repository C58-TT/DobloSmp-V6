package xyz.doblosmp.core;

import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.anticheat.Suspicion;
import xyz.doblosmp.clan.ClanService;
import xyz.doblosmp.discord.DiscordNotifier;
import xyz.doblosmp.economy.AuctionHouse;
import xyz.doblosmp.economy.Ledger;
import xyz.doblosmp.glue.Punishments;
import xyz.doblosmp.quest.QuestEngine;
import xyz.doblosmp.sb.IslandRegistry;
import xyz.doblosmp.social.FriendService;
import xyz.doblosmp.social.PartyService;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.UUID;

/** Modüller arası ortak servisler (tek eklenti örneği için basit bağlam). */
public final class Ctx {
    private Ctx() {}
    public static JavaPlugin plugin; public static Ledger ledger; public static AuctionHouse market; public static ClanService clans; public static QuestEngine quests;
    public static IslandRegistry islands; public static PartyService parties; public static FriendService friends; public static Suspicion suspicion;
    public static Punishments punishments; public static DiscordNotifier discord; public static xyz.doblosmp.glue.Persist persist;

    public static java.util.function.BiConsumer<org.bukkit.entity.Player, Integer> xp = (p, n) -> {};
    public static xyz.doblosmp.gui.NpcManager npcs;
    public static String mode(String game) { return plugin.getConfig().getString("economy.modes." + game, plugin.getConfig().getString("economy.mode", "global")); }
    public static LocalDate today() { return LocalDate.now(ZoneId.systemDefault()); }

    /** Görev ilerlemesi: yalnızca gerçek olaylardan çağrılır. Tamamlanınca oyuncuya bildirir. */
    public static void quest(UUID p, String metric, int amount) {
        if (quests == null) return;
        var done = quests.add(p, metric, amount, today());
        var pl = org.bukkit.Bukkit.getPlayer(p);
        if (pl != null) for (String id : done) pl.sendMessage("§a✔ Görev tamamlandı: §f" + id + " §7(/gorevler al " + id + ")");
    }
    public static void stat(UUID p, String game, String stat, long delta) {
        if (persist != null) persist.stat(p, game, stat, delta);
    }
    public static void discord(DiscordNotifier.Kind k, String title, String text) { if (discord != null) discord.send(k, title, text); }
}
