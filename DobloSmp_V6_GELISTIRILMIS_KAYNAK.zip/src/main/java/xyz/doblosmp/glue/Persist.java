package xyz.doblosmp.glue;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.db.Database;
import xyz.doblosmp.db.SqlStore;

import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.*;

/** Kalıcılık cephesi: MariaDB varsa SQL (asenkron, derin kopya ile), yoksa YAML. Ana thread'de yalnızca bellek kopyası alınır. */
public final class Persist {
    private final JavaPlugin plugin; private final Store yaml; private final Database db; private final SqlStore sql;
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "DobloSuite-Persist"); t.setDaemon(true); return t; });
    private final ConcurrentLinkedQueue<xyz.doblosmp.economy.Ledger.Entry> ledgerQueue = new ConcurrentLinkedQueue<>();

    public Persist(JavaPlugin plugin, Store yaml, Database db) { this.plugin = plugin; this.yaml = yaml; this.db = db; this.sql = db == null ? null : new SqlStore(db); }
    public boolean sql() { return sql != null; }
    public SqlStore store() { return sql; }

    public void load() {
        try {
            if (sql != null) {
                Ctx.ledger.restore(sql.loadBalances()); sql.loadClans(Ctx.clans); sql.loadAuctions(Ctx.market); sql.loadQuests(Ctx.quests); sql.loadIslands(Ctx.islands);
                Ctx.friends.restore(sql.loadFriends());
            } else {
                yaml.loadLedger(Ctx.ledger); yaml.loadMarket(Ctx.market); yaml.loadClans(Ctx.clans); yaml.loadQuests(Ctx.quests); yaml.loadIslands(Ctx.islands); yaml.loadFriends(Ctx.friends);
            }
        } catch (SQLException e) { plugin.getLogger().severe("Veri yüklenemedi: " + e.getMessage()); throw new IllegalStateException("Veri yüklenemedi; veri kaybını önlemek için eklenti durduruluyor.", e); }
        if (sql != null) Ctx.ledger.setListener(ledgerQueue::add);
    }

    /** Ana thread'de çağrılır: kopyaları alır, yazmayı arka plana bırakır. */
    public void saveAsync() {
        if (sql == null) { saveYaml(); return; }
        var bal = Ctx.ledger.snapshot(); var clans = Ctx.clans.snapshot(); var auctions = Ctx.market.active(); var quests = Ctx.quests.copyData();
        var islands = Ctx.islands.snapshot(); var friends = Ctx.friends.snapshot(); List<xyz.doblosmp.economy.Ledger.Entry> log = new ArrayList<>(); var e = (xyz.doblosmp.economy.Ledger.Entry) null;
        while ((e = ledgerQueue.poll()) != null) log.add(e);
        io.submit(() -> { try { sql.saveBalances(bal); sql.appendLedger(log); sql.saveClans(clans); sql.saveAuctions(auctions); sql.saveQuests(quests); sql.saveIslands(islands); sql.saveFriends(friends); }
            catch (Exception ex) { plugin.getLogger().severe("SQL kayıt hatası: " + ex.getMessage()); ledgerQueue.addAll(log); } });
    }
    private void saveYaml() { yaml.saveLedger(Ctx.ledger); yaml.saveMarket(Ctx.market); yaml.saveClans(Ctx.clans); yaml.saveQuests(Ctx.quests); yaml.saveIslands(Ctx.islands); yaml.saveFriends(Ctx.friends); }

    /** Kapanışta: aynı thread'de ve bekleyerek yazar. */
    public void saveBlocking() {
        if (sql == null) { saveYaml(); return; }
        saveAsync(); io.shutdown();
        try { if (!io.awaitTermination(30, TimeUnit.SECONDS)) plugin.getLogger().severe("SQL kayıt zaman aşımı!"); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        if (db != null) db.close();
    }

    public void stat(UUID p, String game, String stat, long delta) {
        if (sql == null) return; io.submit(() -> { try { sql.addStat(p, game, stat, delta); } catch (SQLException e) { plugin.getLogger().warning("İstatistik yazılamadı: " + e.getMessage()); } });
    }
    public void run(java.util.concurrent.Callable<?> c) { if (sql != null) io.submit(() -> { try { c.call(); } catch (Exception e) { plugin.getLogger().warning("SQL işlemi başarısız: " + e.getMessage()); } }); }
}
