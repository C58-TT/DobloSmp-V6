package xyz.doblosmp.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.function.Consumer;

/**
 * Sandık tabanlı menü çerçevesi. Sade sandık envanteri olduğu için Bedrock'ta Geyser tarafından otomatik çevrilir ve mobilde çalışır.
 * Tıklamalar daima iptal edilir; eylemler yalnızca üst envanterdeki kayıtlı slotlar için çalışır (eşya çıkarma/duplikasyon yok).
 */
public final class Menu implements InventoryHolder {
    private final Inventory inv; private final Map<Integer, Consumer<Player>> actions = new HashMap<>(); private Consumer<Player> onClose;

    public Menu(String title, int rows) { inv = Bukkit.createInventory(this, Math.max(1, Math.min(6, rows)) * 9, color(title)); }
    @Override public Inventory getInventory() { return inv; }
    public static Component color(String s) { return LegacyComponentSerializer.legacySection().deserialize(s).decoration(TextDecoration.ITALIC, false); }

    public static ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m); ItemMeta meta = it.getItemMeta(); meta.displayName(color(name));
        if (lore.length > 0) meta.lore(Arrays.stream(lore).map(Menu::color).toList()); it.setItemMeta(meta); return it;
    }
    public Menu set(int slot, ItemStack it, Consumer<Player> action) { if (slot >= 0 && slot < inv.getSize()) { inv.setItem(slot, it); if (action != null) actions.put(slot, action); else actions.remove(slot); } return this; }
    public Menu fillEmpty(Material m) { ItemStack f = item(m, " "); for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) inv.setItem(i, f); return this; }
    public Menu onClose(Consumer<Player> c) { onClose = c; return this; }
    public void open(Player p) { p.openInventory(inv); }

    /** Geri düğmesi (son satır, ilk slot). */
    public Menu back(Consumer<Player> to) { return set(inv.getSize() - 9, item(Material.ARROW, "§eGeri"), to); }

    /** Sayfalı liste: 0..(rows-1)*9-1 arası slotlar içerik, son satır gezinti. */
    public static <T> void paged(Player p, String title, List<T> items, int page, java.util.function.Function<T, ItemStack> icon,
                                 java.util.function.BiConsumer<Player, T> click, Consumer<Player> back, java.util.function.IntConsumer reopen) {
        int per = 45, pages = Math.max(1, (items.size() + per - 1) / per), pg = Math.max(0, Math.min(page, pages - 1));
        Menu m = new Menu(title + " §8(" + (pg + 1) + "/" + pages + ")", 6);
        for (int i = 0; i < per && pg * per + i < items.size(); i++) { T t = items.get(pg * per + i); m.set(i, icon.apply(t), click == null ? null : pl -> click.accept(pl, t)); }
        if (pg > 0) m.set(48, item(Material.ARROW, "§eÖnceki sayfa"), pl -> reopen.accept(pg - 1));
        if (pg < pages - 1) m.set(50, item(Material.ARROW, "§eSonraki sayfa"), pl -> reopen.accept(pg + 1));
        if (back != null) m.back(back); m.open(p);
    }

    public static final class Events implements Listener {
        @EventHandler public void onClick(InventoryClickEvent e) {
            if (!(e.getView().getTopInventory().getHolder() instanceof Menu m)) return;
            e.setCancelled(true);                                         // her durumda: eşya taşıma/shift-click/duplikasyon yok
            if (e.getClickedInventory() != e.getView().getTopInventory() || !(e.getWhoClicked() instanceof Player p)) return;
            Consumer<Player> a = m.actions.get(e.getSlot()); if (a != null) a.accept(p);
        }
        @EventHandler public void onDrag(InventoryDragEvent e) { if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true); }
        @EventHandler public void onClose(InventoryCloseEvent e) { if (e.getInventory().getHolder() instanceof Menu m && m.onClose != null && e.getPlayer() instanceof Player p) m.onClose.accept(p); }
    }
}
