package xyz.doblosmp.glue;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffectType;
import xyz.doblosmp.anticheat.*;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.discord.DiscordNotifier;
import xyz.doblosmp.game.Activities;
import xyz.doblosmp.gui.Menus;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * Anti-cheat bağlayıcısı (SEZGİSEL katman; paket seviyesinde DEĞİL). Hiçbir tespit tek başına kesin kanıt değildir:
 * puanlar birikir/azalır, TPS-ping-teleport-hız-iksiri durumunda atlanır, varsayılan yaptırım yalnızca yönetici uyarısıdır.
 * GrimAC/Vulcan/Themis/Matrix kuruluysa "tamamlayıcı" moda geçer (çakışan hareket/savaş kontrolleri kapanır).
 * Paket seviyesi exploit kontrolleri (kitap/NBT/crash) için ProtocolLib/PacketEvents gerekir → YAPILMADI.
 */
public final class AntiCheatListener implements Listener {
    private final JavaPlugin plugin; private final Suspicion suspicion; private final Sanction sanction; private final Compat.Mode mode;
    private final Map<UUID, Integer> airTicks = new HashMap<>(); private final Map<UUID, int[]> mining = new HashMap<>(); private final Map<UUID, Long> lastAlert = new HashMap<>(), skipUntil = new HashMap<>(), lastReview = new HashMap<>();
    private final Map<UUID, Deque<Long>> hits = new HashMap<>(), places = new HashMap<>(), cmds = new HashMap<>(); private final Map<UUID, Deque<long[]>> targets = new HashMap<>();
    private final Map<UUID, Double> lastHoriz = new HashMap<>(); private final Map<UUID, Long> lastAttack = new HashMap<>(), totemPop = new HashMap<>(), crystalPlaced = new HashMap<>(); private final Map<UUID, Integer> crystalStreak = new HashMap<>();
    private final Path logFile;

    public AntiCheatListener(JavaPlugin plugin, Suspicion suspicion) {
        this.plugin = plugin; this.suspicion = suspicion; var c = plugin.getConfig();
        sanction = new Sanction(c.getDouble("anticheat.alert-at", 8), c.getDouble("anticheat.setback-at", 14), c.getDouble("anticheat.kick-at", 22), c.getDouble("anticheat.ban-at", 40), c.getBoolean("anticheat.auto-punish", false));
        Set<String> names = new HashSet<>(); for (var pl : Bukkit.getPluginManager().getPlugins()) names.add(pl.getName());
        mode = Compat.detect(names, c.getString("anticheat.mode", "auto")); logFile = plugin.getDataFolder().toPath().resolve("anticheat.log");
        plugin.getLogger().info("Anti-cheat modu: " + mode + (mode == Compat.Mode.COMPLEMENT ? " (harici anti-cheat algılandı; çakışan kontroller kapalı)" : ""));
    }
    private boolean enabled() { return plugin.getConfig().getBoolean("anticheat.enabled", false); }
    private boolean active(String check) { return Compat.checkActive(mode, check); }
    private boolean skip(Player p) {
        GameMode g = p.getGameMode(); if (g == GameMode.CREATIVE || g == GameMode.SPECTATOR || p.hasPermission("doblo.ac.bypass")) return true;
        if (System.currentTimeMillis() < skipUntil.getOrDefault(p.getUniqueId(), 0L)) return true;
        return Checks.shouldSkip(Bukkit.getTPS()[0], p.getPing(), plugin.getConfig().getDouble("anticheat.min-tps", 18.0), plugin.getConfig().getInt("anticheat.max-ping", 400));
    }
    private void grace(Player p, long ms) { skipUntil.merge(p.getUniqueId(), System.currentTimeMillis() + ms, Math::max); }

    private void flag(Player p, String check, double pts, String detail, Location back) {
        if (pts <= 0 || !active(check)) return; long now = System.currentTimeMillis(); suspicion.add(p.getUniqueId(), check, pts, detail, now); double total = suspicion.total(p.getUniqueId(), now);
        Sanction.Action act = mode == Compat.Mode.COMPLEMENT ? (total >= plugin.getConfig().getDouble("anticheat.alert-at", 8) ? Sanction.Action.ALERT : Sanction.Action.NONE) : sanction.decide(total);
        log(p, check, total, detail, act);
        switch (act) {
            case ALERT -> alert(p, check, total, detail); case SETBACK -> { alert(p, check, total, detail); if (back != null) p.teleport(back); }
            case KICK -> { alert(p, check, total, detail); p.kick(net.kyori.adventure.text.Component.text("Şüpheli davranış nedeniyle bağlantın kesildi. (Hata olduğunu düşünüyorsan yetkililere yaz.)")); }
            case BAN -> { alert(p, check, total, detail); long secs = plugin.getConfig().getLong("anticheat.tempban-seconds", 3600); Ctx.punishments.record(secs > 0 ? "tempban" : "ban", p.getName(), "[DobloGuard] " + check + " " + String.format("%.1f", total), secs, "DobloGuard");
                if (secs > 0) { Ctx.punishments.tempBan(p.getName(), secs); p.kick(net.kyori.adventure.text.Component.text("Anti-cheat: geçici yasak (" + secs / 60 + " dk).")); } else Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban " + p.getName() + " [DobloGuard] " + check); }
            default -> {}
        }
        if (total >= plugin.getConfig().getDouble("anticheat.review-at", 12) && now - lastReview.getOrDefault(p.getUniqueId(), 0L) > 600_000L) { lastReview.put(p.getUniqueId(), now); Ctx.punishments.report("DobloGuard", p.getName(), "AC-inceleme: " + check + " toplam=" + String.format("%.1f", total)); }
    }
    private void log(Player p, String check, double total, String detail, Sanction.Action a) {
        try { Files.createDirectories(logFile.getParent()); Files.writeString(logFile, java.time.Instant.now() + "\t" + p.getName() + "\t" + check + "\t" + String.format("%.1f", total) + "\t" + a + "\tping=" + p.getPing() + "\ttps=" + String.format("%.1f", Bukkit.getTPS()[0]) + "\t" + detail + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND); } catch (IOException ignored) {}
    }
    private void alert(Player p, String check, double total, String detail) {
        long now = System.currentTimeMillis(); if (now - lastAlert.getOrDefault(p.getUniqueId(), 0L) < 10_000L) return; lastAlert.put(p.getUniqueId(), now);
        String msg = "§c[DobloGuard] §f" + p.getName() + " §7" + check + " §c" + String.format("%.1f", total) + " §8(" + detail + ", ping " + p.getPing() + ")";
        for (Player st : Bukkit.getOnlinePlayers()) if (st.hasPermission("doblo.admin") && (Menus.prefs == null || Menus.prefs.get(st.getUniqueId(), "ac_alerts"))) st.sendMessage(msg);
        if (total >= plugin.getConfig().getDouble("anticheat.discord-at", 15)) Ctx.discord(DiscordNotifier.Kind.WARN, "Anti-cheat uyarısı", p.getName() + " — " + check + " (" + String.format("%.1f", total) + ")");
    }
    private boolean gameBusy(UUID id) { return plugin.getConfig().getBoolean("anticheat.skip-movement-in-games", true) && Activities.busy(id); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true) public void onMove(PlayerMoveEvent e) {
        if (!enabled() || e.getTo() == null) return; Player p = e.getPlayer(); Location from = e.getFrom(), to = e.getTo(); UUID id = p.getUniqueId();
        double dx = to.getX() - from.getX(), dz = to.getZ() - from.getZ(), dy = to.getY() - from.getY(), horiz = Math.sqrt(dx * dx + dz * dz); lastHoriz.put(id, horiz);
        if (Double.isNaN(dx + dy + dz) || Math.abs(dx) > 8 || Math.abs(dz) > 8 || Math.abs(dy) > 10) { if (!skip(p)) flag(p, "packet", Checks.packet(0, to.getX(), to.getY(), to.getZ()) + (Math.abs(dx) > 8 || Math.abs(dz) > 8 ? 3 : 0), "delta=" + String.format("%.1f,%.1f,%.1f", dx, dy, dz), from); return; }
        if (from.getWorld() != to.getWorld() || skip(p) || p.isInsideVehicle() || p.isGliding() || p.isRiptiding() || p.isFlying() || p.getAllowFlight() || p.isSwimming() || gameBusy(id)) { airTicks.remove(id); return; }
        var sp = p.getPotionEffect(PotionEffectType.SPEED); boolean ice = p.getLocation().subtract(0, 1, 0).getBlock().getType().name().contains("ICE");
        flag(p, "speed", Checks.speed(horiz, sp == null ? -1 : sp.getAmplifier(), ice, p.isSprinting(), p.getPing()), String.format("h=%.2f", horiz), from);
        Material below = p.getLocation().subtract(0, 0.3, 0).getBlock().getType(); Block in = p.getLocation().getBlock(); String in_ = in.getType().name();
        boolean liquidOrClimb = in.isLiquid() || in_.contains("VINE") || in_.contains("LADDER") || in_.contains("SCAFFOLDING") || in.getType() == Material.COBWEB || in_.contains("BERRIES") || in_.contains("POWDER_SNOW");
        boolean airborne = below.isAir() && !p.isOnGround();
        if (airborne) { int t = airTicks.merge(id, 1, Integer::sum); boolean slow = p.hasPotionEffect(PotionEffectType.SLOW_FALLING) || p.hasPotionEffect(PotionEffectType.LEVITATION) || p.hasPotionEffect(PotionEffectType.JUMP_BOOST);
            flag(p, "fly", Checks.fly(t, dy, liquidOrClimb, slow), "air=" + t, from); } else airTicks.remove(id);
        if (p.isOnGround() && below.isAir() && !liquidOrClimb) flag(p, "nofall", Checks.noFall(p.getFallDistance(), true, false, false), "fd=" + String.format("%.1f", p.getFallDistance()), from);
    }
    @EventHandler public void onTeleport(PlayerTeleportEvent e) { grace(e.getPlayer(), 2500); airTicks.remove(e.getPlayer().getUniqueId()); }
    @EventHandler public void onVelocity(PlayerVelocityEvent e) { grace(e.getPlayer(), 1500); }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) { grace(e.getPlayer(), 3000); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true) public void onHit(EntityDamageByEntityEvent e) {
        if (!enabled()) return; UUID vid = e.getEntity().getUniqueId();
        if (e.getDamager() instanceof Player p && !skip(p)) { UUID id = p.getUniqueId(); long now = System.currentTimeMillis(); lastAttack.put(id, now);
            if (e.getEntity() instanceof EnderCrystal) { long placed = crystalPlaced.getOrDefault(id, 0L); long d = now - placed; int streak = d < 150 ? crystalStreak.merge(id, 1, Integer::sum) : crystalStreak.merge(id, 0, (a, b) -> 0); flag(p, "autocrystal", Checks.autoCrystal(d, streak), "d=" + d + "ms s=" + streak, null); return; }
            double dist = p.getEyeLocation().distance(e.getEntity().getLocation().add(0, e.getEntity().getHeight() / 2, 0)); flag(p, "reach", Checks.reach(dist, p.getPing(), false), String.format("d=%.2f", dist), null);
            Deque<Long> d = hits.computeIfAbsent(id, k -> new ArrayDeque<>()); d.addLast(now); while (!d.isEmpty() && now - d.peekFirst() > 1000) d.pollFirst();
            Deque<long[]> tg = targets.computeIfAbsent(id, k -> new ArrayDeque<>()); tg.addLast(new long[]{now, vid.hashCode()}); while (!tg.isEmpty() && now - tg.peekFirst()[0] > 500) tg.pollFirst();
            long distinct = tg.stream().map(x -> x[1]).distinct().count(); org.bukkit.util.Vector dir = p.getEyeLocation().getDirection(), to = e.getEntity().getLocation().add(0, e.getEntity().getHeight() / 2, 0).toVector().subtract(p.getEyeLocation().toVector());
            double aim = to.length() < 0.5 ? 0 : Math.toDegrees(dir.angle(to)); flag(p, "killaura", Checks.killAura((int) distinct, aim, d.size()), "targets=" + distinct + " aim=" + String.format("%.0f", aim) + " cps=" + d.size(), null); }
    }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true) public void onPlace(BlockPlaceEvent e) {
        if (!enabled()) return; Player p = e.getPlayer(); if (e.getBlockPlaced().getType() == Material.END_CRYSTAL) crystalPlaced.put(p.getUniqueId(), System.currentTimeMillis()); if (skip(p) || gameBusy(p.getUniqueId())) return;
        Deque<Long> d = places.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>()); long now = System.currentTimeMillis(); d.addLast(now); while (!d.isEmpty() && now - d.peekFirst() > 1000) d.pollFirst();
        boolean below = e.getBlockPlaced().getY() == p.getLocation().getBlockY() - 1 && Math.abs(e.getBlockPlaced().getX() + 0.5 - p.getLocation().getX()) < 1.5 && Math.abs(e.getBlockPlaced().getZ() + 0.5 - p.getLocation().getZ()) < 1.5;
        flag(p, "scaffold", Checks.scaffold(d.size(), p.getLocation().getPitch(), p.isSprinting(), below && lastHoriz.getOrDefault(p.getUniqueId(), 0.0) > 0.1), "bps=" + d.size(), null);
    }
    @EventHandler public void onTotem(EntityResurrectEvent e) { if (e.getEntity() instanceof Player p) totemPop.put(p.getUniqueId(), System.currentTimeMillis()); }
    @EventHandler public void onSwap(PlayerSwapHandItemsEvent e) { if (!enabled() || skip(e.getPlayer())) return; Long pop = totemPop.get(e.getPlayer().getUniqueId()); if (pop != null) { long d = System.currentTimeMillis() - pop; if (d < 2000) flag(e.getPlayer(), "autototem", Checks.autoTotem(d), "d=" + d + "ms", null); } }
    @EventHandler public void onInv(InventoryClickEvent e) {
        if (!enabled() || !(e.getWhoClicked() instanceof Player p) || skip(p) || gameBusy(p.getUniqueId())) return; boolean attacked = System.currentTimeMillis() - lastAttack.getOrDefault(p.getUniqueId(), 0L) < 300;
        flag(p, "inventory", Checks.inventory(true, lastHoriz.getOrDefault(p.getUniqueId(), 0.0), attacked), "h=" + String.format("%.2f", lastHoriz.getOrDefault(p.getUniqueId(), 0.0)) + (attacked ? " saldırı" : ""), null);
    }
    @EventHandler public void onCmd(PlayerCommandPreprocessEvent e) {
        if (!enabled()) return; Player p = e.getPlayer(); Deque<Long> d = cmds.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>()); long now = System.currentTimeMillis(); d.addLast(now); while (!d.isEmpty() && now - d.peekFirst() > 1000) d.pollFirst();
        if (!p.hasPermission("doblo.ac.bypass")) flag(p, "packet", Checks.packet(d.size() * 60, 0, 0, 0) > 0 ? 1.5 : 0, "komut/sn=" + d.size(), null);
    }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true) public void onBreak(BlockBreakEvent e) {
        if (!enabled()) return; Player p = e.getPlayer(); if (skip(p)) return; Material m = e.getBlock().getType(); int[] s = mining.computeIfAbsent(p.getUniqueId(), k -> new int[3]); s[0]++;
        if (m == Material.DIAMOND_ORE || m == Material.DEEPSLATE_DIAMOND_ORE || m == Material.ANCIENT_DEBRIS) { s[1]++; boolean exposed = false; for (var f : org.bukkit.block.BlockFace.values()) if (Math.abs(f.getModY()) <= 1 && e.getBlock().getRelative(f).getType().isAir()) exposed = true; if (exposed) s[2]++; }
        if (s[0] >= 200) { flag(p, "xray", Checks.xray(s[1], s[0], s[2]), "cevher=" + s[1] + "/" + s[0], null); mining.remove(p.getUniqueId()); }
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) { UUID id = e.getPlayer().getUniqueId(); for (Map<UUID, ?> m : List.of(airTicks, mining, lastAlert, skipUntil, hits, places, cmds, targets, lastHoriz, lastAttack, totemPop, crystalPlaced, crystalStreak, lastReview)) m.remove(id); }
}
