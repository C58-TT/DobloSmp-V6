#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Bu script root olarak çalıştırılmalı (sudo).' >&2; exit 1; fi
getent group minecraft >/dev/null || groupadd minecraft
id minecraft >/dev/null 2>&1 || useradd --system --gid minecraft --home-dir /opt/minecraft --shell /usr/sbin/nologin minecraft
install -d -m 0750 -o root -g minecraft /etc/doblosmp
secret_file=/etc/doblosmp/secrets.env
read -r -s -p 'MariaDB parola (boş bırakılabilir): ' dbpass; echo
read -r -s -p 'Discord webhook URL (şimdilik boş bırakılabilir): ' webhook; echo
DOBLO_DB_PASSWORD_VALUE="$dbpass" DOBLO_DISCORD_WEBHOOK_VALUE="$webhook" python3 - <<'PY'
import os
from pathlib import Path

def quote(v):
    return v.replace('\\', '\\\\').replace('"', '\\"').replace('$', '\\$').replace('`', '\\`')
lines = [f'DOBLO_DB_PASSWORD="{quote(os.environ.get("DOBLO_DB_PASSWORD_VALUE", ""))}"',
         f'DOBLO_DISCORD_WEBHOOK="{quote(os.environ.get("DOBLO_DISCORD_WEBHOOK_VALUE", ""))}"']
p = Path('/etc/doblosmp/secrets.env')
p.write_text('\n'.join(lines) + '\n')
p.chmod(0o640)
PY
chown root:minecraft "$secret_file"
chmod 0640 "$secret_file"
echo "Secret dosyası oluşturuldu: /etc/doblosmp/secrets.env (izin 0640). Webhook URL'sini kimseyle paylaşma."
echo 'Unit dosyası EnvironmentFile=-/etc/doblosmp/secrets.env kullanıyor olmalı. Ardından: systemctl daemon-reload'
