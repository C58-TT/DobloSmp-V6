package xyz.doblosmp.game;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import xyz.doblosmp.core.Ctx;
import xyz.doblosmp.duels.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Duels Paper bağlayıcısı: kuyruk, ELO, davet, kit, arena, raund, seyirci, sıfırlama. Paper'da test EDİLMEDİ. 2v2 YOK (yalnızca 1v1). */
public final class DuelsManager implements CommandExecutor, Listener {
    private final class Game {
        final ArenaStore.Arena arena; final DuelMatch match; final String kit; final boolean ranked; final BlockLog log = new BlockLog(); final Set<UUID> spectators = new HashSet<>();
        BukkitTask task; int countdown = 5, roundDelay; boolean ended; Game(ArenaStore.Arena a, DuelMatch m, String k, boolean r) { arena = a; match = m; kit = k; ranked = r; }
    }
    private record Invite(UUID from, String kit, long until) {}

    private final JavaPlugin plugin; private final ArenaStore store; private final PlayerState state; private final DuelQueue queue; private final Map<UUID, Game> byPlayer = new HashMap<>(); private final Map<String, Game> inUse = new HashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>(); private final Map<String, Map<UUID, Integer>> elo = new ConcurrentHashMap<>(); private final File eloFile; private final Map<UUID, Boolean> queuedRanked = new HashMap<>(); private BukkitTask poller;

    public DuelsManager(JavaPlugin plugin, ArenaStore store, PlayerState state) {
        this.plugin = plugin; this.store = store; this.state = state; this.eloFile = new File(plugin.getDataFolder(), "duels-elo.yml"); loadYamlElo();
        queue = new DuelQueue(plugin.getConfig().getInt("duels.elo-range", 100), plugin.getConfig().getInt("duels.elo-widen-per-second", 10));
        poller = Bukkit.getScheduler().runTaskTimer(plugin, this::pairUp, 40L, 40L);
    }

    // ---------- ELO ----------
    public int eloOf(UUID p, String kit) { return elo.getOrDefault(kit, Map.of()).getOrDefault(p, Elo.START); }
    /** Oyuncu girişinde SQL'den arka planda yüklenir. */
    public void loadElo(UUID p) {
        if (!Ctx.persist.sql()) return; ConfigurationSection kits = plugin.getConfig().getConfigurationSection("duels.kits"); if (kits == null) return;
        Ctx.persist.run(() -> { for (String k : kits.getKeys(false)) elo.computeIfAbsent(k, x -> new ConcurrentHashMap<>()).put(p, Ctx.persist.store().elo(p, k)); return null; });
    }
    private void loadYamlElo() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(eloFile);
        for (String kit : y.getKeys(false)) { var sec = y.getConfigurationSection(kit); if (sec == null) continue;
            Map<UUID, Integer> values = elo.computeIfAbsent(kit, x -> new ConcurrentHashMap<>());
            for (String id : sec.getKeys(false)) try { values.put(UUID.fromString(id), Math.max(0, sec.getInt(id, Elo.START))); } catch (IllegalArgumentException ignored) { }
        }
    }
    private synchronized void saveYamlElo() {
        YamlConfiguration y = new YamlConfiguration();
        elo.forEach((kit, values) -> values.forEach((id, value) -> y.set(kit + "." + id, value)));
        try { plugin.getDataFolder().mkdirs(); y.save(eloFile); } catch (IOException e) { plugin.getLogger().severe("Duels Elo kaydedilemedi: " + e.getMessage()); }
    }
    private void setElo(UUID p, String kit, int v) {
        elo.computeIfAbsent(kit, x -> new ConcurrentHashMap<>()).put(p, v); saveYamlElo();
        if (Ctx.persist.sql()) Ctx.persist.run(() -> { Ctx.persist.store().setElo(p, kit, v); return null; });
    }
    private void showTop(Player p, String kit) {
        if (!kitExists(kit)) { p.sendMessage("§cBilinmeyen kit."); return; }
        if (Ctx.persist.sql()) {
            Ctx.persist.run(() -> { var rows = Ctx.persist.store().topElo(kit, 10); Bukkit.getScheduler().runTask(plugin, () -> {
                p.sendMessage("§6§lDuels Elo Sıralaması §7(" + kit + ")"); int i = 1;
                for (var row : rows.entrySet()) p.sendMessage("§e" + (i++) + ". §f" + Bukkit.getOfflinePlayer(row.getKey()).getName() + " §7- §b" + row.getValue() + " §8(" + Elo.league(row.getValue()) + ")");
                if (rows.isEmpty()) p.sendMessage("§7Henüz sıralama verisi yok.");
            }); return null; });
        } else {
            var rows = new ArrayList<>(elo.getOrDefault(kit, Map.of()).entrySet()); rows.sort(Map.Entry.<UUID,Integer>comparingByValue().reversed());
            p.sendMessage("§6§lDuels Elo Sıralaması §7(" + kit + ")"); int i = 1;
            for (var row : rows.stream().limit(10).toList()) p.sendMessage("§e" + (i++) + ". §f" + Bukkit.getOfflinePlayer(row.getKey()).getName() + " §7- §b" + row.getValue() + " §8(" + Elo.league(row.getValue()) + ")");
            if (rows.isEmpty()) p.sendMessage("§7Henüz sıralama verisi yok.");
        }
    }

    // ---------- komutlar ----------
    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Oyuncu komutu."); return true; } UUID id = p.getUniqueId();
        if (a.length == 0) { p.sendMessage("§e/duel <oyuncu> [kit] | queue <kit> [ranked|unranked] | top [kit] | leave | accept | deny | spectate <oyuncu> | stats"); return true; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "queue" -> { String kit = a.length > 1 ? a[1] : "crystal"; boolean ranked = a.length < 3 || a[2].equalsIgnoreCase("ranked");
                if (!kitExists(kit)) { p.sendMessage("§cBilinmeyen kit."); return true; } if (Activities.busy(id)) { p.sendMessage("§cZaten bir etkinlikte/kuyruktasın."); return true; }
                if (Ctx.parties.of(id) != null) { p.sendMessage("§cParti düellosu bu kuyrukta desteklenmiyor; bireysel sıraya gir."); return true; }
                if (!Activities.enter(id, Activities.Kind.DUEL_QUEUE)) return true; queue.join(id, kit + (ranked ? ":R" : ":U"), 1, ranked ? eloOf(id, kit) : Elo.START); p.sendMessage("§aKuyruğa girdin: " + kit + (ranked ? " (sıralı)" : " (sırasız)") + " §7/duel leave"); }
            case "leave" -> { if (queue.leave(id)) { Activities.leave(id, Activities.Kind.DUEL_QUEUE); p.sendMessage("§eKuyruktan çıktın."); } else if (byPlayer.get(id) != null) forfeit(p); else p.sendMessage("§cKuyrukta değilsin."); }
            case "accept" -> { Invite inv = invites.remove(id); Player from = inv == null ? null : Bukkit.getPlayer(inv.from()); if (inv == null || inv.until() < System.currentTimeMillis() || from == null) { p.sendMessage("§cGeçerli davet yok."); return true; }
                if (Activities.busy(id) || Activities.busy(inv.from())) { p.sendMessage("§cOyunculardan biri meşgul."); return true; } startMatch(from.getUniqueId(), id, inv.kit(), false); }
            case "deny" -> { Invite inv = invites.remove(id); if (inv != null) { Player f = Bukkit.getPlayer(inv.from()); if (f != null) f.sendMessage("§c" + p.getName() + " düello davetini reddetti."); } p.sendMessage("§eReddedildi."); }
            case "spectate" -> { Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null; Game g = t == null ? null : byPlayer.get(t.getUniqueId()); if (g == null || Activities.busy(id)) { p.sendMessage("§cİzlenecek maç yok veya meşgulsün."); return true; }
                state.save(p); Activities.force(id, Activities.Kind.DUELS); byPlayer.put(id, g); g.spectators.add(id); p.setGameMode(GameMode.SPECTATOR); p.teleport(t.getLocation()); p.sendMessage("§aİzleyicisin. /duel leave"); }
            case "top" -> { String kit = a.length > 1 ? a[1] : "crystal"; showTop(p, kit); }
            case "stats" -> p.sendMessage("§bELO'ların: " + (kits().isEmpty() ? "-" : String.join(", ", kits().stream().map(k -> k + "=" + eloOf(id, k) + " (" + Elo.league(eloOf(id, k)) + ")").toList())));
            case "arena" -> { if (!p.hasPermission("doblo.admin")) { p.sendMessage("§cYetkin yok."); return true; } admin(p, a); }
            default -> { Player t = Bukkit.getPlayerExact(a[0]); String kit = a.length > 1 ? a[1] : "crystal";
                if (t == null || t.equals(p) || !kitExists(kit)) { p.sendMessage("§c/duel <çevrimiçi oyuncu> [kit]"); return true; } if (Activities.busy(id) || Activities.busy(t.getUniqueId())) { p.sendMessage("§cOyunculardan biri meşgul."); return true; }
                invites.put(t.getUniqueId(), new Invite(id, kit, System.currentTimeMillis() + 30_000)); p.sendMessage("§aDavet gönderildi."); t.sendMessage("§e" + p.getName() + " seni " + kit + " düellosuna davet etti. §a/duel accept §7veya §c/duel deny §7(30 sn)"); }
        }
        return true;
    }
    private Set<String> kits() { ConfigurationSection k = plugin.getConfig().getConfigurationSection("duels.kits"); return k == null ? Set.of() : k.getKeys(false); }
    private boolean kitExists(String k) { return kits().contains(k); }

    private void admin(Player p, String[] a) {
        if (a.length < 2) { p.sendMessage("§e/duel arena create <ad> | setspawn <ad> <1|2> | setspectator <ad> | enable | disable | delete | list | check"); return; }
        String op = a[1].toLowerCase(Locale.ROOT); if (op.equals("list")) { store.all().stream().filter(x -> x.type.equals("DUELS")).forEach(x -> p.sendMessage("§7" + x.name + (x.enabled ? " §aaçık" : " §cdevre dışı"))); return; }
        if (a.length < 3) { p.sendMessage("§cArena adı gerekli."); return; }
        if (op.equals("create")) { p.sendMessage(store.create(a[2], "DUELS") != null ? "§aArena oluşturuldu." : "§cOluşturulamadı."); return; }
        var ar = store.get(a[2]); if (ar == null || !ar.type.equals("DUELS")) { p.sendMessage("§cArena yok."); return; } if (inUse.containsKey(ar.name)) { p.sendMessage("§cArena kullanımda."); return; }
        switch (op) {
            case "setspawn" -> { int n = a.length > 3 ? Integer.parseInt(a[3]) : 0; if (n < 1 || n > 2) { p.sendMessage("§c1 veya 2"); return; } ar.points.put("spawn:" + n, new ArrayList<>(List.of(p.getLocation().clone()))); p.sendMessage("§aAyarlandı."); }
            case "setspectator" -> { ar.points.put("spectator", new ArrayList<>(List.of(p.getLocation().clone()))); p.sendMessage("§aAyarlandı."); }
            case "enable" -> { if (ar.first("spawn:1") == null || ar.first("spawn:2") == null) { p.sendMessage("§c1. ve 2. doğma noktası gerekli."); return; } ar.enabled = true; p.sendMessage("§aAçıldı."); }
            case "disable" -> { ar.enabled = false; p.sendMessage("§eKapatıldı."); } case "delete" -> { store.delete(ar.name); p.sendMessage("§eSilindi."); }
            case "check" -> p.sendMessage(ar.first("spawn:1") != null && ar.first("spawn:2") != null ? "§aHazır." : "§cEksik doğma noktaları.");
            default -> p.sendMessage("§cBilinmeyen alt komut.");
        }
        store.save();
    }

    // ---------- eşleştirme ----------
    private List<ArenaStore.Arena> freeArenas() { List<ArenaStore.Arena> l = new ArrayList<>(); for (var a : store.all()) if (a.type.equals("DUELS") && a.enabled && !inUse.containsKey(a.name)) l.add(a); return l; }
    private void pairUp() {
        int free = freeArenas().size(); if (free == 0 && queue.size() < 2) return; var matches = queue.poll(System.currentTimeMillis()); int n = 0;
        for (var m : matches) { if (n++ >= free) { queue.join(m.a().player(), m.a().kit(), 1, m.a().elo()); queue.join(m.b().player(), m.b().kit(), 1, m.b().elo()); continue; }
            Activities.leave(m.a().player(), Activities.Kind.DUEL_QUEUE); Activities.leave(m.b().player(), Activities.Kind.DUEL_QUEUE);
            String[] k = m.a().kit().split(":"); startMatch(m.a().player(), m.b().player(), k[0], k.length > 1 && k[1].equals("R")); }
    }

    // ---------- maç ----------
    private void startMatch(UUID a, UUID b, String kit, boolean ranked) {
        Player pa = Bukkit.getPlayer(a), pb = Bukkit.getPlayer(b); var arenas = freeArenas();
        if (pa == null || pb == null || arenas.isEmpty() || !Activities.enter(a, Activities.Kind.DUELS)) { if (pa != null) pa.sendMessage("§cMaç başlatılamadı (arena/rakip yok)."); if (pb != null) pb.sendMessage("§cMaç başlatılamadı."); return; }
        if (!Activities.enter(b, Activities.Kind.DUELS)) { Activities.leave(a, Activities.Kind.DUELS); return; }
        var arena = arenas.get(new Random().nextInt(arenas.size())); Game g = new Game(arena, new DuelMatch(a, b, plugin.getConfig().getInt("duels.best-of", 3), plugin.getConfig().getLong("duels.max-minutes", 10) * 60_000L), kit, ranked);
        inUse.put(arena.name, g); byPlayer.put(a, g); byPlayer.put(b, g); state.save(pa); state.save(pb);
        for (Player p : List.of(pa, pb)) { prepare(p, g, p == pa ? 1 : 2); p.sendMessage("§bDüello: §f" + pa.getName() + " §7vs §f" + pb.getName() + " §7(" + kit + (ranked ? ", sıralı" : ", sırasız") + ")"); }
        g.task = Bukkit.getScheduler().runTaskTimer(plugin, () -> tick(g), 20L, 20L);
    }
    private void prepare(Player p, Game g, int spawn) {
        PlayerState.prepare(p, GameMode.SURVIVAL); p.teleport(g.arena.first("spawn:" + spawn)); ConfigurationSection k = plugin.getConfig().getConfigurationSection("duels.kits." + g.kit);
        if (k == null) return; List<ItemStack> armor = new ArrayList<>();
        for (String s : k.getStringList("items")) { ItemStack it = parse(s); if (it != null) { if (it.getType() == Material.MACE) { it.addEnchantment(Enchantment.DENSITY, 5); it.addEnchantment(Enchantment.WIND_BURST, 2); } p.getInventory().addItem(it); } }
        ItemStack[] arm = new ItemStack[4]; List<String> al = k.getStringList("armor"); for (int i = 0; i < Math.min(4, al.size()); i++) arm[i] = parse(al.get(i)); p.getInventory().setArmorContents(arm);
    }
    private ItemStack parse(String s) { String[] x = s.split(":"); try { return new ItemStack(Material.valueOf(x[0].toUpperCase(Locale.ROOT)), x.length > 1 ? Integer.parseInt(x[1]) : 1); } catch (IllegalArgumentException e) { plugin.getLogger().warning("Kit eşyası geçersiz: " + s); return null; } }

    private void tick(Game g) {
        if (g.ended) return; Player pa = Bukkit.getPlayer(g.match.a), pb = Bukkit.getPlayer(g.match.b);
        if (pa == null || pb == null) { finish(g, pa == null ? g.match.b : g.match.a, "rakip ayrıldı"); return; }
        if (g.match.timedOut()) { UUID w = g.match.resolveTimeout(); if (w == null) { cancelDraw(g); } else finish(g, w, "süre doldu"); return; }
        if (g.match.state() == DuelMatch.State.COUNTDOWN || g.match.state() == DuelMatch.State.ROUND_END) {
            if (g.roundDelay > 0) { g.roundDelay--; return; }
            if (g.countdown > 0) { for (Player p : List.of(pa, pb)) GameUtil.title(p, "§e" + g.countdown, ""); g.countdown--; } else { g.match.startFight(); GameUtil.title(pa, "§aBAŞLA!", ""); GameUtil.title(pb, "§aBAŞLA!", ""); g.countdown = 3; }
        }
    }
    private void cancelDraw(Game g) { g.ended = true; for (UUID u : List.of(g.match.a, g.match.b)) { Player p = Bukkit.getPlayer(u); if (p != null) p.sendMessage("§eMaç berabere bitti."); } cleanup(g); }
    private void forfeit(Player p) { Game g = byPlayer.get(p.getUniqueId()); if (g == null || g.ended) return; if (g.spectators.contains(p.getUniqueId())) { leaveSpectator(p, g); return; } UUID other = p.getUniqueId().equals(g.match.a) ? g.match.b : g.match.a; finish(g, other, p.getName() + " pes etti"); }
    private void leaveSpectator(Player p, Game g) { g.spectators.remove(p.getUniqueId()); byPlayer.remove(p.getUniqueId()); Activities.leave(p.getUniqueId(), Activities.Kind.DUELS); state.restoreIfPending(p); }

    private void roundWon(Game g, UUID winner) {
        UUID loser = winner.equals(g.match.a) ? g.match.b : g.match.a; boolean over = g.match.roundWon(winner); Player pw = Bukkit.getPlayer(winner), pl = Bukkit.getPlayer(loser);
        if (over) { finish(g, winner, "maç bitti"); return; }
        String score = g.match.rounds(g.match.a) + " - " + g.match.rounds(g.match.b); for (Player p : List.of(pw, pl)) if (p != null) p.sendMessage("§eRaund bitti! Skor: §f" + score);
        g.countdown = 3; g.roundDelay = 2; Bukkit.getScheduler().runTaskLater(plugin, () -> { if (g.ended) return; Player a = Bukkit.getPlayer(g.match.a), b = Bukkit.getPlayer(g.match.b); if (a != null) prepare(a, g, 1); if (b != null) prepare(b, g, 2); }, 40L);
    }

    private void finish(Game g, UUID winner, String why) {
        if (g.ended) return; g.ended = true; UUID loser = winner.equals(g.match.a) ? g.match.b : g.match.a; Player pw = Bukkit.getPlayer(winner), pl = Bukkit.getPlayer(loser);
        int ew = eloOf(winner, g.kit), el = eloOf(loser, g.kit); var res = g.match.finish(winner.equals(g.match.a) ? ew : el, winner.equals(g.match.a) ? el : ew, 32);
        int delta = res == null ? Elo.expectedDelta(ew, el, true, 32) : res.winnerDelta();
        if (g.ranked) { setElo(winner, g.kit, ew + delta); setElo(loser, g.kit, Math.max(0, el - delta)); }
        String mode = Ctx.mode("duels"); long reward = plugin.getConfig().getLong("duels.reward-win", 60); Ctx.ledger.deposit(mode, winner, reward, "duels"); Ctx.ledger.deposit(mode, loser, plugin.getConfig().getLong("duels.reward-lose", 10), "duels");
        Ctx.stat(winner, "duels", "wins", 1); Ctx.stat(loser, "duels", "losses", 1); Ctx.quest(winner, "duels_win", 1); Ctx.quest(winner, "match_won", 1); Ctx.quest(winner, "match_played", 1); Ctx.quest(loser, "match_played", 1);
        if (Ctx.persist.sql()) Ctx.persist.run(() -> { Ctx.persist.store().addDuelHistory(g.kit, winner, loser, delta, g.ranked); return null; });
        if (pw != null) { Ctx.xp.accept(pw, 60); GameUtil.title(pw, "§6ZAFER", "§7" + why); pw.sendMessage("§a+" + reward + " para" + (g.ranked ? " §7| ELO §a+" + delta + " §7→ §f" + (ew + delta) + " (" + Elo.league(ew + delta) + ")" : "")); }
        if (pl != null) { GameUtil.title(pl, "§cMAĞLUBİYET", "§7" + why); if (g.ranked) pl.sendMessage("§cELO -" + delta + " §7→ §f" + Math.max(0, el - delta) + " (" + Elo.league(Math.max(0, el - delta)) + ")"); }
        Bukkit.getScheduler().runTaskLater(plugin, () -> cleanup(g), 60L);
    }
    private void cleanup(Game g) {
        if (g.task != null) g.task.cancel();
        for (UUID u : new ArrayList<>(byPlayer.keySet())) if (byPlayer.get(u) == g) { Player p = Bukkit.getPlayer(u); byPlayer.remove(u); Activities.leave(u, Activities.Kind.DUELS); if (p != null) state.restoreIfPending(p); }
        g.log.restore(plugin, 800, () -> inUse.remove(g.arena.name));
    }

    // ---------- olaylar ----------
    private Game of(Player p) { return byPlayer.get(p.getUniqueId()); }
    @EventHandler(priority = EventPriority.HIGH) public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return; Game g = of(p); if (g == null) return;
        if (g.ended || g.spectators.contains(p.getUniqueId()) || g.match.state() != DuelMatch.State.FIGHTING) { e.setCancelled(true); return; }
        if (e instanceof EntityDamageByEntityEvent by) { Player d = by.getDamager() instanceof Player x ? x : (by.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player sh ? sh : null); if (d == null || of(d) != g) { e.setCancelled(true); return; } }
        else if (e.getCause() != EntityDamageEvent.DamageCause.VOID && e.getCause() != EntityDamageEvent.DamageCause.FALL && e.getCause() != EntityDamageEvent.DamageCause.FIRE && e.getCause() != EntityDamageEvent.DamageCause.FIRE_TICK) { /* diğer nedenler serbest */ }
        if (e.getCause() == EntityDamageEvent.DamageCause.VOID || p.getHealth() - e.getFinalDamage() <= 0) { e.setCancelled(true); UUID other = p.getUniqueId().equals(g.match.a) ? g.match.b : g.match.a; p.setHealth(20); roundWon(g, other); }
    }
    @EventHandler public void onDeath(PlayerDeathEvent e) { if (of(e.getEntity()) != null) { e.getDrops().clear(); e.setDroppedExp(0); e.deathMessage(null); } }
    @EventHandler(priority = EventPriority.HIGH) public void onPlace(BlockPlaceEvent e) { Game g = of(e.getPlayer()); if (g == null) return; if (g.ended || g.match.state() != DuelMatch.State.FIGHTING || g.spectators.contains(e.getPlayer().getUniqueId())) { e.setCancelled(true); return; } var rs = e.getBlockReplacedState(); g.log.recordData(rs.getWorld().getName(), rs.getX(), rs.getY(), rs.getZ(), rs.getBlockData()); g.log.recordPlaced(e.getBlock()); }
    @EventHandler(priority = EventPriority.HIGH) public void onBreak(BlockBreakEvent e) { Game g = of(e.getPlayer()); if (g == null) return; if (!g.log.isPlaced(e.getBlock())) e.setCancelled(true); else g.log.unplace(e.getBlock()); }
    @EventHandler public void onFood(FoodLevelChangeEvent e) { if (e.getEntity() instanceof Player p && of(p) != null) e.setCancelled(true); }
    @EventHandler public void onDrop(PlayerDropItemEvent e) { if (of(e.getPlayer()) != null) e.setCancelled(true); }
    @EventHandler public void onMove(PlayerMoveEvent e) { Game g = of(e.getPlayer()); if (g != null && !g.ended && g.match.state() != DuelMatch.State.FIGHTING && !g.spectators.contains(e.getPlayer().getUniqueId()) && e.getTo() != null && (e.getFrom().getX() != e.getTo().getX() || e.getFrom().getZ() != e.getTo().getZ())) { e.setTo(e.getFrom()); } }
    @EventHandler public void onQuit(PlayerQuitEvent e) { Player p = e.getPlayer(); if (queue.leave(p.getUniqueId())) Activities.leave(p.getUniqueId(), Activities.Kind.DUEL_QUEUE); invites.remove(p.getUniqueId()); Game g = of(p); if (g != null) forfeit(p); }
    @EventHandler public void onCmd(PlayerCommandPreprocessEvent e) { Game g = of(e.getPlayer()); if (g == null || e.getPlayer().hasPermission("doblo.admin")) return; String c = e.getMessage().toLowerCase(Locale.ROOT).split(" ")[0]; if (!Set.of("/duel", "/msg", "/w", "/r", "/rapor").contains(c)) { e.setCancelled(true); e.getPlayer().sendMessage("§cMaçta bu komut kullanılamaz. /duel leave"); } }


    /** HUD verileri: oyun modu satırı içermez. */
    public List<String> hudLines(Player p) {
        Game g = byPlayer.get(p.getUniqueId()); if (g == null) return List.of();
        UUID other = p.getUniqueId().equals(g.match.a) ? g.match.b : g.match.a;
        int value = eloOf(p.getUniqueId(), g.kit);
        Player opponent = Bukkit.getPlayer(other);
        return List.of("Oyuncu: " + p.getName(), "ELO: " + value, "Lig: " + Elo.league(value),
                "Rakip: " + (opponent == null ? "Çevrimdışı" : opponent.getName()),
                "Skor: " + g.match.rounds(g.match.a) + " - " + g.match.rounds(g.match.b));
    }

    public void shutdown() {
        if (poller != null) poller.cancel(); for (Game g : new ArrayList<>(inUse.values())) { g.ended = true; for (UUID u : new ArrayList<>(byPlayer.keySet())) { Player p = Bukkit.getPlayer(u); if (p != null && byPlayer.get(u) == g) state.restoreIfPending(p); } g.log.restore(plugin, Integer.MAX_VALUE, null); }
        inUse.clear(); byPlayer.clear();
    }
}
